/* Main.cpp (exercise 6.8)
Description:
	* Solutions to problems a-k.
*/

#include <iostream>
#include "NameDecorator.hpp"
#include "ShapeDecorator.hpp"
#include "Shape.hpp"

int main()
{
	

	system("pause");

	return 0;
}