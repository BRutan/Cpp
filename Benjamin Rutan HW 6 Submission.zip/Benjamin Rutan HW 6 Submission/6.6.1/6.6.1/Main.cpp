/* Main.cpp (exercise 6.6.1)
Description:
	* Solutions to problems a-f.
*/

#include <iostream>
#include "Point.hpp"
#include "ApproximateDistance.hpp"
#include "DistanceStrategy.hpp"
#include "ExactDistance.hpp"

int main()
{
	// f) Calculate distance between two points using different DistanceStrategy methods:
	Point p1(4.0, 5.0), p2(12.0, 3.0);
	
	// Test ApproximateDistance:
	Point::DistanceMethod(&ApproximateDistance());

	std::cout << "Distance between " << p1 << ", " << p2 << " (using ApproximateDistance): " << p1.Distance(p2) << std::endl;
	std::cout << "Distance between " << p1 << ", " << Point(0, 0) << " (using ApproximateDistance): " << p1.Distance() << std::endl;

	// Change strategy to ExactDistance:
	Point::DistanceMethod(&ExactDistance());

	std::cout << "Distance between " << p1 << ", " << p2 << " (using ExactDistance): " << p1.Distance(p2) << std::endl;
	std::cout << "Distance between " << p1 << ", " << Point(0, 0) << " (using ExactDistance): " << p1.Distance() << std::endl;
	
	system("pause");

	return 0;
}