/* ExactDistance.hpp (exercise 6.6.1)
Description:
	* Calculate exact distance between two points.
Class Members:
	// Constructors/Destructor:
	* ExactDistance(): Default constructor.
	* ExactDistance(const ExactDistance&): Copy constructor.
	* ~ExactDistance(): Destructor.
	// Misc Methods:
	* double Distance(const Point&, const Point&) const: Calculate distance using Pythagorean theorem.
	// Overloaded Operators:
	* ExactDistance& operator=(const ExactDistance&): Assignment operator.
*/

#ifndef EXACTDISTANCE_HPP
#define EXACTDISTANCE_HPP

#include <cmath>
#include "DistanceStrategy.hpp"

class Point;

class ExactDistance : public DistanceStrategy
{
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	ExactDistance() noexcept;					  /* Default constructor. */
	ExactDistance(const ExactDistance&) noexcept; /* Copy constructor. */
	virtual ~ExactDistance() noexcept;			  /* Destructor. */
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	virtual double Distance(const Point&, const Point&) const noexcept;		/* Calculate distance using Pythagorean Theorem ("exact" precision). */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	ExactDistance& operator=(const ExactDistance&) noexcept;				/* Assignment operator. */
};

#endif