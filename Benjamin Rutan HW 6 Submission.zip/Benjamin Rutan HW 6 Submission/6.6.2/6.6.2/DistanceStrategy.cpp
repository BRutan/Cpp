/* DistanceStrategy.cpp (exercise 6.6.2)
Description:
	* Abstract base class used in defining derived distance calculation methods, to enable polymorphism.
Class Methods:
	// Constructors/Destructor:
	* DistanceStrategy(): Default constructor.
	* ~DistanceStrategy(): Destructor.
	// Misc Methods:
	* double Distance(const Point&, const Point&) const: PVMF to be overwritten in derived strategy classes. Calculate distance between two points.
	// Overloaded Operators:
	* DistanceStrategy& operator=(const DistanceStrategy&): Assignment operator.
*/

#include "DistanceStrategy.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
DistanceStrategy::DistanceStrategy() noexcept				/* Default constructor. */
{

}
DistanceStrategy::~DistanceStrategy() noexcept				/* Destructor. */
{

}
////////////////////////////
// Overloaded Operators:
////////////////////////////
DistanceStrategy& DistanceStrategy::operator=(const DistanceStrategy &dist_in) noexcept				/* Assignment operator. */
{
	// Preclude self-assignment:
	if (this != &dist_in)
	{

	}
	return *this;
}