/* ApproximateDistance.cpp (exercise 6.6.2)
Description:
	* Calculate the approximate distance between two points using fast but inaccurate "taxi driver" algorithm.
Class Members:
	// Constructors/Destructor:
	* ApproximateDistance(): Default constructor.
	* ApproximateDistance(const ApproximateDistance&): Copy constructor.
	* ~ApproximateDistance(): Destructor.
	// Misc Methods:
	* double Distance(const Point&, const Point&) const: Calculate distance using "taxi driver" algorithm.
	// Overloaded Operators:
	* ApproximateDistance& operator=(const ApproximateDistance&): Assignment Operator.
*/

#include <cmath>
#include "ApproximateDistance.hpp"
#include "DistanceStrategy.hpp"
#include "Point.hpp"
#include "Shape.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
ApproximateDistance::ApproximateDistance() noexcept							     /* Default constructor. */
{

}
ApproximateDistance::ApproximateDistance(const ApproximateDistance &in) noexcept /* Copy constructor. */
{

}
ApproximateDistance::~ApproximateDistance() noexcept						     /* Destructor. */
{

}
////////////////////////////
// Misc Methods:
////////////////////////////
double ApproximateDistance::Distance(const Point &p1, const Point &p2) const noexcept				/* Calculate distance using Pythagorean Theorem ("exact" precision). */
{
	return std::abs(p1.X() - p2.X()) + std::abs(p1.Y() - p2.Y());
}
////////////////////////////
// Overloaded Operators:
////////////////////////////
ApproximateDistance& ApproximateDistance::operator=(const ApproximateDistance &in) noexcept	/* Assignment operator. */
{
	if (this != &in)
	{

	}
	return *this;
}