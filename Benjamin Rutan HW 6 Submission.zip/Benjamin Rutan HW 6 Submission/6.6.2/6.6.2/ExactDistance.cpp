/* ExactDistance.cpp (exercise 6.6.2)
Description:
	* Calculate exact distance between two points.
Class Members:
	// Constructors/Destructor:
	* ExactDistance(): Default constructor.
	* ExactDistance(const ExactDistance&): Copy constructor.
	* ~ExactDistance(): Destructor.
	// Misc Methods:
	* double Distance(const Point&, const Point&) const: Calculate distance using Pythagorean theorem.
	// Overloaded Operators:
	* ExactDistance& operator=(const ExactDistance&): Assignment operator.
*/

#include <cmath>
#include "DistanceStrategy.hpp"
#include "ExactDistance.hpp"
#include "Point.hpp"
#include "Shape.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
ExactDistance::ExactDistance() noexcept				/* Default constructor. */
{

}
ExactDistance::ExactDistance(const ExactDistance &in) noexcept	/* Copy constructor. */
{

}
ExactDistance::~ExactDistance() noexcept		/* Destructor. */
{

}
////////////////////////////
// Misc Methods:
////////////////////////////
double ExactDistance::Distance(const Point &p1, const Point &p2) const noexcept		/* Calculate distance using Pythagorean Theorem ("exact" precision). */
{
	return std::sqrt(std::pow(p2.X() - p1.X(), 2) + std::pow(p2.Y() - p1.Y(), 2));
}
////////////////////////////
// Overloaded Operators:
////////////////////////////
ExactDistance& ExactDistance::operator=(const ExactDistance &in) noexcept				/* Assignment operator. */
{
	if (this != &in)
	{

	}
	return *this;
}
