/* DistanceStrategy.hpp (exercise 6.6.1)
Description:
	* Abstract base class used in defining derived distance calculation methods, to enable polymorphism.
Class Methods:
	// Constructors/Destructor:
	* DistanceStrategy(): Default constructor.
	* ~DistanceStrategy(): Destructor.
	// Misc Methods:
	* double Distance(const Point&, const Point&) const: PVMF to be overwritten in derived strategy classes. Calculate distance between two points. 
	// Overloaded Operators:
	* DistanceStrategy& operator=(const DistanceStrategy&): Assignment operator.
*/

#ifndef DISTANCESTRATEGY_HPP
#define DISTANCESTRATEGY_HPP

#include "Shape.hpp"

class Point;	/* Forward declare to prevent issues. */

class DistanceStrategy
{
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	DistanceStrategy() noexcept;									/* Default constructor. */
	DistanceStrategy(const DistanceStrategy&) noexcept;				/* Default constructor. */
	DistanceStrategy(DistanceStrategy*) noexcept;					/* Copy constructor. */
	virtual ~DistanceStrategy() noexcept;							/* Destructor. */
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	virtual double Distance(const Point&, const Point&) const noexcept = 0;		/* PVMF to be overwritten in derived strategy classes. */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	DistanceStrategy& operator=(const DistanceStrategy&) noexcept;				/* Assignment operator. */
};

#endif
