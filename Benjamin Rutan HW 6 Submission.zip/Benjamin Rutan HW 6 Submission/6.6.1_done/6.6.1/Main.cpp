/* Main.cpp (exercise 6.6.1)
Description:
	* Solutions to problems a-f.
*/

#include <iostream>
#include <memory>
#include "Point.hpp"
#include "ApproximateDistance.hpp"
#include "DistanceStrategy.hpp"
#include "ExactDistance.hpp"

int main()
{
	// f) Calculate distance between two points using different DistanceStrategy methods:
	Point p1(4.0, 5.0), p2(12.0, 3.0);
	ApproximateDistance *strategy1 = new ApproximateDistance();
	ExactDistance *strategy2 = new ExactDistance();

	// Test ApproximateDistance:
	Point::SetDistanceStrategy(strategy1);

	std::cout << "Distance between "; 
	p1.Print(); std::cout << ", ";
	p2.Print();
	std::cout << " (using ApproximateDistance): " << p1.Distance(p2) << std::endl;
	std::cout << "Distance between ";
	p1.Print(); std::cout << ", ";
	Point(0, 0).Print();
	std::cout << " (using ApproximateDistance): " << p1.Distance() << std::endl;

	// Change strategy to ExactDistance:
	Point::SetDistanceStrategy(strategy2);

	std::cout << "Distance between ";
	p1.Print(); std::cout << ", ";
	p2.Print();
	std::cout << " (using ExactDistance): " << p1.Distance(p2) << std::endl;
	std::cout << "Distance between ";
	p1.Print();
	std::cout << ", ";
	Point(0, 0).Print();
	std::cout << " (using ExactDistance): " << p1.Distance() << std::endl;
	
	system("pause");

	return 0;
}