/* Shape.hpp (exercise 6.3)
Description:
	*Header file for Shape class, declares member variables/objects and functions.
Member Functions:
	// Constructors/Destructor:
	*Shape(): Default constructor.
	*Shape(const Shape&): Copy constructor.
	*virtual ~Shape(): Destructor.
	// Misc. Methods:
	void Print() const: PVMF to make class abstract. 
*/

#ifndef SHAPE_HPP
#define SHAPE_HPP

class Shape
{
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	Shape() noexcept;								/* Default Constructor. */
	Shape(Shape*) noexcept;							/* Copy constructor using pointers. */
	Shape(const Shape&) noexcept;					/* Copy Constructor. */
	virtual ~Shape() noexcept;						/* Destructor. */
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	virtual void Print() const noexcept = 0;		/* Prints string representation of Shape. */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	Shape& operator=(const Shape&) noexcept;		/* Assignment operator (with Shape). */
};

#endif