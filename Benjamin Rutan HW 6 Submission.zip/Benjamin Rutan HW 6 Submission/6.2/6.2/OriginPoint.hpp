/* OriginPoint.hpp (exercise 6.2)
Description:
	*


*/


#ifndef ORIGINPOINT_HPP
#define ORIGINPOINT_HPP

#include "Point.hpp"
#include "Singleton.hpp"

class OriginPoint : public Singleton<Point>
{
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	OriginPoint();
	OriginPoint(const OriginPoint&);
	virtual ~OriginPoint();
	////////////////////////////
	// Misc. Methods:
	////////////////////////////
	OriginPoint& operator=(const OriginPoint&);
};

#endif