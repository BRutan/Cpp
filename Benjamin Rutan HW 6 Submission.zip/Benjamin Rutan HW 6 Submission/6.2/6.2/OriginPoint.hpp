/* OriginPoint.hpp (exercise 6.2)
Description:
	* Derived class from Singleton<Point>, models the origin (point (0, 0) in R^2). 
Member Functions:
	// Constructors/Destructor:
	OriginPoint(): Default constructor. Set base Point object to default state.
	OriginPoint(const OriginPoint&): Copy constructor. Set base Point object.
	~OriginPoint(): Destructor.
	// Misc. Methods:
	OriginPoint& opreator=(const OriginPoint&): Assignment operator.
*/

#ifndef ORIGINPOINT_HPP
#define ORIGINPOINT_HPP

class Point;
#include "Point.hpp"
#include "Singleton.cpp"

class OriginPoint : public Singleton<Point>
{
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	OriginPoint();
	OriginPoint(const OriginPoint&);
	virtual ~OriginPoint();
	////////////////////////////
	// Misc. Methods:
	////////////////////////////
	OriginPoint& operator=(const OriginPoint&);
};

#endif