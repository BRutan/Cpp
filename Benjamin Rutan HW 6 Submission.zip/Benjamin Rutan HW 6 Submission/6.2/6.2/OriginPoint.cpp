/* OriginPoint.cpp (exercise 6.2)
Description:
	* Derived class from Singleton<Point>, models the origin (point (0, 0) in R^2).
Member Functions:
	// Constructors/Destructor:
	* OriginPoint(): Default constructor. Set base Point object to default state.
	* OriginPoint(const OriginPoint&): Copy constructor. Set base Point object.
	* ~OriginPoint(): Destructor.
	// Misc. Methods:
	* OriginPoint& opreator=(const OriginPoint&): Assignment operator.
*/

#include "OriginPoint.hpp"
#include "Point.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
OriginPoint::OriginPoint() : OriginPoint::Singleton()
{

}
OriginPoint::OriginPoint(const OriginPoint& op_in) 
{

}
OriginPoint::~OriginPoint()
{

}
////////////////////////////
// Misc. Methods:
////////////////////////////
OriginPoint& OriginPoint::operator=(const OriginPoint& op_in)
{
	// Preclude self-assignment:
	if (this != &op_in)
	{

	}
	return *this;
}