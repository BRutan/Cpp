/* OriginPoint.cpp (exercise 6.2)
Description:
	* 


*/



#include "OriginPoint.hpp"


////////////////////////////
// Constructors/Destructor:
////////////////////////////
OriginPoint::OriginPoint() : OriginPoint::Singleton()
{

}
OriginPoint::OriginPoint(const OriginPoint& op_in) 
{

}
OriginPoint::~OriginPoint()
{

}
////////////////////////////
// Misc. Methods:
////////////////////////////
OriginPoint& OriginPoint::operator=(const OriginPoint& op_in)
{
	// Preclude self-assignment:
	if (this != &op_in)
	{

	}
	return *this;
}