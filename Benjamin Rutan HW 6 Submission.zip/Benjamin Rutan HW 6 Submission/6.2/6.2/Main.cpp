/* Main.cpp (exercise 6.2)
Description:
	*



*/

#include <iostream>
#include "OriginPoint.hpp"
#include "Point.hpp"
#include "Singleton.hpp"
#include "Shape.hpp"


int main()
{
	system("pause");

	return 0;
}