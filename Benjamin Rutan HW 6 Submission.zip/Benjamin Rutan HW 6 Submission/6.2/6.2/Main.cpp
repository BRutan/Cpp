/* Main.cpp (exercise 6.2)
Description:
	* Solutions to problems a-d.
*/

#include <iostream>
#include "OriginPoint.hpp"
#include "Point.hpp"
#include "Singleton.hpp"
#include "Shape.hpp"

int main()
{
	// d) Write test program to test origin point Distance() function.
	Point p1(4.0, 5.0);
	OriginPoint op1;
	
	std::cout << "Distance between point ";
	p1.Print();
	std::cout << " and point ";
	op1.instance()->Print();
	std::cout << ": " << p1.Distance(op1) << std::endl;

	system("pause");

	return 0;
}