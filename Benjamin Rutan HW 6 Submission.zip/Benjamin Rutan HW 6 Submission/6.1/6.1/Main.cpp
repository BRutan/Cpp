/* Main.cpp (exercise 6.1)
Description:
	* Solutions to problems a-f.
*/

#include <iostream>
#include "Circle.hpp"
#include "Line.hpp"
#include "Point.hpp"
#include "Shape.hpp"

int main()
{
	// Create instances of Circle, Line, Point and Shape:
	Circle c1(4.0, 5.0);
	Line l1(Point(2.0, 5.0), Point(3.0, 4.0));
	Point p1(12.0, 13.0);

	// Test the overloaded stdout operator:
	std::cout << "Circle1: "; 
	c1.Print();
	std::cout << std::endl;
	std::cout << "Line1: ";
	l1.Print();
	std::cout << std::endl;
	std::cout << "Point1: ";
	p1.Print();
	std::cout << std::endl;

	// Test the class hierarchy:
	std::cout << "Shape is base of Circle: " << std::is_base_of<Shape, Circle>::value << std::endl;
	std::cout << "Shape is base of Line: " << std::is_base_of<Shape, Line>::value << std::endl;
	std::cout << "Shape is base of Point: " << std::is_base_of<Shape, Point>::value << std::endl;

	std::cout << "Shape is abstract: " << std::is_abstract<Shape>::value << std::endl;
	std::cout << "Shape is final: " << std::is_final<Shape>::value << std::endl;
	std::cout << "Point is final: " << std::is_final<Point>::value << std::endl;
	std::cout << "Circle is final: " << std::is_final<Circle>::value << std::endl;
	std::cout << "Line is final: " << std::is_final<Line>::value << std::endl;

	// Test the Point::Distance() and Line::Length() functions:
	p1.Print(); std::cout << " distance from "; Point(3.0, 4.0).Print(); std::cout << ": " << p1.Distance(Point(3.0, 4.0)) << std::endl;
	p1.Print(); std::cout << " distance from origin: " << p1.Distance() << std::endl;
	std::cout << "Line l1 Length: " << l1.Length() << std::endl;

	system("pause");

	return 0;
}