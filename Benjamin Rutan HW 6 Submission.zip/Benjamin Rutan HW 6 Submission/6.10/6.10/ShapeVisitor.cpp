/* ShapeVisitor.cpp (exercise 6.10)
Description:
	* Abstract base class following Visitor pattern, to be specialized in derived classes that alter state of Shape derived classes.
Class Members:
	// Constructors/Destructor:
	* ShapeVisitor(): Default constructor.
	* ShapeVisitor(const ShapeVisitor&): Copy constructor.
	* ~ShapeVisitor(): Destructor.
	// Misc. Methods:
	* void visit(Point&) const = 0: Alter state of Point.
	* void visit(Line&) const = 0: Alter state of Line.
	* void visit(Circle&) const = 0: Alter state of Circle.
	* void visit(ShapeComposite&) const = 0: Alter state of ShapeComposite.
	// Overloaded Operators:
	* ShapeVisitor& operator=(const ShapeVisitor&): Assignment operator.
*/

#include "ShapeVisitor.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
ShapeVisitor::ShapeVisitor() noexcept							/* Default constructor. */
{

}
ShapeVisitor::ShapeVisitor(const ShapeVisitor&) noexcept		/* Copy constructor. */
{

}
ShapeVisitor::~ShapeVisitor() noexcept							/* Destructor. */
{

}	
////////////////////////////
// Overloaded Operators:
////////////////////////////
ShapeVisitor& ShapeVisitor::operator=(const ShapeVisitor &in) noexcept /* Assignment operator. */
{
	if (this != &in)
	{

	}
	return *this;
}