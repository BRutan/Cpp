/* TranslateVisitor.hpp (exercise 6.10)
Description:
	* Derived ShapeVisitor class, translates Shape object using given distance in each direction (x, y).
Class Members:
	// Constructors/Destructor:
	* TranslateVisitor(): Default constructor. Set distance to 0.
	* TranslateVisitor(double): Overloaded constructor. Set distance.
	* TranslateVisitor(const TranslateVisitor&): Copy constructor. Copy distance.
	* ~TranslateVisitor(): Destructor.
	// Misc. Methods:
	* void visit(Point&) const: Alter state of Point.
	* void visit(Line&) const: Alter state of Line.
	* void visit(Circle&) const: Alter state of Circle.
	* void visit(ShapeComposite&) const: Alter state of ShapeComposite.
	// Overloaded Operators:
	* TranslateVisitor& operator=(const TranslateVisitor&): Assignment operator.
*/

#include "ShapeVisitor.hpp"
#include "Circle.hpp"
#include "Line.hpp"
#include "Point.hpp"
#include "ShapeComposite.hpp"
#include "Shape.hpp"
#include "TranslateVisitor.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
TranslateVisitor::TranslateVisitor() noexcept							/* Default constructor. */
{

}
TranslateVisitor::TranslateVisitor(double dist_in) noexcept : distance(dist_in)				/* Overloaded constructor. Assign distance. */
{

}
TranslateVisitor::TranslateVisitor(const TranslateVisitor &tv_in) noexcept : distance(tv_in.distance) /* Copy constructor. Copy distance. */
{

}
TranslateVisitor::~TranslateVisitor() noexcept				/* Destructor. */
{

}
////////////////////////////
// Misc Methods:
////////////////////////////
void TranslateVisitor::visit(Point &p_in) const noexcept		/* Alter state of Point class. */
{
	// Translate each dimension of point:
	p_in.X(p_in.X() + this->distance);
	p_in.Y(p_in.Y() + this->distance);
}
void TranslateVisitor::visit(Line &l_in) const noexcept			/* Alter state of Line class. */
{
	// Translate each point in Line:
	Point temp1(l_in.P1()), temp2(l_in.P2());
	temp1.X(temp1.X() + this->distance);
	temp1.Y(temp1.Y() + this->distance);
	temp2.X(temp2.X() + this->distance);
	temp2.Y(temp2.Y() + this->distance);
	l_in.P1(temp1);
	l_in.P2(temp2);
}
void TranslateVisitor::visit(Circle &c_in) const noexcept		/* Alter state of Circle class.*/
{
	// Translate Centerpoint of Circle:
	Point temp1(c_in.CenterPoint());
	temp1.X(temp1.X() + this->distance);
	temp1.Y(temp1.Y() + this->distance);
	c_in.CenterPoint(temp1);
}
////////////////////////////
// Overloaded Operators:
////////////////////////////
TranslateVisitor& TranslateVisitor::operator=(const TranslateVisitor &in) noexcept	 /* Assignment operator. */
{
	if (this != &in)
	{
		this->distance = in.distance;
	}
	return *this;
}