/* TranslateVisitor.hpp (exercise 6.10)
Description:
	* Derived ShapeVisitor class, translates Shape object using given distance in each direction (x, y).
Class Members:
	// Constructors/Destructor:
	* TranslateVisitor(): Default constructor. Set distance to 0.
	* TranslateVisitor(double): Overloaded constructor. Set distance.
	* TranslateVisitor(const TranslateVisitor&): Copy constructor. Copy distance.
	* ~TranslateVisitor(): Destructor.
	// Misc. Methods:
	* void visit(Point&) const: Alter state of Point.
	* void visit(Line&) const: Alter state of Line.
	* void visit(Circle&) const: Alter state of Circle.
	* void visit(ShapeComposite&) const: Alter state of ShapeComposite.
	// Overloaded Operators:
	* TranslateVisitor& operator=(const TranslateVisitor&): Assignment operator.
*/

#include "ShapeVisitor.hpp"
#include "Circle.hpp"
#include "Line.hpp"
#include "Point.hpp"
#include "ShapeComposite.hpp"
#include "Shape.hpp"
#include "TranslateVisitor.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
TranslateVisitor::TranslateVisitor() noexcept							/* Default constructor. */
{

}
TranslateVisitor::TranslateVisitor(double dist_in) noexcept : distance(dist_in)				/* Overloaded constructor. Assign distance. */
{

}
TranslateVisitor::TranslateVisitor(const TranslateVisitor &tv_in) noexcept : distance(tv_in.distance) /* Copy constructor. Copy distance. */
{

}
TranslateVisitor::~TranslateVisitor() noexcept				/* Destructor. */
{

}
////////////////////////////
// Misc Methods:
////////////////////////////
void TranslateVisitor::visit(Point &p_in) const noexcept		/* Alter state of Point class. */
{
	// Translate each dimension of point:
	p_in.X(p_in.X() + distance);
	p_in.Y(p_in.Y() + distance);
}
void TranslateVisitor::visit(Line &l_in) const noexcept			/* Alter state of Line class. */
{
	// Translate each point in Line:
	l_in.P1().X(l_in.P1().X() + distance);
	l_in.P1().Y(l_in.P1().Y() + distance);
}
void TranslateVisitor::visit(Circle &c_in) const noexcept		/* Alter state of Circle class.*/
{
	// Translate Centerpoint of Circle:
	c_in.CenterPoint().X(c_in.CenterPoint().X() + distance);
	c_in.CenterPoint().Y(c_in.CenterPoint().Y() + distance);
}
void TranslateVisitor::visit(ShapeComposite &sc_in) const noexcept	/* Alter state of ShapeComposite class.*/
{
	Point *temp_p;
	Line *temp_l;
	Circle *temp_c;
	ShapeComposite *temp_sc;
	// Delegate responsibility for each element of ShapeComposite:
	for (auto iter = sc_in.begin(); iter != sc_in.end(); iter++)
	{
		// Determine appropriate function to call via attempted downcasting:
		temp_p = (Point*)(&**iter);
		if (temp_p == nullptr)
		{
			// Attempt to convert to Line pointer:
			temp_l = (Line*)(&**iter);
			if (temp_l == nullptr)
			{
				// Attempt to convert to Circle pointer:
				temp_c = (Circle*)(&**iter);
				if (temp_c == nullptr)
				{
					// Attempt to convert to ShapeComposite:
					temp_sc = (ShapeComposite*)(&**iter);
					if (temp_sc == nullptr)
					{
						// No types left, break:
						break;
					}
					else
					{
						// Call ShapeComposite version:
						this->visit(*temp_sc);
					}
				}
				else
				{
					// Call Circle version of visit:
					this->visit(*temp_c);
				}
			}
			else
			{
				// Call Line version of visit:
				this->visit(*temp_l);
			}
		}
		else
		{
			// Call Point version of visit:
			this->visit(*temp_p);
		}
	}
}
////////////////////////////
// Overloaded Operators:
////////////////////////////
TranslateVisitor& TranslateVisitor::operator=(const TranslateVisitor &in) noexcept	 /* Assignment operator. */
{
	if (this != &in)
	{
		this->distance = in.distance;
	}
	return *this;
}