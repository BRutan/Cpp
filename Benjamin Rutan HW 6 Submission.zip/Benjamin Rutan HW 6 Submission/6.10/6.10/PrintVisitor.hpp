/* PrintVisitor.hpp (exercise 6.10)
Description:
	* Abstract base class following Visitor pattern, to be specialized in derived classes that alter state of Shape derived classes.
Class Members:
	// Constructors/Destructor:
	* PrintVisitor(): Default constructor.
	* PrintVisitor(const PrintVisitor&): Copy constructor.
	* ~PrintVisitor(): Destructor.
	// Misc. Methods:
	* void visit(Point&) const: Alter state of Point.
	* void visit(Line&) const: Alter state of Line.
	* void visit(Circle&) const: Alter state of Circle.
	* void visit(ShapeComposite&) const: Alter state of ShapeComposite.
	// Overloaded Operators:
	* PrintVisitor& operator=(const PrintVisitor&): Assignment operator.
*/

#ifndef PRINTVISITOR_HPP
#define PRINTVISITOR_HPP

#include "ShapeVisitor.hpp"

class Point;
class Line;
class Circle;
class ShapeComposite;

class PrintVisitor : public ShapeVisitor
{
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	PrintVisitor() noexcept;							/* Default constructor. */
	PrintVisitor(const PrintVisitor&) noexcept;			/* Copy constructor. */
	virtual ~PrintVisitor() noexcept;					/* Destructor. */
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	virtual void visit(Point&) const noexcept;			/* Alter state of Point class. */
	virtual void visit(Line&) const noexcept;			/* Alter state of Line class. */
	virtual void visit(Circle&) const noexcept;			/* Alter state of Circle class.*/
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	PrintVisitor& operator=(const PrintVisitor&) noexcept; /* Assignment operator. */
};

#endif

