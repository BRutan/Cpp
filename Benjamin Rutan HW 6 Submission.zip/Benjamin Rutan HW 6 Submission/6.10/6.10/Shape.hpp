/* Shape.hpp (exercise 6.10)
Description:
	*Header file for Shape class, declares member variables/objects and functions.
Member Functions:
	// Constructors/Destructor:
	*Shape(): Default constructor.
	*Shape(const Shape&): Copy constructor.
	*virtual ~Shape(): Destructor.
	// Misc. Methods:
	*void Print() const: PVMF to make class abstract. 
*/

#ifndef SHAPE_HPP
#define SHAPE_HPP

#include <memory>

class ShapeVisitor;

class Shape
{
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	Shape() noexcept;								/* Default Constructor. */
	Shape(Shape*) noexcept;							/* Copy constructor using pointers. */
	Shape(const Shape&) noexcept;					/* Copy Constructor. */
	virtual ~Shape() noexcept;						/* Destructor. */
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	virtual void Accept(std::shared_ptr<ShapeVisitor>&) = 0;	/* Allow ShapeVisitor to interact with derived Shape object. */
	virtual Shape* Clone() noexcept = 0;			/* PVMF to be defined in derived classes. Return reference to this derived Shape object. */
	virtual void Print() const noexcept = 0;		/* Prints string representation of Shape. */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	Shape& operator=(const Shape&) noexcept;		/* Assignment operator (with Shape). */
};

#endif