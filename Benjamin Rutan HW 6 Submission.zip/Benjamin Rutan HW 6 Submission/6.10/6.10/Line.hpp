/*	Line.hpp (exercise 6.10)
Description:
	* Declare Line class that represents a line in 2-D Euclidean space. 
State Variables/Objects:
	*Point p1, p2: Points in 2-D Euclidean space.
Member Functions:
	*Line(): Default constructor (allocates memory for both state Point objects, sets their states to (0,0)).
	*Line(const Point&, const Point&): Overloaded constructor (allocates memory for both state Point objects, sets their states to (0,0)).
	*Line(const Line&): Copy constructor (allocates memory for both state Point objects, sets their states to passed Line's point's states). 
	*~Line(): Destructor (frees memory previously allocated by constructor).
	// Accessors:
	*Point P1() const: Return copy of P1 Point Object.
	*Point P2() const: Return copy of P2 Point Object.
	// Mutators:
	*void P1(const Point&): Change P1's state to state of passed Point object.
	*void P2(const Point&): Change P2's state to state of passed Point object.
	// Misc. Methods:
	*void Accept(shared_ptr<ShapeVisitor>&): Allow ShapeVisitor to interact with this Line.
	*Shape* Clone(): Return reference to this Line object.
	*double Length() const: Return length of line. 
	*void Print() const: "Print" the line to stdout.
*/

#ifndef LINE_HPP
#define LINE_HPP

#include <memory>
#include<iostream>
#include<string>
#include"Point.hpp"
#include"Shape.hpp"

class ShapeVisitor;

class Line : public Shape
{
private:
	///////////////////////////
	// State objects: 
	///////////////////////////
	Point p1;						/* First point object. */
	Point p2;						/* Second point object. */
public:
	///////////////////////////
	// Constructors/Destructor: 
	///////////////////////////
	Line() noexcept;								/* Default Constructor. */
	Line(const Point&, const Point&) noexcept;		/* Overloaded Constructor. */
	Line(Shape*) noexcept;							/* Copy constructor using pointers. */
	Line(const Line&) noexcept;						/* Copy Constructor. */
	virtual ~Line() noexcept;						/* Destructor. */
	///////////////////////////
	// Accessors:
	///////////////////////////
	Point P1() const noexcept;				/* Returns x value of P1 Point Object. */
	Point P2() const noexcept;				/* Returns y value of P2 Point Object. */
	///////////////////////////
	// Mutators:
	///////////////////////////
	void P1(const Point&) noexcept;			/* Change x value of P1 Point Object. */
	void P2(const Point&) noexcept;			/* Change y value of P2 Point Object. */
	///////////////////////////
	// Misc. Methods:
	///////////////////////////
	void Accept(std::shared_ptr<ShapeVisitor>&); /* Allow ShapeVisitor to interact with this Line. */
	Shape* Clone() noexcept;				/* Return reference to this Line object. */
	double Length() const noexcept;			/* Return the length of the line. */
	virtual void Print() const noexcept;	/* "Print" the line to stdout. */
	///////////////////////////
	// Overloaded Operators:
	///////////////////////////
	// Member operators:
	Line& operator=(const Line&) noexcept;	/* Assignment operator. */
};

#endif