/* TranslateVisitor.hpp (exercise 6.10)
Description:
	* Abstract base class following Visitor pattern, to be specialized in derived classes that alter state of Shape derived classes.
Class Members:
	// Constructors/Destructor:
	* TranslateVisitor(): Default constructor.
	* TranslateVisitor(const TranslateVisitor&): Copy constructor.
	* ~TranslateVisitor(): Destructor.
	// Misc. Methods:
	* void visit(Point&) const = 0: Alter state of Point.
	* void visit(Line&) const = 0: Alter state of Line.
	* void visit(Circle&) const = 0: Alter state of Circle.
	* void visit(ShapeComposite&) const = 0: Alter state of ShapeComposite.
	// Overloaded Operators:
	* TranslateVisitor& operator=(const TranslateVisitor&): Assignment operator.
*/

#ifndef TRANSLATEVISITOR_HPP
#define TRANSLATEVISITOR_HPP

#include "ShapeVisitor.hpp"

class Point;
class Line;
class Circle;
class ShapeComposite;

class TranslateVisitor : public ShapeVisitor
{
private:
	double distance;
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	TranslateVisitor() noexcept;							/* Default constructor. Set distance to 0. */
	TranslateVisitor(double) noexcept;						/* Default constructor. Set distance to 0. */
	TranslateVisitor(const TranslateVisitor&) noexcept;		/* Copy constructor. */
	virtual ~TranslateVisitor() noexcept;					/* Destructor. */
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	virtual void visit(Point&) const noexcept;			/* Alter state of Point class. */
	virtual void visit(Line&) const noexcept;			/* Alter state of Line class. */
	virtual void visit(Circle&) const noexcept;			/* Alter state of Circle class.*/
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	TranslateVisitor& operator=(const TranslateVisitor&) noexcept; /* Assignment operator. */
};

#endif