/* PrintVisitor.cpp (exercise 6.10)
Description:
	* Abstract base class following Visitor pattern, to be specialized in derived classes that alter state of Shape derived classes.
Class Members:
	// Constructors/Destructor:
	* PrintVisitor(): Default constructor.
	* PrintVisitor(const PrintVisitor&): Copy constructor.
	* ~PrintVisitor(): Destructor.
	// Misc. Methods:
	* void visit(Point&) const: Alter state of Point.
	* void visit(Line&) const: Alter state of Line.
	* void visit(Circle&) const: Alter state of Circle.
	* void visit(ShapeComposite&) const: Alter state of ShapeComposite.
	// Overloaded Operators:
	* PrintVisitor& operator=(const PrintVisitor&): Assignment operator.
*/

#include "PrintVisitor.hpp"
#include "Circle.hpp"
#include "Line.hpp"
#include "Point.hpp"
#include "ShapeComposite.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
PrintVisitor::PrintVisitor() noexcept							/* Default constructor. */
{

}
PrintVisitor::PrintVisitor(const PrintVisitor&) noexcept			/* Copy constructor. */
{

}
PrintVisitor::~PrintVisitor() noexcept					/* Destructor. */
{

}
////////////////////////////
// Misc Methods:
////////////////////////////
void PrintVisitor::visit(Point &p_in) const noexcept	/* Alter state of Point class. */
{
	p_in.Print();
}
void PrintVisitor::visit(Line &l_in) const noexcept		/* Alter state of Line class. */
{
	l_in.Print();
}
void PrintVisitor::visit(Circle &circ_in) const noexcept		/* Alter state of Circle class.*/
{
	circ_in.Print();
}
void PrintVisitor::visit(ShapeComposite &sc_in) const noexcept	/* Alter state of ShapeComposite class.*/
{
	sc_in.Print();
}
////////////////////////////
// Overloaded Operators:
////////////////////////////
PrintVisitor& PrintVisitor::operator=(const PrintVisitor &in) noexcept /* Assignment operator. */
{
	if (this != &in)
	{

	}
	return *this;
}