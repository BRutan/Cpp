/* ShapeVisitor.hpp (exercise 6.10)
Description:
	* Abstract base class following Visitor pattern, to be specialized in derived classes that alter state of Shape derived classes.
Class Members:
	// Constructors/Destructor:
	* ShapeVisitor(): Default constructor.
	* ShapeVisitor(const ShapeVisitor&): Copy constructor.
	* ~ShapeVisitor(): Destructor.
	// Misc. Methods:
	* void visit(Point&) const = 0: Alter state of Point.
	* void visit(Line&) const = 0: Alter state of Line.
	* void visit(Circle&) const = 0: Alter state of Circle.
	* void visit(ShapeComposite&) const = 0: Alter state of ShapeComposite.
	// Overloaded Operators:
	* ShapeVisitor& operator=(const ShapeVisitor&): Assignment operator.
*/

#ifndef SHAPEVISITOR_HPP
#define SHAPEVISITOR_HPP

class Point;
class Line;
class Circle;
class Shape;
class ShapeComposite;

class ShapeVisitor
{
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	ShapeVisitor() noexcept;							/* Default constructor. */
	ShapeVisitor(const ShapeVisitor&) noexcept;			/* Copy constructor. */
	virtual ~ShapeVisitor() noexcept;					/* Destructor. */
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	virtual void visit(Point&) const noexcept = 0;			/* PVMF to be overwritten. Alter state of Point class. */			
	virtual void visit(Line&) const noexcept = 0;			/* PVMF to be overwritten. Alter state of Line class. */
	virtual void visit(Circle&) const noexcept = 0;			/* PVMF to be overwritten. Alter state of Circle class.*/
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	ShapeVisitor& operator=(const ShapeVisitor&) noexcept; /* Assignment operator. */
};

#endif
