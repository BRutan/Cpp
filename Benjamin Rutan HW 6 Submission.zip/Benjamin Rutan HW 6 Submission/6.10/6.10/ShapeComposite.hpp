/* ShapeComposite.hpp (exercise 6.10)
Description:
	* Class houses list of derived Shape classes (Circle, Point, Line), provides iterable functionality.
Member Functions:
	// Constructor/Destructor:
	* ShapeComposite(): Default constructor. Initialize shapePtrs list to default initialization.
	* ~ShapeComposite(): Destructor.
	// Accessors:
	* size_t count() const: Return number of elements in the shapePtrs list.
	// Mutators:
	* void AddShape(shared_ptr<Shape>&): Add new shared pointer to object of derived Shape class to the ShapeComposite.
	// Misc. Methods:
	*void Accept(shared_ptr<ShapeVisitor>&): Allow ShapeVisitor to interact with this ShapeComposite.
	* Shape* Clone(): Return reference to this ShapeComposite.
	* compositeIterator begin(): Return iterator to start of shapePtrs list.
	* constCompositeIterator begin() const;	Return const iterator to start of shapePtrs list.
	* compositeIterator end(): Return iterator to "end" of shapePtrs list.
	* constCompositeIterator end() const: Return const iterator to "end" of shapePtrs list.
*/

#ifndef SHAPECOMPOSITE_HPP
#define SHAPECOMPOSITE_HPP

#include <iostream>
#include <list>
#include <memory>
#include <sstream>
#include "Shape.hpp"

class ShapeVisitor;

class ShapeComposite : public Shape
{
private:
	std::list<std::shared_ptr<Shape>> shapePtrs;
public:
	typedef std::list<std::shared_ptr<Shape>>::iterator compositeIterator;
	typedef std::list<std::shared_ptr<Shape>>::const_iterator constCompositeIterator;
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	ShapeComposite() noexcept;									/* Default constructor. */
	ShapeComposite(Shape*) noexcept;					/* Copy constructor with pointers. */
	ShapeComposite(const ShapeComposite&) noexcept;				/* Private copy constructor. */
	virtual ~ShapeComposite() noexcept;							/* Destructor. */
	////////////////////////////
	// Accessors:
	////////////////////////////
	std::size_t count() const noexcept;				/* Return size of shapePtrs list. */
	////////////////////////////
	// Mutators:
	////////////////////////////
	void AddShape(std::shared_ptr<Shape>&) noexcept;/* Add shape pointer to the shapePtrs list. */
	////////////////////////////
	// Misc. Methods:
	////////////////////////////
	void Accept(std::shared_ptr<ShapeVisitor>&);	/* Allow ShapeVisitor to interact with this Circle. */
	virtual Shape* Clone() noexcept;				/* Return reference to this ShapeComposite. */
	compositeIterator begin() noexcept;				/* Return iterator to start of shapePtrs list. */
	constCompositeIterator begin() const noexcept;	/* Return const iterator to start of shapePtrs list. */
	compositeIterator end() noexcept;				/* Return iterator to "end" of shapePtrs list. */
	constCompositeIterator end() const noexcept;	/* Return const iterator to "end" of shapePtrs list. */
	virtual void Print() const noexcept;			/* Print each Shape object to stdout. */
	////////////////////////////
	// Overloaded Operator:
	////////////////////////////
	ShapeComposite& operator=(ShapeComposite&) noexcept;	/* Assignment operator. */
};

#endif