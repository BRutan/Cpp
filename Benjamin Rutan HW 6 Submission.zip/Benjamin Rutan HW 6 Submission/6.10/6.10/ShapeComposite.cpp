/* ShapeComposite.hpp (exercise 6.10)
Description:
	* Class houses list of derived Shape classes (Circle, Point, Line), provides iterable functionality.
Member Functions:
	// Constructor/Destructor:
	* ShapeComposite(): Default constructor. Initialize shapePtrs list to default initialization.
	* ~ShapeComposite(): Destructor.
	// Accessors:
	* size_t count() const: Return number of elements in the shapePtrs list.
	// Mutators:
	* void AddShape(shared_ptr<Shape>&): Add new shared pointer to object of derived Shape class to the ShapeComposite.
	// Misc. Methods:
	*void Accept(shared_ptr<ShapeVisitor>&): Allow ShapeVisitor to interact with this ShapeComposite.
	* compositeIterator begin(): Return iterator to start of shapePtrs list.
	* constCompositeIterator begin() const;	Return const iterator to start of shapePtrs list.
	* compositeIterator end(): Return iterator to "end" of shapePtrs list.
	* constCompositeIterator end() const: Return const iterator to "end" of shapePtrs list.
*/

#include "ShapeComposite.hpp"
#include "ShapeVisitor.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
ShapeComposite::ShapeComposite() noexcept : shapePtrs()		/* Default constructor. */
{

}
ShapeComposite::ShapeComposite(Shape *sc_in) noexcept : shapePtrs(((ShapeComposite*)sc_in)->shapePtrs)					/* Copy constructor with pointers. */
{

}
ShapeComposite::~ShapeComposite() noexcept					/* Destructor. Reset all shared_ptrs in sharedPtrs list. */
{
	for (auto iter = shapePtrs.begin(); iter != shapePtrs.end(); iter++)
	{
		iter->reset();
	}
}
////////////////////////////
// Accessors:
////////////////////////////
std::size_t ShapeComposite::count() const noexcept			/* Return size of shapePtrs list. */
{
	return this->shapePtrs.size();
}
////////////////////////////
// Mutators:
////////////////////////////
void ShapeComposite::AddShape(std::shared_ptr<Shape> &shape_in) noexcept		/* Add shape pointer to the shapePtrs list. */
{
	this->shapePtrs.emplace_back(shape_in);
}
////////////////////////////
// Misc. Methods:
////////////////////////////
void ShapeComposite::Accept(std::shared_ptr<ShapeVisitor> &sv_in) /* Allow ShapeVisitor to interact with this Circle. */
{
	for (auto iter = this->shapePtrs.begin(); iter != this->shapePtrs.end(); iter++)
	{
		(*iter)->Accept(sv_in);
	}
}
Shape* ShapeComposite::Clone() noexcept				/* Return reference to this ShapeComposite. */
{
	return this;
}
void ShapeComposite::Print() const noexcept										/* Print the ShapeComposite to stdout. */
{
	std::size_t size = shapePtrs.size();
	if (size)
	{
		std::size_t currSize = 1;
		std::cout << "{ ";
		for (auto iter = shapePtrs.begin(); iter != shapePtrs.end(); iter++)
		{
			(*iter)->Print();
			std::cout << ((++currSize <= size) ? ", " : " }");
		}
	}
}
ShapeComposite::compositeIterator ShapeComposite::begin() noexcept				/* Return iterator to start of shapePtrs list. */
{
	return this->shapePtrs.begin();
}
ShapeComposite::constCompositeIterator ShapeComposite::begin() const noexcept	/* Return const iterator to start of shapePtrs list. */
{
	return this->shapePtrs.cbegin();
}
ShapeComposite::compositeIterator ShapeComposite::end() noexcept					/* Return iterator to "end" of shapePtrs list. */
{
	return this->shapePtrs.end();
}
ShapeComposite::constCompositeIterator ShapeComposite::end() const noexcept		/* Return const iterator to "end" of shapePtrs list. */
{
	return this->shapePtrs.cend();
}
////////////////////////////
// Misc. Methods:
////////////////////////////
ShapeComposite& ShapeComposite::operator=(ShapeComposite &sc_in) noexcept		/* Assignment operator. */
{
	if (this != &sc_in)
	{
		this->shapePtrs = sc_in.shapePtrs;
	}
	return *this;
}