/* Main.cpp (exercise 6.10)
Description:
	* Solutions to problems a-f.
*/

#include <iostream>
#include "Circle.hpp"
#include "Line.hpp"
#include "PrintVisitor.hpp"
#include "Point.hpp"
#include "Shape.hpp"
#include "ShapeVisitor.hpp"
#include "ShapeComposite.hpp"
#include "TranslateVisitor.hpp"

int main()
{
	// Create instances of PrintVisitor and TranslateVisitor:
	std::shared_ptr<ShapeVisitor> tran(new TranslateVisitor(4.0));
	std::shared_ptr<ShapeVisitor> pv(new PrintVisitor());
	// Create Shape instances:
	std::shared_ptr<Shape> p1(new Point(4.0, 5.0));
	std::shared_ptr<Shape> l1(new Line(Point(12.0, 4.0), Point(17.0, 3.0)));
	std::shared_ptr<Shape> c1(new Circle(Point(3.0, 10.0), 4.0));
	ShapeComposite sc;
	sc.AddShape(p1);
	sc.AddShape(l1);
	sc.AddShape(c1);

	// Use TranslateVisitor on ShapeComposite:
	std::cout << "ShapeComposite: "; sc.Print(); std::cout << std::endl;
	sc.Accept(tran);
	std::cout << "ShapeComposite (following translate by 4): "; sc.Print(); std::cout << std::endl;
	
	// Use PrintVisitor on ShapeComposite:
	sc.Accept(pv); std::cout << std::endl;
	
	system("pause");

	return 0;
}