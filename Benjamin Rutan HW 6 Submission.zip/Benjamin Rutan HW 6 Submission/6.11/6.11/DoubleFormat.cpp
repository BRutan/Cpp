/* DoubleFormat.cpp (exercise 6.11)
Description:
	* Displays data in Counter as a double floating point.
Class Members:
	// Data:
	* int value: current DoubleFormat value.
	// Constructors/Destructor:
	* DoubleFormat(): Default constructor.
	* DoubleFormat(const DoubleFormat&): Copy constructor.
	* ~DoubleFormat(): Destructor.
	// Misc Methods:
	* void Update(Subject&) const: Update the subject.
	// Overloaded Operators:
	* DoubleFormat& operator=(const DoubleFormat&): Assignment operator.
*/

#include <iomanip>
#include <iostream>
#include <memory>
#include "DoubleFormat.hpp"
#include "Observer.hpp"

///////////////////////////
// Constructor/Destructor:
///////////////////////////
DoubleFormat::DoubleFormat() noexcept : counter_data(nullptr)								/* Default constructor. */
{

}
DoubleFormat::DoubleFormat(const DoubleFormat &df) noexcept	: counter_data(df.counter_data)	/* Copy constructor. */
{

}
DoubleFormat::~DoubleFormat() noexcept													/* Destructor. */
{

}
///////////////////////////
// Misc Methods:
///////////////////////////
void DoubleFormat::Update(Subject *subj_in) noexcept									/* Update the subject. */
{
	this->counter_data = subj_in;
}
///////////////////////////
// Overloaded Operators:
///////////////////////////
DoubleFormat& DoubleFormat::DoubleFormat::operator=(const DoubleFormat &in) noexcept	/* Assignment operator. */
{
	if (this != &in)
	{
		this->counter_data = in.counter_data;
	}
	return *this;
}