/* DoubleFormat.hpp (exercise 6.11)
Description:
	* Displays data in Counter as a double floating point.
Class Members:
	// Data:
	* shared_ptr<Subject> stored_subj: Current attached-to subject.
	// Constructors/Destructor:
	* DoubleFormat(): Default constructor.
	* DoubleFormat(shared_ptr<Subject> subj_in *subj_in) noexcept: Overloaded Constructor. Set the stored_subj and attach to.
	* DoubleFormat(const DoubleFormat&): Copy constructor.
	* ~DoubleFormat(): Destructor.
	// Misc Methods:
	* void Update(Subject&) const: Update the subject.
	// Overloaded Operators:
	* DoubleFormat& operator=(const DoubleFormat&): Assignment operator.
*/

#ifndef DOUBLEFORMAT_HPP
#define DOUBLEFORMAT_HPP

#include <iomanip>
#include <iostream>
#include <memory>
#include "Observer.hpp"

class Subject;

class DoubleFormat : public Observer
{
private:
	std::shared_ptr<Subject> stored_subj;		/* Current attached - to subject. */
public:
	///////////////////////////
	// Constructor/Destructor:
	///////////////////////////
	DoubleFormat() noexcept;						/* Default constructor. */
	DoubleFormat(DoubleFormat*) noexcept;			/* Copy constructor with pointers. */
	DoubleFormat(std::shared_ptr<Subject>&) noexcept;				/* Overloaded Constructor. Set the stored_subj and attach to. */
	DoubleFormat(const DoubleFormat&) noexcept;		/* Copy constructor. */
	virtual ~DoubleFormat() noexcept;				/* Destructor. */
	///////////////////////////
	// Misc Methods:
	///////////////////////////
	virtual void Update(Subject*) noexcept;			/* Update the subject. */
	///////////////////////////
	// Overloaded Operators:
	///////////////////////////
	DoubleFormat& operator=(const DoubleFormat&) noexcept;	/* Assignment operator. */
};

#endif
