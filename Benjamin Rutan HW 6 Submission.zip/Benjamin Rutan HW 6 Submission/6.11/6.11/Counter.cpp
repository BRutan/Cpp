/* Counter.cpp (exercise 6.11)
Description:
	* Derived Subject class that increments or decrements a counter variable.
Class Members:
	// Data:
	* int value: current counter value.
	// Constructors/Destructor:
	* Counter(): Default constructor. Set counter to 0.
	* Counter(const Counter&): Copy counter object.
	* ~Counter(): Destructor.
	// Misc Methods:
	* int GetCounter() const: Return current counter.
	* void IncreaseCounter(): Increase counter by 1.
	* void DecreaseCounter(): Decrease counter by 1.
	// Overloaded Operators:
	* Counter& operator=(const Counter&): Assignment operator.
*/

#include "Counter.hpp"
#include "Subject.hpp"

///////////////////////////
// Constructor/Destructor:
///////////////////////////
Counter::Counter() noexcept	: value(0)		/* Default constructor. Set counter to 0.*/
{

}
Counter::Counter(const Counter &in) noexcept : value(in.value) /* Copy constructor. */
{

}
Counter::~Counter() noexcept				/* Destructor. */
{

}
///////////////////////////
// Misc Methods:
///////////////////////////
int Counter::GetCounter() const noexcept		/* Return the current counter. */
{
	return value;
}
void Counter::IncreaseCounter() noexcept		/* Increase the counter by 1. */
{
	value++;
}
void Counter::DecreaseCounter() noexcept		/* Decrease the counter by 1. */
{
	value--;
}
///////////////////////////
// Overloaded Operators:
///////////////////////////
Counter& Counter::operator=(const Counter &in) noexcept	/* Assignment operator.*/
{
	if (this != &in)
	{
		this->value = in.value;
	}
	return *this;
}