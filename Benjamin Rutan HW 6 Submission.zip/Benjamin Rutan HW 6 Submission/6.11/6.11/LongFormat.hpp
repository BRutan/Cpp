/* LongFormat.hpp (exercise 6.11)
Description:
	* Abstract base class, to be derived in classes that observe data.
Class Members:
	// Data:
	* int value: current LongFormat value.
	// Constructors/Destructor:
	* LongFormat(): Default constructor.
	* LongFormat(const LongFormat&): Copy constructor.
	* ~LongFormat(): Destructor.
	// Misc Methods:
	* void Update(Subject*): Update the subject.
	// Overloaded Operators:
	* LongFormat& operator=(const LongFormat&): Assignment operator.
*/

#ifndef LONGFORMAT_HPP
#define LONGFORMAT_HPP

#include <cmath>
#include <iomanip>
#include <iostream>
#include <memory>
#include "Counter.hpp"
#include "Observer.hpp"

class LongFormat : public Observer
{
private:
	std::shared_ptr<Subject> counter_data;
public:
	///////////////////////////
	// Constructor/Destructor:
	///////////////////////////
	LongFormat() noexcept;						/* Default constructor. */
	LongFormat(const LongFormat&) noexcept;		/* Copy constructor. */
	virtual ~LongFormat() noexcept;				/* Destructor. */
	///////////////////////////
	// Misc Methods:
	///////////////////////////
	virtual void Update(Subject*) noexcept;	/* Update the subject. */
	///////////////////////////
	// Overloaded Operators:
	///////////////////////////
	LongFormat& operator=(const LongFormat&) noexcept;	/* Assignment operator. */
	friend std::ostream& operator<<(std::ostream &out, const LongFormat &in)
	{
		// Display counter using integer format:
		out << "Long Format display - counter: " << std::setprecision(0) << in.counter_data;
		return out;
	}
};

#endif