/* LongFormat.cpp (exercise 6.11)
Description:
	* Displays counter as a long integer..
Class Members:
	// Data:
	* int value: current LongFormat value.
	// Constructors/Destructor:
	* LongFormat(): Default constructor.
	* LongFormat(const LongFormat&): Copy constructor.
	* ~LongFormat(): Destructor.
	// Misc Methods:
	* void Update(Subject*): Update the subject.
	// Overloaded Operators:
	* LongFormat& operator=(const LongFormat&): Assignment operator.
*/

#include "LongFormat.hpp"
#include "Observer.hpp"

///////////////////////////
// Constructor/Destructor:
///////////////////////////
LongFormat::LongFormat() noexcept : counter_data(nullptr) 							/* Default constructor. */
{

}
LongFormat::LongFormat(const LongFormat &in) noexcept : counter_data(in.counter_data)			/* Copy constructor. Copy counter of passed object. */
{

}
LongFormat::~LongFormat() noexcept		    						/* Destructor. */
{

}
///////////////////////////
// Misc Methods:
///////////////////////////
void LongFormat::Update(Subject *subj_in) noexcept			/* Update the subject. */
{
	// Display as Long format:
	std::cout << std::setprecision(0) << std::round(((Counter*)subj_in)->GetCounter()) << std::endl;
}
///////////////////////////
// Overloaded Operators:
///////////////////////////
LongFormat& LongFormat::operator=(const LongFormat &lf_in) noexcept	/* Assignment operator. */
{
	if (this != &lf_in)
	{
		this->counter_data = lf_in.counter_data;
	}
	return *this;
}