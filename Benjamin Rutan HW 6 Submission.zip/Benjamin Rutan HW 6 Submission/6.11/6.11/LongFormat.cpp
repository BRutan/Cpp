/* LongFormat.cpp (exercise 6.11)
Description:
	* Displays counter as a long integer..
Class Members:
	// Data:
	* shared_ptr<Subject> stored_subj: Current attached-to subject.
	// Constructors/Destructor:
	* LongFormat(): Default constructor.
	* LongFormat(Subject*): Overloaded constructor. Set stored_subj and become attached to subject.
	* LongFormat(const LongFormat&): Copy constructor.
	* ~LongFormat(): Destructor.
	// Misc Methods:
	* void Update(Subject*): Update the subject.
	// Overloaded Operators:
	* LongFormat& operator=(const LongFormat&): Assignment operator.
*/

#include "LongFormat.hpp"
#include "Observer.hpp"
#include "Subject.hpp"
#include "Counter.hpp"

///////////////////////////
// Constructor/Destructor:
///////////////////////////
LongFormat::LongFormat() noexcept : stored_subj(nullptr)				/* Default constructor. */
{

}
LongFormat::LongFormat(std::shared_ptr<Subject> &subj_in) noexcept: stored_subj(subj_in.get())			/* Overloaded Constructor. Set stored_subj and attach. */
{
	// Attach to subject:
	std::shared_ptr<Observer> temp = std::make_shared<LongFormat>(this);
	subj_in->Attach(temp);
}
LongFormat::LongFormat(const LongFormat &in) noexcept : stored_subj(in.stored_subj) 	/* Copy constructor. Copy counter of passed object. */
{

}
LongFormat::LongFormat(LongFormat *in) noexcept : stored_subj(in->stored_subj)			/* Copy constructor with pointers. */
{

}
LongFormat::~LongFormat() noexcept		    							/* Destructor. */
{

}
///////////////////////////
// Misc Methods:
///////////////////////////
void LongFormat::Update(Subject *subj_in) noexcept			/* Update the subject. */
{
	// Display as Long format:
	if (subj_in == &(*stored_subj))
	{
		std::cout << std::setprecision(2) << std::dynamic_pointer_cast<Counter, Subject>(this->stored_subj)->GetCounter() << std::endl;
	}
}
///////////////////////////
// Overloaded Operators:
///////////////////////////
LongFormat& LongFormat::operator=(const LongFormat &lf_in) noexcept	/* Assignment operator. */
{
	if (this != &lf_in)
	{
		this->stored_subj.reset(lf_in.stored_subj.get());
	}
	return *this;
}