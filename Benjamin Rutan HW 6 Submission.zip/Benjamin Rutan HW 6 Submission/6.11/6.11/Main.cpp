/*


*/


#include <iostream>
#include "Counter.hpp"
#include "DoubleFormat.hpp"
#include "LongFormat.hpp"
#include "Observer.hpp"
#include "Subject.hpp"

int main()
{
	// f) Test the Subject and Observer classes:

	Counter count;
	std::shared_ptr<Observer> obs1(new LongFormat());
	std::shared_ptr<Observer> obs2(new DoubleFormat());
	// Attach to counter:
	count.Attach(obs1);
	count.Attach(obs2);
	count.IncreaseCounter();
	// Update the subject:
	count.

	

	system("pause");

	return 0;
}