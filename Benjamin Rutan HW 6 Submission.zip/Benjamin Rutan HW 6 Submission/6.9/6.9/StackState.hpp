/* StackState.hpp (exercise 6.9)
Description:
	* Base class for derived states of Stack object (EmptyState, NotFullNotEmptyState, FullState).
 Class Members:
	// Constructors/Destructor:
	* StackState(): Default constructor.
	* StackState(const StackState&): Copy constructor.
	* ~StackState(): Destructor
	// Misc. Methods:
	* void Push(Stack&, double): Push new element onto passed stack.
	* double Pop(Stack&): Remove top element from passed stack.
	// Overloaded Operators:
	* StackState& operator=(const StackState&): Assignment operator.
*/

#ifndef STACKSTATE_HPP
#define STACKSTATE_HPP

#include <memory>

class Stack;

class StackState
{
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	StackState() noexcept;						/* Default constructor. */
	StackState(const StackState&) noexcept;		/* Copy constructor. */
	virtual ~StackState() noexcept;				/* PVMF to make class abstract. */
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	virtual void Push(Stack&, double) = 0;			/* PVMF. Push element onto stack. */
	virtual double Pop(Stack&) const = 0;					/* PVMF. Remove element from stack and return. */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	StackState& operator=(const StackState&) noexcept;	/* Assignment operator. */
};

#endif
