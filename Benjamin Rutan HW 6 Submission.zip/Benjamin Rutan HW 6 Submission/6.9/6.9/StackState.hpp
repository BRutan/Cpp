/* StackState.hpp (exercise 6.9)
Description:
	*
 Class Members:




*/



#ifndef STACKSTATE_HPP
#define STACKSTATE_HPP

template<typename T>
class StackState
{
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	StackState() noexcept;
	StackState(const StackState&) noexcept;
	virtual ~StackState() noexcept;
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	void Push(const T&);
	T& Pop() const;
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	StackState& operator=(const StackState&) noexcept;
};


#endif
