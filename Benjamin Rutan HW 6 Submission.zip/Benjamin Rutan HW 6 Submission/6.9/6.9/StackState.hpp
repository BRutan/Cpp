/* StackState.hpp (exercise 6.9)
Description:
	* Base class for derived states of Stack object (EmptyState, NotFullNotEmptyState, FullState).
 Class Members:
	// Constructors/Destructor:
	* StackState(): Default constructor.
	* StackState(const StackState&): Copy constructor.
	* ~StackState(): Destructor
	// Misc. Methods:
	* void Push(Stack<T>&, const T&): Push new element onto passed stack.
	* T Pop(Stack<T>&): Remove top element from passed stack.
	// Overloaded Operators:
	* StackState& operator=(const StackState&): Assignment operator.
*/

#ifndef STACKSTATE_HPP
#define STACKSTATE_HPP

#include <memory>
#include "Singleton.hpp"

template<typename T>
class Stack;

template<typename T>
class StackState
{
protected:
	friend class Stack<T>;						/* Allow StackState to mutate and return elements of Stack. */
	virtual void ChangeState(std::shared_ptr<Stack>, Singleton<StackState> newState) = 0; /* Change state of passed Stack. */
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	StackState() noexcept;						/* Default constructor. */
	StackState(const StackState&) noexcept;		/* Copy constructor. */
	virtual ~StackState() noexcept;				/* PVMF to make class abstract. */
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	void Push(Stack<T>&, const T&) = 0;			/* PVMF. Push element onto stack. */
	T Pop(Stack<T>&) const = 0;					/* PVMF. Remove element from stack and return. */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	StackState& operator=(const StackState&) noexcept;	/* Assignment operator. */
};

#include "StackState.cpp"

#endif
