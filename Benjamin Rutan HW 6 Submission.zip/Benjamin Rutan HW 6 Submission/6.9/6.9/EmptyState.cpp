/* EmptyState.cpp (exercise 6.9)
Description:
	* Derived StackState class, signifying that stack is empty and altering behavior on Push() / Pop() operations.
Class Members:
	// Constructors/Destructor:
	* EmptyState(): Default constructor.
	* EmptyState(const EmptyState&): Copy constructor.
	* ~EmptyState(): Destructor
	// Misc. Methods:
	* void Push(Stack<T>&, const T&): Push new element onto passed stack.
	* T Pop(Stack<T>&): Throw exception since no elements to remove.
	// Overloaded Operators:
	* EmptyState& operator=(const EmptyState&): Assignment operator.
*/

#include "EmptyState.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
template<typename T>
EmptyState::EmptyState() noexcept										/* Default constructor. */
{

}
template<typename T>
EmptyState::EmptyState(const EmptyState &in) noexcept					/* Copy constructor. */
{

}
template<typename T>
virtual EmptyState::~EmptyState() noexcept								/* Destructor. */
{

}
////////////////////////////
// Misc Methods:
////////////////////////////
template<typename T>
void EmptyState::Push(Stack<T> &stack_in, const T &in) noexcept							/* Push new element onto stack. */
{
	// Push new element onto stack:
	StackState::Push(stack_in, in);
}
template<typename T>
T& EmptyState::Pop(Stack<T> &stack_in) const											/* Throw exception since no elements to pop. */
{
	// Throw exception since cannot pop element off of empty stack:
	throw std::out_of_range("Cannot call Stack::Pop(): Stack is empty.");
}
////////////////////////////
// Overloaded Operators:
////////////////////////////
template<typename T>
EmptyState& EmptyState::operator=(const EmptyState &in) noexcept						/* Assignment operator. Do nothing since class has no state variables. */
{
	if (this != &in)
	{

	}
	return *this;
}