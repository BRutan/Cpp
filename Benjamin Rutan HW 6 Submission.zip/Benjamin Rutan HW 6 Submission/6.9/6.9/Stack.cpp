/* Stack.hpp (exercise 6.9) (define inline)
Description:
	* Template LIFO stack using StackState polymorphism and heap storage for items.
Class Members:
	// Data:
	* double*items[]: Data to store.
	* StackState *state: In {EmptyState, FullState, NotFullNotEmptyState} to delegate further functionality.
	* size_t currIndex, size: Current index of top item, and total size.
	* void Init(size_t):
	// Constructors/Destructor:
	* Stack(): Default constructor. Set size to 1 and default construct items.
	* ~Stack(): Destructor. Free memory allocated in items.
	// Misc Methods:
	* void Push(double): Push copy of new item onto Stack.
	* doublePop(): Remove and return item at currIndex from Stack.
	// Overloaded Operators:
	* Stack& operator=(const Stack&): Assignment operator. Deep copy all items of passed Stack into this Stack.
*/


#include "StackState.hpp"
#include "EmptyState.hpp"
#include "Stack.hpp"

////////////////////////////
// Private functions:
////////////////////////////

void Stack::Init(int size_in)				/* Initialize the Stack, setting size, currIndex (to 0) and state to EmptyState. */
{
	if (size_in < 1)
	{
		this->size = 1;
	}
	else
	{
		this->size = size_in;
	}
	currIndex = 0;
	this->items = new double[size];
	std::shared_ptr<StackState> temp(new EmptyState());
	this->state = temp;
}
////////////////////////////
// Constructors/Destructor:
////////////////////////////
Stack::Stack() noexcept					/* Default constructor. Set size of items[] to 1, currIndex to 0 and stack_state to EmptyState. */
{
	this->Init(1);
}
Stack::Stack(std::size_t size_in) noexcept	/* Overloaded constructor. Set size of items[] to passed index, currIndex to 0 and state_state to EmptyState. */
{
	this->Init(size_in);
}
Stack::Stack(const Stack &stack_in) noexcept : items(new double[stack_in.size])
{
	
}
Stack::~Stack() noexcept			/* Destructor. Free memory via calling shared_ptr destructor. */
{

}
////////////////////////////
// Misc. Methods:
////////////////////////////

void Stack::Push(double data_in)				/* Push new element into items. */
{
	// Call Push method of state (which handles Push operation, and may throw exception):
	state->Push(*this, data_in);
}

double Stack::Pop()									/* Pop top element off of stack. */
{
	// Test the Pop method of state (which handles Pop operator, and may throw exception):
	return state->Pop(*this);
}
////////////////////////////
// Overloaded Operators:
////////////////////////////

Stack& Stack::operator=(const Stack &in) noexcept	/* Assignment operator. Deep copy all elements in items from passed Stack into this stack. */
{
	if (this != &in)
	{
		
	}
	return *this;
}