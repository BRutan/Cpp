/* Stack.hpp (exercise 6.9) (define inline)
Description:
	* Template LIFO stack using StackState polymorphism and heap storage for items.
Class Members:
	// Data:
	* T *items[]: Data to store.
	* StackState *state: In {EmptyState, FullState, NotFullNotEmptyState} to delegate further functionality.
	* size_t currIndex, size: Current index of top item, and total size.
	* void Init(size_t):
	// Constructors/Destructor:
	* Stack(): Default constructor. Set size to 1 and default construct items.
	* ~Stack(): Destructor. Free memory allocated in items.
	// Misc Methods:
	* void Push(const T&): Push copy of new item onto Stack.
	* T Pop(): Remove and return item at currIndex from Stack.
	// Overloaded Operators:
	* Stack& operator=(const Stack&): Assignment operator. Deep copy all items of passed Stack into this Stack.
*/


#include "Stack.hpp"


////////////////////////////
// Private functions:
////////////////////////////
template<typename T>
void Stack::Init(int size_in)				/* Initialize the Stack, setting size, currIndex (to 0) and state to EmptyState. */
{
	if (size_in < 1)
	{
		this->size = 1;
	}
	else
	{
		this->size = size_in;
	}
	currIndex = 0;
	this->items.get() = new T[size];
	this->state.get() = new EmptyState();
}
////////////////////////////
// Constructors/Destructor:
////////////////////////////
template<typename T>
Stack::Stack() noexcept					/* Default constructor. Set size of items[] to 1, currIndex to 0 and stack_state to EmptyState. */
{
	this->Init(1);
}
template<typename T>
Stack::Stack(std::size_t size_in) noexcept	/* Overloaded constructor. Set size of items[] to passed index, currIndex to 0 and state_state to EmptyState. */
{
	this->Init(size_in);
}
template<typename T>
Stack::Stack(const Stack &stack_in) noexcept : items(new T[stack_in.size](stack_in.items))
{

}
template<typename T>
Stack::~Stack() noexcept			/* Destructor. Free memory via calling shared_ptr destructor. */
{

}
////////////////////////////
// Misc. Methods:
////////////////////////////
template<typename T>
void Stack::Push(const T& data_in)				/* Push new element into items. */
{
	// Call Push method of state (which handles Push operation, and may throw exception):
	state.get()->Push(data_in);
	// If at maximum capacity following Push operation, change state to FullState:
	if (this->currIndex = this->size - 1)
	{
		// Delete singleton, replace with FullState:
		this->state.des.~Destroyer;
		this->state.ins = new FullState();
	}
	else if (typeid(*state.ins) == EmptyState)
	{
		// If previously in EmptyState, set state to NotFullNotEmptyState:
		this->state.des.~Destroyer();
		this->state.ins = new NotFullNotEmptyState();
	}
}
template<typename T>
T Stack::Pop()									/* Pop top element off of stack. */
{
	// Test the Pop method of state (which handles Pop operator, and may throw exception):
	T temp = this->state.ins->Pop();
	// If no elements remaining, then set state to EmptyState:
	if (currIndex = -1)
	{
		// Delete singleton, replace with EmptyState:
		this->state.des.~Destroyer();
		this->state.ins = new EmptyState();
	}
	else if (typeid(*state.ins) == FullState)
	{
		// If was previously full, set to NotFullNotEmptyState:
		this->state.des.~Destroyer();
		this->state.ins = new NotFullNotEmptyState();
	}
	return temp;
}
////////////////////////////
// Overloaded Operators:
////////////////////////////
template<typename T>
Stack& Stack::operator=(const Stack &in) noexcept	/* Assignment operator. Deep copy all elements in items from passed Stack into this stack. */
{
	if (this != &in)
	{
		this->items.get()->;
		this->items = in.items;
	}
	return *this;
}