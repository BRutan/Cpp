/* FullState.hpp (exercise 6.9)
Description:
	* Derived StackState class, signifying that stack is full and altering behavior on Push() / Pop() operations.
Class Members:
	// Constructors/Destructor:
	* FullState(): Default constructor.
	* FullState(const FullState&): Copy constructor.
	* ~FullState(): Destructor
	// Misc. Methods:
	* void Push(Stack&, double): Push new element onto passed stack.
	* double Pop(Stack&): Throw exception since no elements to remove.
	// Overloaded Operators:
	* FullState& operator=(const FullState&): Assignment operator.
*/

#ifndef FULLSTATE_HPP
#define FULLSTATE_HPP

#include <stdexcept>
#include "StackState.hpp"

class Stack;

class FullState : public StackState
{
public:
	friend class ::Stack;
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	FullState() noexcept;						/* Default constructor. */
	FullState(const FullState &in) noexcept;	/* Copy constructor. */
	virtual ~FullState() noexcept;				/* Destructor.*/
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	virtual void Push(Stack &stack_in, double data_in);	/* Throw exception since cannot add any more elements.*/
	virtual double Pop(Stack &stack_in) const noexcept;			/* Pop top element from stack. */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	FullState& operator=(const FullState &in) noexcept;	/* Assignment operator. */
};

#endif
