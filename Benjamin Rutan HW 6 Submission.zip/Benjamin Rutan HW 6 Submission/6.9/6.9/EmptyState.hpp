/* EmptyState.hpp (exercise 6.9)
Description:
	*
Class Members:
	// 

	//
	
	//


*/

#ifndef EMPTYSTATE_HPP
#define EMPTYSTATE_HPP

#include "StackState.hpp"

template<typename T>
class EmptyState
{


};


#endif