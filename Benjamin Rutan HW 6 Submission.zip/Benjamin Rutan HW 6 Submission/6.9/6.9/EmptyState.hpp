/* EmptyState.cpp (exercise 6.9)
Description:
	* Derived StackState class, signifying that stack is empty and altering behavior on Push() / Pop() operations.
Class Members:
	// Constructors/Destructor:
	* EmptyState(): Default constructor.
	* EmptyState(const EmptyState&): Copy constructor.
	* ~EmptyState(): Destructor
	// Misc. Methods:
	* void Push(Stack<T>&, const T&): Push new element onto passed stack.
	* T Pop(Stack<T>&): Throw exception since no elements to remove.
	// Overloaded Operators:
	* EmptyState& operator=(const EmptyState&): Assignment operator.
*/

#ifndef EMPTYSTATE_HPP
#define EMPTYSTATE_HPP

#include <stdexcept>
#include "Stack.hpp"
#include "StackState.hpp"

template<typename T>
class EmptyState : public StackState
{	
public:	
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	EmptyState() noexcept;										/* Default constructor. */
	EmptyState(const EmptyState &in) noexcept;					/* Copy constructor. */
	virtual ~EmptyState() noexcept;								/* Destructor. */
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	void Push(Stack<T> &stack_in, const T &in) noexcept;		/* Push new element onto stack. */
	T& Pop(Stack<T> &stack_in) const;							/* Throw exception since no elements to pop. */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	EmptyState& operator=(const EmptyState &in) noexcept;		/* Assignment operator. Do nothing since class has no state variables. */
};

#include "EmptyState.cpp"

#endif