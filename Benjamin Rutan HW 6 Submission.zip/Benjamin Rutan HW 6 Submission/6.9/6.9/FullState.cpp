/* FullState.hpp (exercise 6.9)
Description:
	* Derived StackState class, signifying that stack is full and altering behavior on Push() / Pop() operations.
Class Members:
	// Constructors/Destructor:
	* FullState(): Default constructor.
	* FullState(const FullState&): Copy constructor.
	* ~FullState(): Destructor
	// Misc. Methods:
	* void Push(Stack<T>&, const T&): Push new element onto passed stack.
	* T Pop(Stack<T>&): Throw exception since no elements to remove.
	// Overloaded Operators:
	* FullState& operator=(const FullState&): Assignment operator.
*/

#include "FullState.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
template<typename T>
FullState::FullState() noexcept							/* Default constructor. */
{

}
template<typename T>
FullState::FullState(const FullState &in) noexcept		/* Copy constructor. */
{

}
template<typename T>
FullState::~FullState() noexcept						/* Destructor. */
{

}
////////////////////////////
// Misc Methods:
////////////////////////////
template<typename T>
void FullState::Push(Stack<T> &stack_in, const T &data_in)	/* Throw exception since cannot add any more elements to stack. */
{
	// Throw exception since cannot add any more data to full stack:
	throw std::out_of_range("Cannot call Stack::Push(): Stack is full.");
}
template<typename T>
T& FullState::Pop(Stack<T> &stack_in) const noexcept			/* Remove top element from stack. */
{
	return StackState::Pop(stack_in);
}
////////////////////////////
// Overloaded Operators:
////////////////////////////
template<typename T>
FullState& FullState::operator=(const FullState &in) noexcept	/* Assignment operator. */
{
	if (this != &in)
	{

	}
	return *this;
}