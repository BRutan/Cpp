/* NotFullNotEmptyState.cpp (exercise 6.9)
Description:
	* Derived StackState class, signifying that stack is neither empty not full, allowing both Push() and Pop() operations.
Class Members:
	// Constructors/Destructor:
	* NotFullNotEmptyState(): Default constructor.
	* NotFullNotEmptyState(const NotFullNotEmptyState&): Copy constructor.
	* ~NotFullNotEmptyState(): Destructor
	// Misc. Methods:
	* void Push(Stack<T>&, const T&): Push new element onto passed stack.
	* T Pop(Stack<T>&): Pop top element from stack.
	// Overloaded Operators:
	* NotFullNotEmptyState& operator=(const NotFullNotEmptyState&): Assignment operator.
*/

#ifndef NOTFULLNOTEMPTYSTATE_HPP
#define NOTFULLNOTEMPTYSTATE_HPP

#include "StackState.hpp"

template<typename T>
class NotFullNotEmptyState : public StackState
{
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	NotFullNotEmptyState() noexcept;									/* Default constructor. */
	NotFullNotEmptyState(const NotFullNotEmptyState &in) noexcept;		/* Copy constructor. */
	virtual ~NotFullNotEmptyState() noexcept;							/* Destructor. */
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	void Push(Stack<T> &stack_in, const T &value) noexcept;				/* Push new element onto stack. */
	T& Pop(Stack<T> &stack_in) const noexcept;							/* Remove top element from stack. */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	NotFullNotEmptyState& operator=(const NotFullNotEmptyState &in) noexcept;	/* Assignment operator. */
};



#endif
