/* NotFullNotEmptyState.cpp (exercise 6.9)
Description:
	* Derived StackState class, signifying that stack is neither empty not full, allowing both Push() and Pop() operations.
Class Members:
	// Constructors/Destructor:
	* NotFullNotEmptyState(): Default constructor.
	* NotFullNotEmptyState(const NotFullNotEmptyState&): Copy constructor.
	* ~NotFullNotEmptyState(): Destructor
	// Misc. Methods:
	* void Push(Stack&, double): Push new element onto passed stack.
	* double Pop(Stack&): Pop top element from stack.
	// Overloaded Operators:
	* NotFullNotEmptyState& operator=(const NotFullNotEmptyState&): Assignment operator.
*/

#ifndef NOTFULLNOTEMPTYSTATE_HPP
#define NOTFULLNOTEMPTYSTATE_HPP

#include <stdexcept>

class Stack;
class StackState;

class NotFullNotEmptyState : public StackState
{
private:
	friend class Stack;
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	NotFullNotEmptyState() noexcept;									/* Default constructor. */
	NotFullNotEmptyState(const NotFullNotEmptyState &in) noexcept;		/* Copy constructor. */
	virtual ~NotFullNotEmptyState() noexcept;							/* Destructor. */
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	void Push(Stack &stack_in, double value) noexcept;				/* Push new element onto stack. */
	double Pop(Stack &stack_in) const noexcept;							/* Remove top element from stack. */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	NotFullNotEmptyState& operator=(const NotFullNotEmptyState &in) noexcept;	/* Assignment operator. */
};


#endif
