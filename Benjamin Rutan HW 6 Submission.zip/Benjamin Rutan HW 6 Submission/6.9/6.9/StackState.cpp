/* StackState.cpp (exercise 6.9)
Description:
	* Base class for derived states of Stack object (EmptyState, NotFullNotEmptyState, FullState).
Class Members:
	// Constructors/Destructor:
	* StackState(): Default constructor.
	* StackState(const StackState&): Copy constructor.
	* ~StackState(): Destructor
	// Misc. Methods:
	* void Push(Stack<T>&, const T&): Push new element onto passed stack.
	* T Pop(Stack<T>&): Remove top element from passed stack.
	// Overloaded Operators:
	* StackState& operator=(const StackState&): Assignment operator.
*/

#include "StackState.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
template<typename T>
StackState::StackState() noexcept							/* Default constructor. */
{

}
template<typename T>
StackState::StackState(const StackState &in) noexcept		/* Copy constructor. */
{

}
template<typename T>
StackState::~StackState() noexcept							/* Destructor. */
{

}
////////////////////////////
// Misc Methods:
////////////////////////////
template<typename T>
void StackState::Push(Stack<T> &stack_in, const T &data_in)		/* PVMF. Push element onto stack. */
{
	stack_in.items[stack_in.currIndex++] = data_in;
}
template<typename T>
T StackState::Pop(Stack<T> &stack_in) const						/* PVMF. Remove element from stack and return. */
{
	return stack_in.items[--stack_in.currIndex];
}
////////////////////////////
// Overloaded Operators:
////////////////////////////
template<typename T>
StackState& StackState::operator=(const StackState &in) noexcept	/* Assignment operator. */
{
	if (this != &in)
	{

	}
	return *this;
}