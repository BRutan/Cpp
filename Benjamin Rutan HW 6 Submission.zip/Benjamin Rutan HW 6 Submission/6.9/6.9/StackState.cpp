/* StackState.hpp (exercise 6.9)
Description:
	* Base class for derived states of Stack object (EmptyState, NotFullNotEmptyState, FullState).
Class Members:
	// Constructors/Destructor:
	* StackState(): Default constructor.
	* StackState(const StackState&): Copy constructor.
	* ~StackState(): Destructor
	// Misc. Methods:
	* void Push(Stack&, double): Push new element onto passed stack.
	* double Pop(Stack&): Remove top element from passed stack.
	// Overloaded Operators:
	* StackState& operator=(const StackState&): Assignment operator.
*/

#include "Stack.hpp"
#include "StackState.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
StackState::StackState() noexcept							/* Default constructor. */
{

}
StackState::StackState(const StackState &in) noexcept		/* Copy constructor. */
{

}
StackState::~StackState() noexcept							/* Destructor. */
{

}
////////////////////////////
// Misc Methods:
////////////////////////////
void StackState::Push(Stack &stack_in, double data_in)		/* PVMF. Push element onto stack. */
{	
	stack_in.items[stack_in.currIndex++] = data_in;
}
double StackState::Pop(Stack &stack_in) const						/* PVMF. Remove element from stack and return. */
{
	return stack_in.items[--stack_in.currIndex];
}
////////////////////////////
// Overloaded Operators:
////////////////////////////
StackState& StackState::operator=(const StackState &in) noexcept	
{
	if (this != &in)
	{

	}
	return *this;
}