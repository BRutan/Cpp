/* NotFullNotEmptyState.cpp (exercise 6.9)
Description:
	* Derived StackState class, signifying that stack is neither empty not full, allowing both Push() and Pop() operations.
Class Members:
	// Constructors/Destructor:
	* NotFullNotEmptyState(): Default constructor.
	* NotFullNotEmptyState(const NotFullNotEmptyState&): Copy constructor.
	* ~NotFullNotEmptyState(): Destructor
	// Misc. Methods:
	* void Push(Stack<T>&, const T&): Push new element onto passed stack.
	* T Pop(Stack<T>&): Pop top element from stack.
	// Overloaded Operators:
	* NotFullNotEmptyState& operator=(const NotFullNotEmptyState&): Assignment operator.
*/

#include "NotFullNotEmptyState.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
template<typename T>
NotFullNotEmptyState::NotFullNotEmptyState() noexcept								/* Default constructor. */
{

}
template<typename T>
NotFullNotEmptyState::NotFullNotEmptyState(const NotFullNotEmptyState &in) noexcept	/* Copy constructor. */
{

}
template<typename T>
NotFullNotEmptyState::~NotFullNotEmptyState() noexcept								/* Destructor. */
{

}
////////////////////////////
// Misc Methods:
////////////////////////////
template<typename T>
void NotFullNotEmptyState::Push(Stack<T> &stack_in, const T &value) noexcept		/* Push new element onto stack. */
{
	StackState::Push(stack_in, value);
}
template<typename T>
T& NotFullNotEmptyState::Pop(Stack<T> &stack_in) const noexcept						/* Pop top element off of stack. */
{
	return StackState::Pop(stack_in);
}
////////////////////////////
// Overloaded Operators:
////////////////////////////
template<typename T>
NotFullNotEmptyState& NotFullNotEmptyState::operator=(const NotFullNotEmptyState &in) noexcept	/* Assignment operator. */
{
	if (this != &in)
	{

	}
	return *this;
}

