/* NotFullNotEmptyState.cpp (exercise 6.9)
Description:
	* Derived StackState class, signifying that stack is neither empty not full, allowing both Push() and Pop() operations.
Class Members:
	// Constructors/Destructor:
	* NotFullNotEmptyState(): Default constructor.
	* NotFullNotEmptyState(const NotFullNotEmptyState&): Copy constructor.
	* ~NotFullNotEmptyState(): Destructor
	// Misc. Methods:
	* void Push(Stack&, double): Push new element onto passed stack.
	* double Pop(Stack&): Pop top element from stack.
	// Overloaded Operators:
	* NotFullNotEmptyState& operator=(const NotFullNotEmptyState&): Assignment operator.
*/

#include "StackState.hpp"
#include "Stack.hpp"
#include "NotFullNotEmptyState.hpp"
#include "EmptyState.hpp"
#include "FullState.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
NotFullNotEmptyState::NotFullNotEmptyState() noexcept								/* Default constructor. */
{

}

NotFullNotEmptyState::NotFullNotEmptyState(const NotFullNotEmptyState &in) noexcept	/* Copy constructor. */
{

}

NotFullNotEmptyState::~NotFullNotEmptyState() noexcept								/* Destructor. */
{

}
////////////////////////////
// Misc Methods:
////////////////////////////

void NotFullNotEmptyState::Push(Stack &stack_in, double value) noexcept		/* Push new element onto stack. */
{
	StackState::Push(stack_in, value);
	// If stack is now full, change to FullState:
	if (stack_in.currIndex == stack_in.size)
	{
		stack_in.state.reset(new FullState());
	}
}

double NotFullNotEmptyState::Pop(Stack &stack_in) const noexcept						/* Pop top element off of stack. */
{
	auto temp = StackState::Pop(stack_in);
	// Change state to Empty if at first index: 
	if (stack_in.currIndex == 0)
	{
		stack_in.state.reset(new EmptyState());
	}
	return temp;
}
////////////////////////////
// Overloaded Operators:
////////////////////////////

NotFullNotEmptyState& NotFullNotEmptyState::operator=(const NotFullNotEmptyState &in) noexcept	/* Assignment operator. */
{
	if (this != &in)
	{

	}
	return *this;
}

