/* Main.cpp (exericse 6.9)
Description:
	*



*/


#include <iostream>
#include "EmptyState.hpp"
#include "FullState.hpp"
#include "NotFullNotEmptyState.hpp"
#include "Singleton.hpp"
#include "Stack.hpp"
#include "StackState.hpp"

int main()
{
	Stack<double> doubleStack;

	system("pause");

	return 0;
}