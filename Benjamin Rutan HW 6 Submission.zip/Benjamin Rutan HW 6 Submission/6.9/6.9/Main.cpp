/* Main.cpp (exericse 6.9)
Description:
	* Solutions to problems.
*/

#include <iostream>
#include "EmptyState.hpp"
#include "FullState.hpp"
#include "NotFullNotEmptyState.hpp"
#include "StackState.hpp"
#include "Stack.hpp"

int main()
{
	// Make a stack of size 10:
	Stack test(10);
	// Attempt to put more elements onto stack than possible:
	try
	{
		for (double i = 0; i < 11; i++)
		{
			test.Push(i);
		}
	}
	catch (std::out_of_range&)
	{
		std::cout << "Error: Cannot put more than ten items onto stack." << std::endl;
	}

	// Attempt to remove more than ten elements from stack:
	try
	{
		std::cout << "Stack contents: { ";
		for (std::size_t i = 0; i < 11; i++)
		{
			std::cout << test.Pop() << ", ";
		}
	}
	catch (std::out_of_range&)
	{
		std::cout << "\nError: Cannot remove more than ten items from stack. " << std::endl;
	}

	system("pause");

	return 0;
}