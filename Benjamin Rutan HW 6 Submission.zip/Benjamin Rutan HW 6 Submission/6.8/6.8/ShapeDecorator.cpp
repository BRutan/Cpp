/* ShapeDecorator.hpp (exercise 6.8)
Description:
	* Abstract base class for derived decorators.
Class Members:
	// Data:
	* Shape *stored_shape: Polymorphic Shape object to decorate.
	// Constructors/Destructor:
	* ShapeDecorator(): Default constructor. Set stored_shape to NULL.
	* ShapeDecorator(Shape*): Overloaded constructor. Set stored_shape.
	* ~ShapeDecorator(): Destructor.
	// Accessors:
	* Shape* GetShape() const: Get stored Shape object. To be overwritten in derived classes.
	// Mutators:
	* void SetShape(Shape*): Return stored Shape object.
	// Overloaded Operators:
	* ShapeDecorator& operator=(const ShapeDecorato&) = delete: Deleted assignment operator. Do not want to share ownership of heap-stored Shape object
*/


#include "ShapeDecorator.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
ShapeDecorator::ShapeDecorator() noexcept											/* Default constructor. Set stored_shape to NULL. */
{

}
ShapeDecorator::ShapeDecorator(std::shared_ptr<Shape> &shape_in) noexcept : stored_shape(shape_in)	/* Overloaded constructor. Set the Shape to decorate. */
{

}
ShapeDecorator::~ShapeDecorator() noexcept											/* Destructor. */
{
	// Release ownership of Shape object:
	stored_shape.reset();
}
////////////////////////////
// Accessors:
////////////////////////////
std::shared_ptr<Shape> ShapeDecorator::GetShape() const noexcept	/* PVMF to be overwritten in derived classes. Get stored Shape object. */
{
	return this->stored_shape;
}
////////////////////////////
// Mutators:
////////////////////////////
void ShapeDecorator::SetShape(std::shared_ptr<Shape> &in) noexcept
{
	this->stored_shape = in;
}
////////////////////////////
// Overloaded Operators:
////////////////////////////
ShapeDecorator& ShapeDecorator::operator=(ShapeDecorator &in) noexcept
{
	if (this != &in)
	{
		this->stored_shape = in.stored_shape;
	}
	return *this;
}