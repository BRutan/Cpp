/* Main.cpp (exercise 6.8)
Description:
	*


*/


#include <iostream>


int main()
{

	system("pause");

	return 0;
}