/* NameDecorator.cpp (exercise 6.8)
Description:
	* Derived ShapeDecorator class that gives shape a string name.
Class Members:
	// Constructors/Destructor:
	* NameDecorator(): Default constructor. Set stored_shape to NULL.
	* NameDecorator(Shape*): Overloaded constructor. Set stored_shape.
	* ~NameDecorator(): Destructor.
	// Accessors:
	* Shape* GetShape() const: Get stored Shape object.
	// Mutators:
	* void SetShape(Shape*): Return stored Shape object.
	// Overloaded Operators:
	* NameDecorator& operator=(const NameDecorator&) = delete: Deleted assignment operator. Do not want to share ownership of heap-stored Shape object
*/

#include <memory>
#include <string>
#include "NameDecorator.hpp"
#include "ShapeDecorator.hpp"
#include "Shape.hpp"

/////////////////////////////
// Constructors/Destructor:
/////////////////////////////
NameDecorator::NameDecorator() noexcept : name(), ShapeDecorator()			/* Default constructor. Set base Shape member to NULL and name to empty string. */
{

}
NameDecorator::NameDecorator(Shape* shape_in, const std::string &name_in) noexcept : name(name_in), ShapeDecorator(shape_in) /* Overloaded constructor. Set base Shape member and name. */
{

}
NameDecorator::~NameDecorator() noexcept									/* Destructor. */
{

}
/////////////////////////////
// Accessors:
/////////////////////////////
std::shared_ptr<Shape*> NameDecorator::GetShape() const noexcept			/* Return smart pointer to stored Shape base object. */
{
	return ShapeDecorator::GetShape();
}
/////////////////////////////
// Mutators:
/////////////////////////////
void NameDecorator::SetShape(Shape* shape_in) noexcept						/* Set Shape member. */
{
	ShapeDecorator::SetShape(shape_in);
}
/////////////////////////////
// Misc Methods:
/////////////////////////////
Shape* NameDecorator::Clone() const noexcept										/* Clone the current derived Shape object. */
{
	return this;
}


