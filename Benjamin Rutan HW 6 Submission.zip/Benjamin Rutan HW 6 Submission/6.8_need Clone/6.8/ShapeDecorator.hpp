/* ShapeDecorator.hpp (exercise 6.8)
Description:
	* Abstract base class for derived decorators.
Class Members:
	// Data:
	* Shape *stored_shape: Polymorphic Shape object to decorate.
	// Constructors/Destructor:
	* ShapeDecorator(): Default constructor. Set stored_shape to NULL.
	* ShapeDecorator(Shape*): Overloaded constructor. Set stored_shape. 
	* ~ShapeDecorator(): Destructor.
	// Accessors:
	* Shape* GetShape() const: Get stored Shape object. To be overwritten in derived classes.
	// Mutators:
	* void SetShape(Shape*): Return stored Shape object.
	// Overloaded Operators:
	* ShapeDecorator& operator=(const StoredShape&) = delete: Deleted assignment operator. Do not want to share ownership of heap-stored Shape object
*/

#ifndef SHAPEDECORATOR_HPP
#define SHAPEDECORATOR_HPP

#include <memory>
#include "Shape.hpp"

class ShapeDecorator : public Shape
{
private:
	std::shared_ptr<Shape*> stored_shape;
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	ShapeDecorator() noexcept;				/* Default constructor. Set stored_shape to NULL. */
	ShapeDecorator(Shape*) noexcept;		/* Overloaded constructor. Set the Shape to decorate. */
	virtual ~ShapeDecorator() noexcept;		/* Destructor. */
	////////////////////////////
	// Accessors:
	////////////////////////////
	virtual std::shared_ptr<Shape*> GetShape() const noexcept = 0;	/* PVMF to be overwritten in derived classes. Get stored Shape object. */
	////////////////////////////
	// Mutators:
	////////////////////////////
	virtual void SetShape(Shape*) noexcept = 0;		/* PVMF to be overwritten in derived classes. Set stored Shape object. */

	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	ShapeDecorator& operator=(const ShapeDecorator&) noexcept = delete;	/* Deleted assignment operator. Do not want to share ownership of heap-stored Shape object.*/
};

#endif