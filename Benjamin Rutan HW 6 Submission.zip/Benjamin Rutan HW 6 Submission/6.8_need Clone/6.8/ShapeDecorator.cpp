/* ShapeDecorator.hpp (exercise 6.8)
Description:
	* Abstract base class for derived decorators.
Class Members:
	// Data:
	* Shape *stored_shape: Polymorphic Shape object to decorate.
	// Constructors/Destructor:
	* ShapeDecorator(): Default constructor. Set stored_shape to NULL.
	* ShapeDecorator(Shape*): Overloaded constructor. Set stored_shape.
	* ~ShapeDecorator(): Destructor.
	// Accessors:
	* Shape* GetShape() const: Get stored Shape object. To be overwritten in derived classes.
	// Mutators:
	* void SetShape(Shape*): Return stored Shape object.
	// Overloaded Operators:
	* ShapeDecorator& operator=(const ShapeDecorato&) = delete: Deleted assignment operator. Do not want to share ownership of heap-stored Shape object
*/


#include "ShapeDecorator.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
ShapeDecorator::ShapeDecorator() noexcept											/* Default constructor. Set stored_shape to NULL. */
{

}
ShapeDecorator::ShapeDecorator(Shape* shape_in) noexcept : stored_shape(shape_in)	/* Overloaded constructor. Set the Shape to decorate. */
{

}
ShapeDecorator::~ShapeDecorator() noexcept											/* Destructor. */
{
	// Release ownership of Shape object:
	stored_shape.reset();
}
