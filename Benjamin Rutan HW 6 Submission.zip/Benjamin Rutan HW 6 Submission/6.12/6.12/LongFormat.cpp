/* LongFormat.cpp (exercise 6.12)
Description:
	* Displays counter as a long integer..
Class Members:
	// Data:
	* shared_ptr<Propagator> stored_subj: Current attached-to Propagator.
	// Constructors/Destructor:
	* LongFormat(): Default constructor.
	* LongFormat(Propagator*): Overloaded constructor. Set stored_subj and become attached to Propagator.
	* LongFormat(const LongFormat&): Copy constructor.
	* ~LongFormat(): Destructor.
	// Misc Methods:
	* void Update(Propagator*): Update the Propagator.
	// Overloaded Operators:
	* LongFormat& operator=(const LongFormat&): Assignment operator.
*/

#include "LongFormat.hpp"
#include "Observer.hpp"
#include "Propagator.hpp"
#include "Counter.hpp"

///////////////////////////
// Constructor/Destructor:
///////////////////////////
LongFormat::LongFormat() noexcept : stored_subj(nullptr)				/* Default constructor. */
{

}
LongFormat::LongFormat(std::shared_ptr<Propagator> &subj_in) noexcept: stored_subj(subj_in.get())			/* Overloaded Constructor. Set stored_subj and attach. */
{
	// Attach to Propagator:
	std::shared_ptr<Observer> temp = std::make_shared<LongFormat>(this);
	subj_in->AddObserver(temp);
}
LongFormat::LongFormat(const LongFormat &in) noexcept : stored_subj(in.stored_subj) 	/* Copy constructor. Copy counter of passed object. */
{

}
LongFormat::LongFormat(LongFormat *in) noexcept : stored_subj(in->stored_subj)			/* Copy constructor with pointers. */
{

}
LongFormat::~LongFormat() noexcept		    							/* Destructor. */
{

}
///////////////////////////
// Misc Methods:
///////////////////////////
void LongFormat::Update(Propagator *subj_in) noexcept			/* Update the Propagator. */
{
	// Display as Long format:
	if (subj_in == &(*stored_subj))
	{
		std::cout << std::setprecision(2) << std::dynamic_pointer_cast<Counter, Propagator>(this->stored_subj)->GetCounter() << std::endl;
	}
}
///////////////////////////
// Overloaded Operators:
///////////////////////////
LongFormat& LongFormat::operator=(const LongFormat &lf_in) noexcept	/* Assignment operator. */
{
	if (this != &lf_in)
	{
		this->stored_subj.reset(lf_in.stored_subj.get());
	}
	return *this;
}