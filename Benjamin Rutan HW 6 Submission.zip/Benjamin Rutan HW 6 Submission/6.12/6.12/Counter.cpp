/* Counter.hpp (exercise 6.12)
Description:
	* Derived Propagator class that increments or decrements a counter variable.
Class Members:
	// Data:
	* long double value: current counter value.
	// Constructors/Destructor:
	* Counter(): Default constructor. Set counter to 0.
	* Counter(const Counter&): Copy counter object.
	* ~Counter(): Destructor.
	// Misc Methods:
	* void AddObserver(shared_ptr<Observer>&): Attach new observer to observelist.
	* virtual void DeleteObserver(std::shared_ptr<Observer>&): Remove Observer from observeList.
	* virtual void NotifyObservers(): Update each Observer in the observeList.
	* int GetCounter() const: Return current counter.
	* void IncreaseCounter(): Increase counter by 1.
	* void DecreaseCounter(): Decrease counter by 1.
	// Overloaded Operators:
	* Counter& operator=(const Counter&): Assignment operator.
*/

#include "Counter.hpp"
#include "Observer.hpp"

///////////////////////////
// Constructor/Destructor:
///////////////////////////
Counter::Counter() noexcept	: Propagator()		/* Default constructor. Set counter to 0.*/
{

}
Counter::Counter(const Counter &in) noexcept : Propagator(in) /* Copy constructor. */
{

}
Counter::Counter(Counter *in) noexcept : value(in->value)
{

}
Counter::~Counter() noexcept				/* Destructor. */
{

}
///////////////////////////
// Misc Methods:
///////////////////////////
void Counter::AddObserver(std::shared_ptr<Observer> &obs_in) noexcept		/* Attach new Observer to the observeList. */
{
	Propagator::AddObserver(obs_in);
}
void Counter::DeleteObserver(std::shared_ptr<Observer> &obs_in) noexcept	/* Remove Observer from observeList. */
{
	Propagator::DeleteObserver(obs_in);
}
void Counter::NotifyObservers() noexcept							/* Update each Observer in the observeList. */
{
	Propagator::NotifyObservers();
}
long double Counter::GetCounter() const noexcept		/* Return the current counter. */
{
	return value;
}
void Counter::IncreaseCounter() noexcept		/* Increase the counter by 1. */
{
	this->value++;
	// Call Notify() to display to all observers:
	this->NotifyObservers();
}
void Counter::DecreaseCounter() noexcept		/* Decrease the counter by 1. */
{
	this->value--;
	// Call Notify() to display to all observers:
	this->NotifyObservers();
}
void Counter::Update(Observer *obs_in) noexcept
{
	obs_in->Update(this);
}
///////////////////////////
// Overloaded Operators:
///////////////////////////
Counter& Counter::operator=(const Counter &in) noexcept	/* Assignment operator.*/
{
	if (this != &in)
	{
		this->value = in.value;
	}
	return *this;
}