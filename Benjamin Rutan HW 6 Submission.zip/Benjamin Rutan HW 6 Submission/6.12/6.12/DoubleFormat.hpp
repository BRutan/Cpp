/* DoubleFormat.hpp (exercise 6.12)
Description:
	* Displays data in Counter as a double floating point.
Class Members:
	// Data:
	* shared_ptr<Propagator> stored_subj: Current attached-to Propagator.
	// Constructors/Destructor:
	* DoubleFormat(): Default constructor.
	* DoubleFormat(shared_ptr<Propagator> subj_in *subj_in) noexcept: Overloaded Constructor. Set the stored_subj and attach to.
	* DoubleFormat(const DoubleFormat&): Copy constructor.
	* ~DoubleFormat(): Destructor.
	// Misc Methods:
	* void Update(Propagator&) const: Update the Propagator.
	// Overloaded Operators:
	* DoubleFormat& operator=(const DoubleFormat&): Assignment operator.
*/

#ifndef DOUBLEFORMAT_HPP
#define DOUBLEFORMAT_HPP

#include <iomanip>
#include <iostream>
#include <memory>
#include "Observer.hpp"

class Propagator;

class DoubleFormat : public Observer
{
private:
	std::shared_ptr<Propagator> stored_subj;		/* Current attached - to Propagator. */
public:
	///////////////////////////
	// Constructor/Destructor:
	///////////////////////////
	DoubleFormat() noexcept;						/* Default constructor. */
	DoubleFormat(DoubleFormat*) noexcept;			/* Copy constructor with pointers. */
	DoubleFormat(std::shared_ptr<Propagator>&) noexcept;				/* Overloaded Constructor. Set the stored_subj and attach to. */
	DoubleFormat(const DoubleFormat&) noexcept;		/* Copy constructor. */
	virtual ~DoubleFormat() noexcept;				/* Destructor. */
	///////////////////////////
	// Misc Methods:
	///////////////////////////
	virtual void Update(Propagator*) noexcept;			/* Update the Propagator. */
	///////////////////////////
	// Overloaded Operators:
	///////////////////////////
	DoubleFormat& operator=(const DoubleFormat&) noexcept;	/* Assignment operator. */
};

#endif
