/* LongFormat.hpp (exercise 6.12)
Description:
	* Abstract base class, to be derived in classes that observe data.
Class Members:
	// Data:
	* shared_ptr<Propagator> stored_subj: Current attached-to Propagator.
	// Constructors/Destructor:
	* LongFormat(): Default constructor.
	* LongFormat(shared_ptr<Propagator>&): Overloaded constructor. Set stored_subj and become attached to Propagator.
	* LongFormat(const LongFormat&): Copy constructor.
	* ~LongFormat(): Destructor.
	// Misc Methods:
	* void Update(Propagator*): Update the Propagator.
	// Overloaded Operators:
	* LongFormat& operator=(const LongFormat&): Assignment operator.
*/

#ifndef LONGFORMAT_HPP
#define LONGFORMAT_HPP

#include <cmath>
#include <iomanip>
#include <iostream>
#include <memory>
#include "Observer.hpp"

class Propagator;
class Counter;

class LongFormat : public Observer
{
private:
	std::shared_ptr<Propagator> stored_subj;		/* Current attached - to Propagator. */
public:
	///////////////////////////
	// Constructor/Destructor:
	///////////////////////////
	LongFormat() noexcept;						/* Default constructor. */
	LongFormat(std::shared_ptr<Propagator>&) noexcept;				/* Overloaded constructor. Set stored_subj and become attached to Propagator. */
	LongFormat(LongFormat*) noexcept;			/* Copy constructor with pointers. */
	LongFormat(const LongFormat&) noexcept;		/* Copy constructor. */
	virtual ~LongFormat() noexcept;				/* Destructor. */
	///////////////////////////
	// Misc Methods:
	///////////////////////////
	virtual void Update(Propagator*) noexcept;	/* Update the Propagator. */
	///////////////////////////
	// Overloaded Operators:
	///////////////////////////
	LongFormat& operator=(const LongFormat&) noexcept;	/* Assignment operator. */
};

#endif