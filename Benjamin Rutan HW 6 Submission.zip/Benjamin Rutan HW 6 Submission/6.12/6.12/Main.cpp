/* Main.cpp (exercise 6.12)
Description:
	* Solutions to problems a-l.
*/

#include <iostream>
#include "Counter.hpp"
#include "DoubleFormat.hpp"
#include "LongFormat.hpp"
#include "Observer.hpp"
#include "Propagator.hpp"

int main()
{
	// f) Test the Propagator and Observer classes:
	std::shared_ptr<Propagator> count(new Counter());
	std::shared_ptr<Observer> obs1(new LongFormat(count));
	std::shared_ptr<Observer> obs2(new DoubleFormat(count));
	
	// Attach to counter:
	count->AddObserver(obs1);
	count->AddObserver(obs2);
	// Ensure that observers are listening:
	std::dynamic_pointer_cast<Counter, Propagator>(count)->IncreaseCounter();
	std::dynamic_pointer_cast<Counter, Propagator>(count)->DecreaseCounter();	
	
	system("pause");

	return 0;
}