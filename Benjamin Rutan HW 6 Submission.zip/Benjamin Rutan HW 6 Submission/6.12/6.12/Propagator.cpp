/* Propagator.hpp (exercise 6.12)
Description:
	* Handles list of Observers, notifying on changes.
Class Members:
	// Data:
	* list<shared_ptr<Observer>> observeList: List of observers.
	// Constructors/Destructor:
	* Propagator(): Default constructor.
	* Propagator(const Propagator&): Copy constructor.
	* ~Propagator(): Destructor.
	// Misc Methods:
	* void AddObserver(shared_ptr<Observer>&): Add new observer to observeList.
	* void DeleteObserver(shared_ptr<Observer>&): Remove observer from observeList.
	* void NotifyObservers(): update each observer in observeList.
	// Overloaded Operators:
	* Propagator& operator=(const Propagator&): Assignment operator.
*/


#include "Propagator.hpp"
#include "Observer.hpp"

/////////////////////////////
// Constructors/Destructor:
/////////////////////////////
Propagator::Propagator() noexcept : observeList()		/* Default constructor. */
{

}
Propagator::Propagator(const Propagator &in) noexcept : observeList(in.observeList)		/* Copy constructor. */
{

}
Propagator::Propagator(Propagator *prop_in) noexcept
{

}
Propagator::~Propagator() noexcept					/* Destructor. */
{

}
/////////////////////////////
// Misc Methods:
/////////////////////////////
void Propagator::AddObserver(std::shared_ptr<Observer> &obs_in) noexcept	/* Attach new Observer to the observeList. */
{
	observeList.push_back(obs_in);
}
void Propagator::DeleteObserver(std::shared_ptr<Observer> &obs_in) noexcept	/* Remove Observer from observeList. */
{
	observeList.remove(obs_in);
}
void Propagator::NotifyObservers() noexcept				/* Update each Observer in the observeList. */
{
	for (auto it = observeList.begin(); it != observeList.end(); it++)
	{
		(*it)->Update(this);
	}
}
/////////////////////////////
// Overloaded Operators:
/////////////////////////////
Propagator& Propagator::operator=(Propagator &in) noexcept		/* Assignment Operator. */
{
	if (this != &in)
	{
		this->observeList = in.observeList;
	}
	return *this;
}