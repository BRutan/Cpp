/* Propagator.hpp (exercise 6.12)
Description:
	* Handles list of Observers, notifying on changes.
Class Members:
	// Data:
	* list<shared_ptr<Observer>> observeList: List of observers.
	// Constructors/Destructor:
	* Propagator(): Default constructor.
	* Propagator(const Propagator&): Copy constructor.
	* ~Propagator(): Destructor.
	// Misc Methods:
	* void AddObserver(shared_ptr<Observer>&): Add new observer to observeList.  
	* void DeleteObserver(shared_ptr<Observer>&): Remove observer from observeList.
	* void NotifyObservers(): update each observer in observeList.
	// Overloaded Operators:
	* Propagator& operator=(const Propagator&): Assignment operator.
*/

#ifndef PROPAGATOR_HPP
#define PROPAGATOR_HPP

#include <list>
#include <memory>

class Observer;

class Propagator
{
private:
	std::list<std::shared_ptr<Observer>> observeList;
public:
	/////////////////////////////
	// Constructors/Destructor:
	/////////////////////////////
	Propagator() noexcept;						/* Default constructor. */
	Propagator(Propagator*) noexcept;			
	Propagator(const Propagator&) noexcept;		/* Copy constructor. */
	virtual ~Propagator() noexcept;			/* Destructor. */
	/////////////////////////////
	// Misc Methods:
	/////////////////////////////
	virtual void AddObserver(std::shared_ptr<Observer>&) noexcept = 0;	/* Attach new Observer to the observeList. */
	virtual void DeleteObserver(std::shared_ptr<Observer>&) noexcept;	/* Remove Observer from observeList. */
	virtual void NotifyObservers() noexcept;							/* Update all observers in the list. */
	/////////////////////////////
	// Overloaded Operators:
	/////////////////////////////
	Propagator& operator=(Propagator&) noexcept;	/* Assignment Operator. */
};

#endif