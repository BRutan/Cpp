/* Counter.hpp (exercise 6.12)
Description:
	* Derived Propagator class that increments or decrements a counter variable.
Class Members:
	// Data:
	* long double value: current counter value.
	// Constructors/Destructor:
	* Counter(): Default constructor. Set counter to 0.
	* Counter(const Counter&): Copy counter object.
	* ~Counter(): Destructor.
	// Misc Methods:
	* void AddObserver(shared_ptr<Observer>&): Attach new observer to observelist.
	* virtual void DeleteObserver(std::shared_ptr<Observer>&): Remove Observer from observeList.
	* virtual void NotifyObservers(): Update each Observer in the observeList. 
	* int GetCounter() const: Return current counter.
	* void IncreaseCounter(): Increase counter by 1.
	* void DecreaseCounter(): Decrease counter by 1.
	// Overloaded Operators:
	* Counter& operator=(const Counter&): Assignment operator.
*/

#ifndef COUNTER_HPP
#define COUNTER_HPP

#include <list>
#include "Propagator.hpp"

class Observer;

class Counter : public Propagator
{
private:
	long double value;
public:
	///////////////////////////
	// Constructor/Destructor:
	///////////////////////////
	Counter() noexcept;					/* Default constructor. Set counter to 0.*/
	Counter(Counter*) noexcept;	
	Counter(const Counter&) noexcept;	/* Copy constructor. */
	virtual ~Counter() noexcept;		/* Destructor. */
	///////////////////////////
	// Misc Methods:
	///////////////////////////
	virtual void AddObserver(std::shared_ptr<Observer>&) noexcept;		/* Attach new Observer to the observeList. */
	virtual void DeleteObserver(std::shared_ptr<Observer>&) noexcept;	/* Remove Observer from observeList. */
	virtual void NotifyObservers() noexcept;							/* Update each Observer in the observeList. */
	long double GetCounter() const noexcept;		/* Return the current counter. */
	void IncreaseCounter() noexcept;				/* Increase the counter by 1. */
	void DecreaseCounter() noexcept;				/* Decrease the counter by 1. */
	void Update(Observer*) noexcept;
	///////////////////////////
	// Overloaded Operators:
	///////////////////////////
	Counter& operator=(const Counter&) noexcept;	/* Assignment operator.*/
};

#endif