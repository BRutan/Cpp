/* ShapeFactory.hpp (exercise 6.7)
Description:
	* Factory abstract base class for derived classes (ConsoleShapeFactory).
Class Members:
	// Constructors/Destructor:
	* ShapeFactory(): Default constructor.
	* ShapeFactory(const ShapeFactory&): Copy constructor.
	* ~ShapeFactory(): Destructor.
	// Misc Methods:
	* Circle CreateCircle(double p_x, double p_y, double rad) const: PVMF, create a Circle object using passed parameters.  
	* Line CreateLine(double p1_x, double p1_y, double p2_x, double p2_y) const: PVMF, create a Line object using passed parameters.
	* Point CreatePoint(double p_x, double p_y) const: PVMF, create a Point object using passed parameters.
	// Overloaded Operators:
	* ShapeFactory& operator=(const ShapeFactory&): Assignment operator. 
*/

#ifndef SHAPEFACTORY_HPP
#define SHAPEFACTORY_HPP

#include "Circle.hpp"
#include "Line.hpp"
#include "Point.hpp"
#include "Shape.hpp"

class ShapeFactory
{
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	ShapeFactory() noexcept;						/* Default constructor. */
	ShapeFactory(const ShapeFactory&) noexcept;		/* Copy constructor. */
	virtual ~ShapeFactory() noexcept;				/* Destructor. */
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	virtual Circle CreateCircle(double p_x, double p_y, double rad) const noexcept = 0;	/* PVMFs to be overwritten in derived classes (ConsoleShapeFactory). */
	virtual Line CreateLine(double p1_x, double p1_y, double p2_x, double p2_y) const noexcept = 0;
	virtual Point CreatePoint(double p_x, double p_y) const noexcept = 0;
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	ShapeFactory& operator=(const ShapeFactory&) noexcept;	/* Assignment operator. */
};

#endif