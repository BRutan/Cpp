/* Main.cpp (exercise 6.7)
Description:
	* Solutions to problems a-e.
*/

#include <iostream>
#include "ConsoleShapeFactory.hpp"
#include "Circle.hpp"
#include "Line.hpp"
#include "Point.hpp"
#include "Shape.hpp"
#include "ShapeFactory.hpp"

int main()
{
	// e) Create test program for ShapeFactory:
	ShapeFactory *test = new ConsoleShapeFactory();
	
	// Create Point, Line and Circle objects:
	Point p1 = test->CreatePoint(4.0, 5.0);
	p1.Print(); std::cout << std::endl;

	Line l1 = test->CreateLine(4.0, 5.0, 2.0, 1.0);
	l1.Print(); std::cout << std::endl;

	Circle c1 = test->CreateCircle(2.0, 4.0, 12.0);
	c1.Print(); std::cout << std::endl;

	system("pause");

	return 0;
}