/* ShapeFactory.cpp (exercise 6.7)
Description:
	* Factory abstract base class for derived classes (ConsoleShapeFactory).
Class Members:
	// Constructors/Destructor:
	* ShapeFactory(): Default constructor.
	* ShapeFactory(const ShapeFactory&): Copy constructor.
	* ~ShapeFactory(): Destructor.
	// Misc Methods:
	* Circle CreateCircle(double p_x, double p_y, double rad) const: PVMF, create a Circle object using passed parameters.
	* Line CreateLine(double p1_x, double p1_y, double p2_x, double p2_y) const: PVMF, create a Line object using passed parameters.
	* Point CreatePoint(double p_x, double p_y) const: PVMF, create a Point object using passed parameters.
	// Overloaded Operators:
	* ShapeFactory& operator=(const ShapeFactory&): Assignment operator.
*/

#include "Circle.hpp"
#include "Line.hpp"
#include "Point.hpp"
#include "Shape.hpp"
#include "ShapeFactory.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
ShapeFactory::ShapeFactory() noexcept						/* Default constructor. */
{

}
ShapeFactory::ShapeFactory(const ShapeFactory &in) noexcept		/* Copy constructor. */
{

}
ShapeFactory::~ShapeFactory() noexcept						/* Destructor. */
{

}
////////////////////////////
// Overloaded Operators:
////////////////////////////
ShapeFactory& ShapeFactory::operator=(const ShapeFactory &in) noexcept	/* Assignment operator. */
{
	if (this != &in)
	{

	}
	return *this;
}
