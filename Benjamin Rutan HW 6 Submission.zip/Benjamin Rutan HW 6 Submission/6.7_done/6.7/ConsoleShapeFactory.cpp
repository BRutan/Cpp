/* ConsoleShapeFactory.cpp (exercise 6.7)
Description:
	* Derived from ShapeFactory,
Class Members:
	// Constructors/Destructor:
	* ConsoleShapeFactory(): Default constructor.
	* ConsoleShapeFactory(const ConsoleShapeFactory&): Copy constructor.
	* ~ConsoleShapeFactory(): Destructor.
	// Misc Methods:
	* Circle CreateCircle(double p_x, double p_y, double rad) const: PVMF, create a Circle object using passed parameters.
	* Line CreateLine(double p1_x, double p1_y, double p2_x, double p2_y) const: PVMF, create a Line object using passed parameters.
	* Point CreatePoint(double p_x, double p_y) const: PVMF, create a Point object using passed parameters.
	// Overloaded Operators:
	* ConsoleShapeFactory& operator=(const ConsoleShapeFactory&): Assignment operator.
*/

#include "ConsoleShapeFactory.hpp"
#include "ShapeFactory.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
ConsoleShapeFactory::ConsoleShapeFactory() noexcept									/* Default constructor. */
{

}
ConsoleShapeFactory::ConsoleShapeFactory(const ConsoleShapeFactory &in) noexcept	/* Copy constructor. */
{

}
ConsoleShapeFactory::~ConsoleShapeFactory() noexcept								/* Destructor. */
{

}
////////////////////////////
// Misc Methods:
////////////////////////////
Circle ConsoleShapeFactory::CreateCircle(double p_x, double p_y, double rad) const noexcept		/* Create Circle object using passed data. */
{
	return Circle(Point(p_x, p_y), rad);
}
Line ConsoleShapeFactory::CreateLine(double p1_x, double p1_y, double p2_x, double p2_y) const noexcept	/* Create Line object using passed data. */
{
	return Line(Point(p1_x, p1_y), Point(p2_x, p2_y));
}
Point ConsoleShapeFactory::CreatePoint(double p_x, double p_y) const noexcept					/* Create Point object using passed data. */
{
	return Point(p_x, p_y);
}
////////////////////////////
// Overloaded Operators:
////////////////////////////
ConsoleShapeFactory& ConsoleShapeFactory::operator=(const ConsoleShapeFactory &in) noexcept	/* Assignment operator. */
{
	if (this != &in)
	{

	}
	return *this;
}