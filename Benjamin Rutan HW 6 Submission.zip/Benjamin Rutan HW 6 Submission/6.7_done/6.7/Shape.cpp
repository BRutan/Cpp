/* Shape.cpp (exercise 6.7)
Description:
	* Header file for Shape class, declares member variables/objects and functions.
Member Functions:
	// Constructors/Destructor:
	* Shape(): Default constructor. 
	* Shape(const Shape&): Copy constructor.
	* virtual ~Shape(): Destructor.
	// Misc. Methods:
	* void Print() const: PVMF to make class abstract.
	// Overloaded Operators:
	* Shape& operator=(const Shape&): Assignment operator.
*/

#include<iostream>
#include<cstdlib>
#include<sstream>
#include"Shape.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
Shape::Shape()							/* Default constructor. */
{
		
}
Shape::Shape(const Shape &shape_in)		/* Copy constructor. */
{
			
}
Shape::~Shape()							/* Destructor. */
{
		
}
////////////////////////////
// Overloaded Operators:
////////////////////////////
Shape& Shape::operator=(const Shape &shape_in) /* Assignment operator. */
{
	// Preclude self-assignment:
	if (this != &shape_in)
	{
		
	}
	return *this;
}
