/* Main.cpp (exercise 6.4)
Description:
	*


*/

#include <iostream>
#include "Circle.hpp"
#include "Line.hpp"
#include "Point.hpp"
#include "Shape.hpp"

int main()
{
	// 

	return 0;
}