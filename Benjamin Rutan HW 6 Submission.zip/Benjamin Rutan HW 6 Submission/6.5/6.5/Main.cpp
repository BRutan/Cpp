/* Main.cpp (exercise 6.5)
Description:
	* Solutions to problems a-j.
*/

#include <iostream>
#include <string>
#include "Exception.hpp"
#include "NoAccessException.hpp"
#include "NoFundsException.hpp"
#include "ProtectedAccount.hpp"

int main()
{
	// j) 
	ProtectedAccount account("aAxnTiv45", 450230);
	// Test full functionality of ProtectedAccount class:
	

	// Test ProtectedAccount from stdin/stdout:




	system("pause");

	return 0;
}
