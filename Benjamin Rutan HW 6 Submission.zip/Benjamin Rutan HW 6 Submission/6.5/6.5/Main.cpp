/* Main.cpp (exercise 6.5)
Description:
	* Solutions to problems a-j.
*/

#include <iomanip>
#include <iostream>
#include <regex>
#include <vector>
#include <string>
#include "Exception.hpp"
#include "NoAccessException.hpp"
#include "NoFundsException.hpp"
#include "ProtectedAccount.hpp"

int main()
{
	// j) Test the functionality of each class:
	ProtectedAccount account("abc123", 1234342);
	std::size_t attemptCount = 0, currIter;
	std::string currLine, password;
	std::regex amountPattern("([0-9]*[.])?[0-9]+");	/* Pattern for amounts. */
	std::regex space("\\s+");
	std::string splitLine[2];
	double withdrawn;

	// Prompt password from user until correct or hits 3 attempts. If too many attempts, exit program:
	std::cout << "Enter password for account:" << std::endl;
	do
	{
		std::cout << "Password: ";
		std::getline(std::cin, password);
		attemptCount++;
		try
		{
			account.GetBalance(password);
			break;
		}
		catch (NoAccessException&)
		{
			if (attemptCount < 3) 
				std::cout << "Invalid password. Please try again." << std::endl;
		}

	} while (attemptCount < 3);
	
	if (attemptCount == 3)
	{
		std::cout << "Too many access attempts occurred, exiting program." << std::endl;
		system("pause");
		return 0;
	}
	else
	{
		std::cout << "Correct password detected. Current balance: " << std::setprecision(2) << std::fixed << account.GetBalance(password) << std::endl;
	}

	// Get further commands from user:
	do 
	{
		std::cout << "Current balance: " << account.GetBalance(password) << std::endl;
		std::cout << "Enter command {W <Number.00>: Withdraw $, E: Exit}: ";
		std::getline(std::cin, currLine);
		// Clear out the split line:
		currIter = 0;
		splitLine[0] = "";
		splitLine[1] = "";
		// Parse the input using sregex_iterator:
		auto iter = std::sregex_token_iterator(currLine.begin(), currLine.end(), space, -1);
		while (iter != std::sregex_token_iterator() && currIter < 2)
		{
			splitLine[currIter++] = *iter;
			iter++;
		}
		
		if (splitLine[0] == "W" && currIter == 2)
		{
			if (std::regex_match(splitLine[1], amountPattern))
			{
				// Attempt to withdraw:
				try
				{
					withdrawn = account.Withdraw(std::stod(splitLine[1]), password);
					std::cout << "Successfully withdrew " << withdrawn << " from account. " << std::endl;
				}
				catch (NoFundsException&)
				{
					std::cout << "Cannot withdraw " << splitLine[1] << ", not enough funds." << std::endl;
				}
			}
			else
			{
				// Display error to user:
				std::cout << "Amount " << splitLine[1] << " is invalid. Please enter valid amount in form <0.00>." << std::endl;
			}
		}
		else if (splitLine[0] != "E")
		{
			std::cout << "Invalid command. Please re-enter." << std::endl;
		}
	} while (splitLine[0] != "E");


	// Exit procedure:
	std::cout << "Exiting account. " << std::endl;

	system("pause");

	return 0;
}
