/* RealAccount.hpp (exercise 6.5)
Description:
	* Derived Account class with an actual balance.
Class Members:
	// Constructors/Destructor:
	* RealAccount(double) noexcept: Overloaded constructor. Set balance.
	* RealAccount(const RealAccount&) = delete: Deleted copy constructor. Deleting since unwise to be able to copy other users' account information.
	* ~RealAccount(): Destructor.
	// Misc. Methods:
	* double Withdraw(double): Attempt to withdraw and return funds. If balance would be negative, then throw NoFundsException.
	* double GetBalance() const: Get current balance.
	// Overloaded Operators
	* RealAccount& operator=(const RealAccount&) = delete: Deleted assignment operator.
*/

#ifndef REALACCOUNT_HPP
#define REALACCOUNT_HPP

#include "Account.hpp"
#include "Exception.hpp"
#include "NoFundsException.hpp"

class RealAccount : public Account
{
private:
	double balance;
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	RealAccount(double) noexcept;						/* Overloaded constructor. Set balance. */
	RealAccount(const RealAccount&) noexcept = delete;	/* Deleted copy constructor. Deleting since unwise to be able to copy other users' account information. */
	virtual ~RealAccount() noexcept;					/* Destructor. */
	////////////////////////////
	// Misc. Methods:
	////////////////////////////
	virtual double Withdraw(double);			 /* Attempt to withdraw funds. If balance would be negative, then throw NoFundsException. */
	virtual double GetBalance() const noexcept;  /* Get the current balance. */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	RealAccount& operator=(const RealAccount&) = delete; /* Deleted assignment operator. Deleting since unwise to be able to copy other users' account information*/
};

#endif
