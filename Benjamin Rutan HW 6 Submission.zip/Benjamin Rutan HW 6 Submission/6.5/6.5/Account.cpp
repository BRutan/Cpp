/* Account.cpp (exercise 6.5)
Description:
	* Base class for RealAccount.
Class Members:
	// Constructors/Destructor:
	* Account(): Default constructor.
	* Account(const Account&) = delete: Deleted copy constructor.
	* ~Account(): Destructor.
	// Misc Methods:
	* double Withdraw(double): PVMF for overloading in derived classes. Attempt to withdraw funds.
	* double GetBalance() const: PVMF for overloading in derived classes. Get balance of account.
	// Overloaded Operators:
	* Account& operator=(const Account&) noexcept = delete: Deleted assignment operator.
*/

#include "Account.hpp"

/////////////////////////////
// Constructors/Destructor:
/////////////////////////////
Account::Account() noexcept		/* Default constructor. */
{

}
Account::~Account() noexcept	/* Destructor. */
{

}