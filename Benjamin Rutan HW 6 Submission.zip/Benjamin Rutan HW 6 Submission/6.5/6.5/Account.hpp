/* Account.hpp (exercise 6.5)
Description:
	* Base class for RealAccount.
Class Members:
	// Constructors/Destructor:
	* Account(): Default constructor.
	* Account(const Account&) = delete: Deleted copy constructor.
	* ~Account(): Destructor.
	// Misc Methods:
	* double Withdraw(double): PVMF for overloading in derived classes. Attempt to withdraw funds.
	* double GetBalance() const: PVMF for overloading in derived classes. Get balance of account. 
	// Overloaded Operators:
	* Account& operator=(const Account&) noexcept = delete: Deleted assignment operator.
*/

#ifndef ACCOUNT_HPP
#define ACCOUNT_HPP

class Account
{
public:
	/////////////////////////////
	// Constructors/Destructor:
	/////////////////////////////
	Account() noexcept;
	Account(const Account&) noexcept = delete;
	virtual ~Account() noexcept;
	/////////////////////////////
	// Misc. Methods:
	/////////////////////////////
	virtual double Withdraw(double) = 0;
	virtual double GetBalance() const noexcept = 0 ;
	/////////////////////////////
	// Overloaded Operators:
	/////////////////////////////
	Account& operator=(const Account&) noexcept = delete;
};


#endif
