/* Account.hpp (exercise 6.5)
Description:
	*


*/


#ifndef ACCOUNT_HPP
#define ACCOUNT_HPP

class Account
{
public:
	/////////////////////////////
	// Constructors/Destructor:
	/////////////////////////////
	Account() noexcept
	{

	}
	virtual ~Account() noexcept
	{

	}
	/////////////////////////////
	// Misc. Methods:
	/////////////////////////////
	virtual double Withdraw(double) = 0;
	virtual double GetBalance() const = 0 noexcept;
};


#endif
