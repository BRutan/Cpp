/* ProtectedAccount.hpp (exercise 6.5)
Description:
	* Layer over RealAccount, adding password protection.
Class Members:
	// Constructors/Destructor:
	* ProtectedAccount(const string&, double): Overloaded Constructor. Set password and balance of private RealAccount.
	* ProtectedAccount(const ProtectedAccount&) = delete: Deleted Copy constructor.
	* ~ProtectedAccount(): Destructor.
	// Misc Methods:
	* double Withdraw(double, const string&): Attempt to withdraw passed amount from private RealAccount, if password matches. 
	* double GetBalance(const string&) const: Get RealAccount's balance, but only if passed password matches. 
	// Overloaded Operators:
	* ProtectedAccount& operator=(const ProtectedAccount&) = delete: Deleted assignment operator.
*/

#ifndef PROTECTEDACCOUNT_HPP
#define PROTECTEDACCOUNT_HPP

#include <string>
#include "Account.hpp"
#include "NoAccessException.hpp"
#include "RealAccount.hpp"

class ProtectedAccount
{
private:
	std::string password;
	RealAccount acc;
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	ProtectedAccount() noexcept = delete;
	ProtectedAccount(const std::string&, double) noexcept;			/* Overloaded constructor. Set password and balance of RealAccount. */
	ProtectedAccount(const ProtectedAccount&) noexcept = delete;	/* Deleting since probably unwise to be able to copy another person's account, gaining their confidential information. */
	virtual ~ProtectedAccount() noexcept;							/* Destructor. */
	////////////////////////////
	// Misc. Methods:
	////////////////////////////
	virtual double Withdraw(double, const std::string&);				/* Attempt to withdraw balance from RealAccount. */
	virtual double GetBalance(const std::string&) const;		/* Get RealAccount's balance, only if passed password matches. */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	ProtectedAccount& operator=(const ProtectedAccount&) noexcept = delete;	/* Deleting since probably unwise to be able to assign another person's account, for aforementioned reasons. */
};


#endif