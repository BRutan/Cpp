/* NoAccessException.hpp (exercise 6.5)
Description:
	* Exception thrown when client passes incorrect password when attempting to Withdraw() or GetBalance() of internal RealAccount in 
	ProtectedAccount class.
Class Members:
	// Constructors/Destructor:
	* NoFundsException(): Default constructor.
	* NoFundsException(const NoFundsException&): Copy constructor.
	* ~NoFundsException(): Destructor.
	// Overloaded Operators:
	* NoFundsException& operator=(const NoFundsException&): Assignment operator.
*/

#ifndef NOACCESSEXCEPTION_HPP
#define NOACCESSEXCEPTION_HPP

#include "Exception.hpp"

class NoAccessException : public Exception
{
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	NoAccessException() noexcept;							/* Default Constructor. */
	NoAccessException(const NoAccessException&) noexcept;	/* Copy Constructor. */
	virtual ~NoAccessException() noexcept;					/* Destructor. */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	NoAccessException& operator=(const NoAccessException&) noexcept;	/* Assignment Operator. */
};

#endif