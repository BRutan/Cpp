/* NoFundsException.cpp (exercise 6.5)
Description:
	* Exception thrown when client attempts to withdraw amount greater than currently present in RealAccount.
Class Members:
	// Constructors/Destructor:
	* NoFundsException(): Default constructor.
	* NoFundsException(const NoFundsException&): Copy constructor.
	* ~NoFundsException(): Destructor.
	// Overloaded Operators:
	* NoFundsException& operator=(const NoFundsException&): Assignment operator.
*/

#include "NoFundsException.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
NoFundsException::NoFundsException() noexcept								/* Default Constructor. */
{

}
NoFundsException::NoFundsException(const NoFundsException&) noexcept		/* Copy Constructor. */
{

}
NoFundsException::~NoFundsException() noexcept								/* Destructor. */
{

}
////////////////////////////
// Overloaded Operators:
////////////////////////////
NoFundsException& NoFundsException::operator=(const NoFundsException &in) noexcept		/* Assignment Operator. */
{
	// Preclude self-assignment:
	if (this != &in)
	{

	}
	return *this;
}