/* RealAccount.cpp (exercise 6.5)
Description:
	* Derived Account class with an actual balance.
Class Members:
	// Constructors/Destructor:
	* RealAccount(double) noexcept: Overloaded constructor. Set balance.
	* RealAccount(const RealAccount&) = delete: Deleted copy constructor. Deleting since unwise to be able to copy other users' account information.
	* ~RealAccount(): Destructor.
	// Misc. Methods:
	* double Withdraw(double): Attempt to withdraw and return funds. If balance would be negative, then throw NoFundsException.
	* double GetBalance() const: Get current balance.
	// Overloaded Operators
	* RealAccount& operator=(const RealAccount&) = delete: Deleted assignment operator.
*/

#include "RealAccount.hpp"
#include "Exception.hpp"
#include "NoFundsException.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
RealAccount::RealAccount(double balance_in) noexcept: balance(balance_in)		/* Overloaded Constructor. Set balance.*/
{

}
RealAccount::~RealAccount()							/* Destructor. */
{

}
////////////////////////////
// Misc. Methods:
////////////////////////////
double RealAccount::Withdraw(double amount)			/* Attempt to withdraw funds. If balance would be negative, then throw NoFundsException. */
{
	if (balance - amount < 0)
	{
		throw NoFundsException();
	}
	balance -= amount;
	return amount;
}
double RealAccount::GetBalance() const noexcept				/* Get the current balance. */
{
	return balance;
}