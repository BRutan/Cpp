/* ProtectedAccount.cpp (exercise 6.5)
Description:
	* Layer over RealAccount, adding password protection.
Class Members:
	// Constructors/Destructor:
	* ProtectedAccount(const string&, double): Overloaded Constructor. Set password and balance of private RealAccount.
	* ProtectedAccount(const ProtectedAccount&) = delete: Deleted Copy constructor.
	* ~ProtectedAccount(): Destructor.
	// Misc Methods:
	* double Withdraw(double, const string&): Attempt to withdraw passed amount from private RealAccount, if password matches.
	* double GetBalance(const string&) const: Get RealAccount's balance, but only if passed password matches.
	// Overloaded Operators:
	* ProtectedAccount& operator=(const ProtectedAccount&) = delete: Deleted assignment operator.
*/

#include <string>
#include "Account.hpp"
#include "NoAccessException.hpp"
#include "ProtectedAccount.hpp"
#include "RealAccount.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
ProtectedAccount::ProtectedAccount(const std::string& pass_in, double balance_in) noexcept : password(pass_in), acc(balance_in)			/* Overloaded constructor. Set password and balance of RealAccount. */
{

}
ProtectedAccount::~ProtectedAccount() noexcept										/* Destructor. */
{

}
////////////////////////////
// Misc. Methods:
////////////////////////////
double ProtectedAccount::Withdraw(double amount, const std::string &pass_in)		/* Attempt to withdraw amount from RealAccount, only if password matches. */
{
	// If password does not match passed password, throw NoAccessException:
	if (pass_in != password)
	{
		throw NoAccessException();
	}
	return acc.Withdraw(amount);	// Will throw exception if not enough funds present. 
}
double ProtectedAccount::GetBalance(const std::string &pass_in) const 		/* Get RealAccount's balance. */
{
	// If password does not match passed password, throw NoAccessException:
	if (pass_in != password)
	{
		throw NoAccessException();
	}
	return acc.GetBalance();
}