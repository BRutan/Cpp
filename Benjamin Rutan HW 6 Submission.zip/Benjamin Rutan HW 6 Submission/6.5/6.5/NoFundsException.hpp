/* NoFundsException.hpp (exercise 6.5)
Description:
	* Exception thrown when client has no permission to access GetBalance() method in
	Account class.
Class Members:
	


*/

#ifndef NOFUNDSEXCEPTION_HPP
#define NOFUNDSEXCEPTION_HPP

#include "Exception.hpp"

class NoFundsException : public Exception
{
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	NoFundsException() noexcept;
	NoFundsException(const NoFundsException&) noexcept;
	virtual ~NoFundsException() noexcept;
	////////////////////////////
	// :
	////////////////////////////

};



#endif