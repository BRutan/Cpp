/* NoFundsException.hpp (exercise 6.5)
Description:
	* Exception thrown when client attempts to withdraw amount greater than currently present in RealAccount.
Class Members:
	// Constructors/Destructor:
	* NoFundsException(): Default constructor.
	* NoFundsException(const NoFundsException&): Copy constructor.
	* ~NoFundsException(): Destructor.
	// Overloaded Operators:
	* NoFundsException& operator=(const NoFundsException&): Assignment operator. 
*/

#ifndef NOFUNDSEXCEPTION_HPP
#define NOFUNDSEXCEPTION_HPP

#include "Exception.hpp"

class NoFundsException : public Exception
{
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	NoFundsException() noexcept;							/* Default Constructor. */
	NoFundsException(const NoFundsException&) noexcept;		/* Copy Constructor. */
	virtual ~NoFundsException() noexcept;					/* Destructor. */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	NoFundsException& operator=(const NoFundsException&) noexcept;	/* Assignment Operator. */
};



#endif