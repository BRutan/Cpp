/* Exception.hpp (exercise 6.5)
Description:
	* Empty base class for NoAccessException and NoFundsException, to enable polymorphism.
*/

#ifndef EXCEPTION_HPP
#define EXCEPTION_HPP

class Exception
{

};


#endif
