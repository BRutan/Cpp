/* Exception.hpp (exercise 6.5)
Description:
	*

*/

#ifndef EXCEPTION_HPP
#define EXCEPTION_HPP

class Exception
{


};



#endif
