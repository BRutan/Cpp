/* NoAccessException.cpp (exercise 6.5)
Description:
	* Exception thrown when client passes incorrect password when attempting to Withdraw() or GetBalance() of internal RealAccount in
	ProtectedAccount class.
Class Members:
	// Constructors/Destructor:
	* NoFundsException(): Default constructor.
	* NoFundsException(const NoFundsException&): Copy constructor.
	* ~NoFundsException(): Destructor.
	// Overloaded Operators:
	* NoFundsException& operator=(const NoFundsException&): Assignment operator.
*/

#include "NoAccessException.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
NoAccessException::NoAccessException() noexcept								/* Default Constructor. */
{

}
NoAccessException::NoAccessException(const NoAccessException& except_in) noexcept		/* Copy Constructor. */
{

}
NoAccessException::~NoAccessException() noexcept								/* Destructor. */
{

}
////////////////////////////
// Overloaded Operators:
////////////////////////////
NoAccessException& NoAccessException::operator=(const NoAccessException& except_in) noexcept	/* Assignment Operator. */
{
	if (this != &except_in)
	{

	}
	return *this;
}
