/* ConsoleShapeFactory.hpp (exercise 6.7)
Description:
	* Derived class from ShapeFactory that creates instances of derived Shape classes (Circle, Point, Line).
Class Members:
	* 



*/


#ifndef CONSOLESHAPEFACTORY_HPP
#define CONSOLESHAPEFACTORY_HPP

class ConsoleShapeFactory
{


};




#endif