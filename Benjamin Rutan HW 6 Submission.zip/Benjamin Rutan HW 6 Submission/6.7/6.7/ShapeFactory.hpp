/* ShapeFactory.hpp (exercise 6.7)
Description:
	*




*/


#ifndef SHAPEFACTORY_HPP
#define SHAPEFACTORY_HPP





#endif