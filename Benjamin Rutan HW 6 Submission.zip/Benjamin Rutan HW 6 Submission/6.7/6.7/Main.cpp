/* Main.cpp (exercise 6.7)
Description:
	*


*/


#include <iostream>

int main()
{

	system("pause");

	return 0;
}