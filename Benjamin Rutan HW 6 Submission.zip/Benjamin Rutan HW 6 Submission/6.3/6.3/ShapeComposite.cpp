/* ShapeComposite.cpp (exercise 6.3)
Description:
	* Class houses list of derived Shape classes (Circle, Point, Line), provides iterable functionality.
Member Functions:
	// Constructor/Destructor:
	ShapeComposite(): Default constructor. Initialize shapePtrs list to default initialization.
	~ShapeComposite(): Destructor.
	// Accessors:
	size_t count() const: Return number of elements in the shapePtrs list.
	// Mutators:
	void AddShape(Shape*):
	// Misc. Methods:
	compositeIterator begin(): Return iterator to start of shapePtrs list.
	constCompositeIterator begin() const;	Return const iterator to start of shapePtrs list.
	compositeIterator end(): Return iterator to "end" of shapePtrs list.
	constCompositeIterator end() const: Return const iterator to "end" of shapePtrs list.
*/

#include "ShapeComposite.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
ShapeComposite::ShapeComposite()					/* Default constructor. */
{

}
ShapeComposite::~ShapeComposite()					/* Destructor. */
{
	
}
////////////////////////////
// Accessors:
////////////////////////////
std::size_t ShapeComposite::count() const			/* Return size of shapePtrs list. */
{

}
////////////////////////////
// Mutators:
////////////////////////////
void ShapeComposite::AddShape(Shape* shape_in)		/* Add shape pointer to the shapePtrs list. */
{
	this->shapePtrs.emplace_back(std::make_unique<Shape>(std::move(*shape_in)));
}
////////////////////////////
// Misc. Methods:
////////////////////////////
void ShapeComposite::Print() const										/* Print the ShapeComposite to stdout. */
{
	std::size_t size = shapePtrs.size();
	if (size)
	{
		std::size_t currSize = 1;
		std::cout << "{ ";
		for (auto iter = shapePtrs.begin(); iter != shapePtrs.end(); iter++)
		{
			iter->get()->Print();
			std::cout << ((++currSize != size) ? ", " : " }");
		}
	}
}
ShapeComposite::compositeIterator ShapeComposite::begin()				/* Return iterator to start of shapePtrs list. */
{
	return this->shapePtrs.begin();
}
ShapeComposite::constCompositeIterator ShapeComposite::begin() const	/* Return const iterator to start of shapePtrs list. */
{
	return this->shapePtrs.cbegin();
}
ShapeComposite::compositeIterator ShapeComposite::end()					/* Return iterator to "end" of shapePtrs list. */
{
	return this->shapePtrs.end();
}
ShapeComposite::constCompositeIterator ShapeComposite::end() const		/* Return const iterator to "end" of shapePtrs list. */
{
	return this->shapePtrs.cend();
}
