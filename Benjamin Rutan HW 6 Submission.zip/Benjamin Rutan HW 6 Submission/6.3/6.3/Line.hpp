/*	Line.hpp (exercise 6.3)
Description:
	* Declare Line class that represents a line in 2-D Euclidean space. 
State Variables/Objects:
	*Point p1, p2: Points in 2-D Euclidean space.
Member Functions:
	*Line(): Default constructor (allocates memory for both state Point objects, sets their states to (0,0)).
	*Line(const Point&, const Point&): Overloaded constructor (allocates memory for both state Point objects, sets their states to (0,0)).
	*Line(const Line&): Copy constructor (allocates memory for both state Point objects, sets their states to passed Line's point's states). 
	*~Line(): Destructor (frees memory previously allocated by constructor).
	// Accessors:
	*Point P1() const: Return copy of P1 Point Object.
	*Point P2() const: Return copy of P2 Point Object.
	// Mutators:
	*void P1(const Point&): Change P1's state to state of passed Point object.
	*void P2(const Point&): Change P2's state to state of passed Point object.
	// Misc. Methods:
	*double Length() const: Return length of line. 
	*void Print() const: "Print" the line to stdout.
*/

#ifndef LINE_HPP
#define LINE_HPP

#include<iostream>
#include<string>
#include"Point.hpp"
#include"Shape.hpp"

class Line : public Shape
{
private:
	///////////////////////////
	// State objects: 
	///////////////////////////
	Point p1;						/* First point object. */
	Point p2;						/* Second point object. */
public:
	///////////////////////////
	// Constructors/Destructor: 
	///////////////////////////
	Line();								/* Default Constructor. */
	Line(const Point&, const Point&);	/* Overloaded Constructor. */
	Line(const Line&);					/* Copy Constructor. */
	~Line();							/* Destructor. */
	///////////////////////////
	// Accessors:
	///////////////////////////
	Point P1() const;				/* Returns x value of P1 Point Object. */
	Point P2() const;				/* Returns y value of P2 Point Object. */
	///////////////////////////
	// Mutators:
	///////////////////////////
	void P1(const Point&);			/* Change x value of P1 Point Object. */
	void P2(const Point&);			/* Change y value of P2 Point Object. */
	///////////////////////////
	// Misc. Methods:
	///////////////////////////
	double Length() const;			/* Return the length of the line. */
	void Print() const;				/* "Print" the line to stdout. */
	///////////////////////////
	// Overloaded Operators:
	///////////////////////////
	// Member operators:
	Line& operator=(const Line&);	/* Assignment operator. */
};

#endif