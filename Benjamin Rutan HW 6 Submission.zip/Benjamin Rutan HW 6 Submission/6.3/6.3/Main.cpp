/* Main.cpp (exercise 6.3)
Description:
	* Solutions to problems a-h.
*/

#include <iostream>
#include "Circle.hpp"
#include "Line.hpp"
#include "Point.hpp"
#include "ShapeComposite.hpp"

int main()
{
	// Make several shared_ptrs to derived Shape objects (Point, Line and Circle).
	std::shared_ptr<Shape> p1 = std::make_shared<Point>(new Point(4.0, 3.0));
	std::shared_ptr<Shape> l1 = std::make_shared<Line>(new Line(Point(12.0, 14.0), Point(23.0, 13.0)));
	std::shared_ptr<Shape> c1 = std::make_shared<Circle>(new Circle(Point(1.0, 2.0), 2.0));
	
	// h) Test ShapeComposite class:
	ShapeComposite *sc1 = new ShapeComposite(); 
	std::shared_ptr<Shape> sc1Shared = std::make_shared<ShapeComposite>(sc1);
	ShapeComposite sc2;
	sc1->AddShape(p1);
	sc1->AddShape(l1);
	sc1->AddShape(c1); 
	sc2.AddShape(sc1Shared);
	
	// Print all objects in the sc1 ShapeComposite:
	std::cout << "ShapeComposite1: ";
	sc1->Print(); std::cout << std::endl;
	std::cout << "ShapeComposite2: ";
	sc2.Print(); std::cout << std::endl;

	delete sc1;
	
	system("pause");

	return 0;
}