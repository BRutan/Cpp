/* Main.cpp (exercise 6.3)
Description:
	*

*/

#include <iostream>
#include "Circle.hpp"
#include "Line.hpp"
#include "Point.hpp"
#include "ShapeComposite.hpp"

int main()
{
	Point *p1 = new Point(4.0, 3.0);
	Line *l1 = new Line(Point(12.0, 14.0), Point(23.0, 13.0));
	Circle *c1 = new Circle(Point(1.0, 2.0), 2.0);

	// h) Test ShapeComposite class:
	ShapeComposite sc1, *sc2 = new ShapeComposite();
	sc1.AddShape(p1);
	sc1.AddShape(l1);
	sc1.AddShape(c1); 
	sc2->AddShape(new Point(12.0, 3.0));
	sc2->AddShape(new Line(Point(13.0, 2.0), Point(4.0, 5.0)));
	// Add sc2 to first shape:
	sc1.AddShape(sc2); 

	// Print all objects in the sc1 ShapeComposite:
	sc1.Print();


	system("pause");

	return 0;
}