/* Main.cpp (exercise 6.3)
Description:
	*

*/

#include <iostream>
#include "Circle.hpp"
#include "Line.hpp"
#include "Point.hpp"
#include "ShapeComposite.hpp"

int main()
{
	Point p1(4.0, 3.0);
	Line l1(Point(12.0, 14.0), Point(23.0, 13.0));

	// h) Test ShapeComposite class:
	ShapeComposite sc1;
	



	system("pause");

	return 0;
}