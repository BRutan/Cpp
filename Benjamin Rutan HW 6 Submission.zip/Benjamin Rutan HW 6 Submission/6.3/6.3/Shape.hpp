/* Shape.hpp (exercise 6.3)
Description:
	*Header file for Shape class, declares member variables/objects and functions.
Member Functions:
	// Constructors/Destructor:
	*Shape(): Default constructor.
	*Shape(const Shape&): Copy constructor.
	*virtual ~Shape(): Destructor.
	// Misc. Methods:
	void Print() const: PVMF to make class abstract. 
*/

#ifndef SHAPE_HPP
#define SHAPE_HPP

class Shape
{
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	Shape();								/* Default Constructor. */
	Shape(const Shape&);					/* Copy Constructor. */
	virtual ~Shape();						/* Destructor. */
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	virtual void Print() const = 0;						/* Prints string representation of Shape. */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	Shape& operator=(const Shape&);			/* Assignment operator (with Shape). */
};

#endif