/* ShapeComposite.hpp (exercise 6.3)
Description:
	* Class houses list of derived Shape classes (Circle, Point, Line), provides iterable functionality.
Member Functions:
	// Constructor/Destructor:
	ShapeComposite(): Default constructor. Initialize shapePtrs list to default initialization.
	~ShapeComposite(): Destructor.
	// Accessors:
	size_t count() const: Return number of elements in the shapePtrs list.
	// Mutators:
	void AddShape(Shape*):
	// Misc. Methods:
	compositeIterator begin(): Return iterator to start of shapePtrs list.
	constCompositeIterator begin() const;	Return const iterator to start of shapePtrs list.
	compositeIterator end(): Return iterator to "end" of shapePtrs list.
	constCompositeIterator end() const: Return const iterator to "end" of shapePtrs list.
*/

#ifndef SHAPECOMPOSITE_HPP
#define SHAPECOMPOSITE_HPP

#include <iostream>
#include <list>
#include <memory>
#include <sstream>
#include "Shape.hpp"

class ShapeComposite : public Shape
{
private:
	std::list<std::unique_ptr<Shape>> shapePtrs;
	ShapeComposite(const ShapeComposite&);				// Private copy constructor.
	ShapeComposite& operator=(const ShapeComposite&);	// Private assignment operator.
public:
	typedef std::list<std::unique_ptr<Shape>>::iterator compositeIterator;
	typedef std::list<std::unique_ptr<Shape>>::const_iterator constCompositeIterator;
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	ShapeComposite();					/* Default constructor. */
	virtual ~ShapeComposite();			/* Destructor. */
	////////////////////////////
	// Accessors:
	////////////////////////////
	std::size_t count() const;			/* Return size of shapePtrs list. */
	////////////////////////////
	// Mutators:
	////////////////////////////
	void AddShape(Shape*);				/* Add shape pointer to the shapePtrs list. */
	////////////////////////////
	// Misc. Methods:
	////////////////////////////
	virtual void Draw() const;			/* "Draw" the ShapeComposite to stdout. */
	compositeIterator begin();			/* Return iterator to start of shapePtrs list. */
	constCompositeIterator begin() const;	/* Return const iterator to start of shapePtrs list. */
	compositeIterator end();			/* Return iterator to "end" of shapePtrs list. */
	constCompositeIterator end() const; /* Return const iterator to "end" of shapePtrs list. */
	virtual void Print() const;			/* Print each Shape object to stdout. */
	virtual std::string ToString() const; /* Convert ShapeComposite to string. */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	friend std::ostream& operator<<(std::ostream &out, const ShapeComposite &in)
	{
		std::size_t currSize = 1, size = in.shapePtrs.size();
		out << "{ ";
		for (auto elem : in.shapePtrs)
		{
			elem->get()->Print();
			std::cout << ((++currSize != size) ? ", " : " }\n");
		}
		return out;
	}
};

#endif