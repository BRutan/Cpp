/* Main.cpp (exercise 5.10.1)
Description:
	* Solutions to problems a-d.
*/

#include <boost\numeric\ublas\matrix.hpp>
#include <boost\numeric\ublas\matrix_sparse.hpp>
#include <boost\numeric\ublas\triangular.hpp>
#include <boost\numeric\ublas\vector.hpp>
#include <iostream>


int main()
{
	// a) Create vector:
	boost::numeric::ublas::vector<double> v1(20, 40); // Set all 20 values to 40.

	// Access elements:
	std::cout << "v1[1]: " << v1[1] << std::endl;
	std::cout << "v1(1): " << v1(1) << std::endl;

	// b) Create additional vector and perform operations:
	boost::numeric::ublas::vector<double> v2(20, .5);
	v1 += v2;
	std::cout << "v2[1]: " << v2[1] << std::endl;
	std::cout << "v1 += v2" << std::endl;
	std::cout << "v1[1]: " << v1[1] << std::endl;
	
	v1 *= 2.5;
	std::cout << "v1 *= 2.5" << std::endl;
	std::cout << "v1[1]: " << v1[1] << std::endl;
	v1 -= v2;
	std::cout << "v1 -= v2" << std::endl;
	std::cout << "v1[1]: " << v1[1] << std::endl;

	// c) Use transform and multiply to multiply v1, v2 to produce third vector:
	boost::numeric::ublas::vector<double> v3;
	// std::transform<boost::numeric::ublas::vector<double>,boost::numeric::ublas::vector<double>, void(double)>(v1.begin(), v1.end(), v2.begin(), v3.begin(), std::multiplies<>());

	// d) Produce scalar vector of size 100, with all values equal to 5.0:
	boost::numeric::ublas::scalar_vector<double> scalVec(100, 5.0);

	system("pause");

	return 0;
}