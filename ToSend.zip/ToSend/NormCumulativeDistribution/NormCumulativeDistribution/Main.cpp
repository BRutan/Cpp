

#include <iostream>
#include <iomanip>
#include "NormCumulativeDistFunction.hpp"

int main()
{
	double S_0 = 40;
	double K = 40;
	double r = .05;
	double q = .01;
	double t = .25;
	double sigma = .2;
	double d_1 = ((r - q + (sigma * sigma) / 2.0) * t) / (sigma * std::sqrt(t));
	double d_2 = d_1 - std::sqrt(t) * sigma;
	double price = S_0 * std::exp(-q * t) * NormCumulativeDistFunction(d_1) - K * std::exp(-r * t) * NormCumulativeDistFunction(d_2);
	std::cout << "D1: " << d_1 << std::endl;
	std::cout << "D2: " << d_2 << std::endl;
	std::cout << "N(D1): " << std::setprecision(12) << std::fixed << NormCumulativeDistFunction(d_1) << std::endl;
	std::cout << "N(D2): " << std::setprecision(12) << std::fixed << NormCumulativeDistFunction(d_2) << std::endl;
	std::cout << "Price: " << std::setprecision(12) << std::fixed << price << std::endl;
	
	system("pause");
	
	return 0;
}