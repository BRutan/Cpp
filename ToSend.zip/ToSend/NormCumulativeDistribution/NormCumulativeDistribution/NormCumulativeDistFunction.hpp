#ifndef NORMCUMULATIVEDISTFUNCTION_HPP
#define NORMCUMULATIVEDISTFUNCTION_HPP

#define _USE_MATH_DEFINES
#include <cmath>
#include <math.h>

double NormCumulativeDistFunction(double input)
{
	double z = std::abs(input);
	double y = 1 / (1 + .2316419 * z);
	double a[] = { .319381530, -.356563782, 1.781477937, -1.821255978, 1.330274429 };
	double m = 0, temp;
	for (unsigned i = 0; i < 5; i++)
	{
		temp = a[i];
		for (unsigned j = 0; j < i + 1; j++)
		{
			temp *= y;
		}
		m += temp;
	}
	m *= std::exp(-input * input / 2.0) / std::sqrt(M_PI * 2.0);
	m = 1.0 - m;
	if (input > 0)
	{
		return m;
	}
	else
	{
		return 1.0 - m;
	}
}
#endif