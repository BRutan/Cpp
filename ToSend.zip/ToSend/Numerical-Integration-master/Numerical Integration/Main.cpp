/* Main.cpp
Description:
	* Test the NumericalIntegration class.
*/

#define _USE_MATH_DEFINES

#include <cmath>
#include <math.h>
#include <algorithm>
#include <functional>
#include <iomanip>
#include <iostream>
#include <tuple>
#include <vector>
#include "NumericalIntegration.hpp"
#include "Misc_Functions.hpp"

int main()
{
	FType normPDF = [](double i) { return std::exp(-(i * i) / 2.0) / std::sqrt(2 * M_PI); };
	double S_0 = 40;
	double K = 40;
	double r = .05;
	double q = .01;
	double t = .25;
	double sigma = .2;
	double d_1 = ((r - q + (sigma * sigma) / 2.0) * t) / (sigma * std::sqrt(t));
	double d_2 = d_1 - std::sqrt(t) * sigma;
	double tol = 10E-12;
	// Compute NormCDF for given d_1, d_2:
	NumericalIntegration simpsons(Simpson);
	std::vector<std::tuple<unsigned, double>> results[2];
	results[0] = simpsons.Compute_All(normPDF, -1000, d_1, tol, 4);
	results[1] = simpsons.Compute_All(normPDF, -1000, d_2, tol, 4);
	std::tuple<unsigned, unsigned> stats = std::make_tuple(std::max(results[0].size(), results[1].size()), 0);
	// Display all values:
	for (unsigned j = 0; j < std::get<0>(stats); j++)
	{
		// Print number of intervals:
		std::cout << std::setprecision(1) << std::get<0>(results[std::get<1>(stats)][j]);
		for (unsigned i = 0; i < 2; i++)
		{
			if (j < results[i].size())
			{
				std::cout << "\t" << std::setprecision(12) << std::fixed << std::get<1>(results[i][j]) << " ";
			}
			else
			{
				std::cout << std::setw(14) << std::left << " ";
			}
		}
		std::cout << std::endl;
	}
	// Compute black scholes price using approximations:
	double price = S_0 * std::get<1>(results[0][results[0].size() - 1]) * std::exp(-q * t) - K * std::get<1>(results[1][results[1].size() - 1]) * std::exp(-r * t);

	std::cout << "Black Scholes Price: " << price << std::endl;
	system("pause");

	return 0;
}