/* Misc_Functions.hpp:
Description:
	*	



*/


#ifndef MISC_FUNCTIONS_HPP
#define MISC_FUNCTIONS_HPP

#include <iostream>
#include <iomanip>
#include <tuple>
/*

template<class Tuple>
void print_tuple(const Tuple &tuple)
{
	static std::size_t size = std::tuple_size<Tuple>::value;

}


template<class Tuple, std::size_t N>
void print_tuple_helper(const Tuple &tuple)
{
	print_tuple_helper(tuple,  
	std::cout << ", " << std::get<N>(Tuple);
}

template<class Tuple>
void print_tuple_helper(std::ostream &os, std::tuple<T...> &tuple)
{
	return os;
}

template<std::size_t> 
struct temp 
{

};
*/
#endif
