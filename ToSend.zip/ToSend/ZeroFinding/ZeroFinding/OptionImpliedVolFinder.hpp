/* OptionImpliedVolFinder.hpp
Description:
	* 



*/


#ifndef OPTIONIMPLIEDVOLFINDER_HPP
#define OPTIONIMPLIEDVOLFINDER_HPP


#include <fstream>
#include <regex>
#include <string>
#include <sstream>
#include <tuple>
#include <vector>
#include "EuropeanOption.hpp"
#include "OptionElement.hpp"
#include "Option.hpp"
#include "ZeroFinding.hpp"
#include "OptionIterationCounter.hpp"

class OptionImpliedVolFinder
{
private:
	std::vector<OptionElement> _Options;
	OptionIterationCounter _Counter;
public:
	OptionImpliedVolFinder();
	virtual ~OptionImpliedVolFinder();
	std::vector<OptionElement>& GetOptions();
	OptionIterationCounter& GetCounter();
	void AddOption(const OptionElement &elem);
	void PullFromCSV(const std::string &path);
	void ComputeAllIVs(double x_0, double tol_approx, double tol_consec);
	void PrintAllOptionsToCSV(const std::string &path);
	void PrintCounterToCSV(const std::string &outputPath, std::size_t precision);
};

#endif