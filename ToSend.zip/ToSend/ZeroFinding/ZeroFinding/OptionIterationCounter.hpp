

#ifndef OptionIterationCounter_HPP
#define OptionIterationCounter_HPP

#include <fstream>
#include <iomanip>
#include <set>
#include <sstream>
#include <string>
#include <vector>
#include "EuropeanOption.hpp"
#include "Option.hpp"
#include "OptionIterationRow.hpp"

class OptionIterationCounter
{
private:
	std::vector<std::pair<Options::Option*, std::set<OptionIterationRow, OptionRowComparer>>>_Tracker;
public:
	OptionIterationCounter();
	~OptionIterationCounter();
	std::vector<std::pair<Options::Option*, std::set<OptionIterationRow, OptionRowComparer>>>& GetTracker();
	void AppendData(Options::Option *option, const std::set<OptionIterationRow, OptionRowComparer> &data);
	void PrintToCSV(const std::string &path, std::size_t precision);
	OptionIterationCounter& operator=(const OptionIterationCounter &input);
};

#endif
