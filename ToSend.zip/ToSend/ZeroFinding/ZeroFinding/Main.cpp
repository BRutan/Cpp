/* Main.cpp
Description:
	* 




*/
#define _USE_MATH_DEFINES

#include <array>
#include <cmath>
#include <functional>
#include <math.h>
#include <iostream>
#include "EuropeanOption.hpp"
#include "OptionImpliedVolFinder.hpp"
#include "ZeroFinding.hpp"

int main()
{
	/*
	ZeroFinding finder;
	Options::EuropeanOption option(3.0 / 12.0, 30, 20, .025, .01, .025, .3, true);
	std::function<double(double)> Delta_mod = [&option](double K) 
	{ 
		option.Param("k", K); 
		return option.Delta() - .5; 
	};
	std::function<double(double)> SPSensitivity_mod = [&option](double K) 
	{ 
		option.Param("k", K); 
		return -Options::EuropeanOption::normPDF(option.D1()) / (K * option.Param("sigma") * std::sqrt(option.Param("t"))); 
	};
	double tol_consec, tol_approx;
	tol_approx = tol_consec = 10E-6;
	double x_new, x_old;
	x_old = 30;
	x_new = x_old;
	std::vector<std::array<double, 3>> results;
	std::array<double, 3> temp;
	double count = 0;
	temp.at(0) = count++;
	temp.at(1) = x_new;
	temp.at(2) = Delta_mod(x_new) + .5;
	results.push_back(temp);
	while (std::abs(Delta_mod(x_new)) > tol_approx || std::abs(x_new - x_old) > tol_consec)
	{
		x_old = x_new;
		x_new = x_old - (Delta_mod(x_old) / SPSensitivity_mod(x_old));
		temp.at(0) = count++;
		temp.at(1) = x_new;
		temp.at(2) = Delta_mod(x_new) + .5;
		results.push_back(temp);
	}
	option.Param("k", x_new);
	std::cout << "K = " << std::setprecision(6) << std::fixed << x_new << std::endl;;
	std::cout << "Delta: " << std::setprecision(6) << std::fixed << option.Delta() << std::endl;
	// Print results of each step:
	std::cout << "Step:\t\t" << "X_new:\t\t" << "Delta" << std::endl;
	for (auto iter : results)
	{
		for (auto iter2 : iter)
		{
			std::cout << std::setprecision(6) << std::fixed << iter2 << "\t\t";
		}
		std::cout << std::endl;
	}
	*/

	OptionImpliedVolFinder finder;
	finder.PullFromCSV("C:\\Users\\e652171\\Desktop\\Options.csv");
	finder.ComputeAllIVs(.3, 10E-6, 10E-6);
	finder.PrintAllOptionsToCSV("C:\\Users\\e652171\\Desktop\\Results.csv");

	system("pause");

	return 0;
}