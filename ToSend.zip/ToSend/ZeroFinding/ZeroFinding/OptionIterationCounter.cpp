#include "OptionIterationCounter.hpp"
#include "OptionIterationRow.hpp"


#pragma region Constructors/Destructor
OptionIterationCounter::OptionIterationCounter() : _Tracker()
{

}
OptionIterationCounter::~OptionIterationCounter()
{

}
#pragma endregion
#pragma region Accessors
std::vector<std::pair<Options::Option*, std::set<OptionIterationRow, OptionRowComparer>>>& OptionIterationCounter::GetTracker()
{
	return this->_Tracker;
}
#pragma endregion
#pragma region Mutators
void OptionIterationCounter::AppendData(Options::Option *option, const std::set<OptionIterationRow, OptionRowComparer> &data)
{
	this->_Tracker.push_back(std::make_pair(option, data));
}
#pragma endregion
#pragma region Class Methods
void OptionIterationCounter::PrintToCSV(const std::string &outputPath, std::size_t precision)
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Print all elements to provided file, overwriting if necessary.
	if (this->_Tracker.size())
	{
		// Throw exception if intended file is not csv or could not create the file:
		if (outputPath.find(".csv") == std::string::npos)
		{
			throw std::exception("File must be csv.");
		}
		std::ofstream file(outputPath);
		if (!file.good())
		{
			throw std::exception("Could not create file at path.");
		}
		std::stringstream ss("");
		// Print the headers:
		ss << "------------------------------------------------------------------------------------\n";
		file.write(ss.str().c_str(), ss.str().length());
		ss.str("");
		for (auto &option : this->_Tracker)
		{
			ss << "Option Description: " << option.first->Description() << "\n";
			file.write(ss.str().c_str(), ss.str().length());
			ss.str("");
			ss << "Step #,Price,IV\n";
			file.write(ss.str().c_str(), ss.str().length());
			for (auto &row : option.second)
			{
				ss.str("");
				ss << row.stepNum << "," << std::setprecision(precision) << std::fixed << row.IV << "\n";
				file.write(ss.str().c_str(), ss.str().length());
			}
			ss.str("");
			ss << "------------------------------------------------------------------------------------\n";
			file.write(ss.str().c_str(), ss.str().length());
		}
		file.close();
	}
}
#pragma endregion
#pragma region Overloaded Operators
OptionIterationCounter& OptionIterationCounter::operator=(const OptionIterationCounter &input)
{
	if (this != &input)
	{
		this->_Tracker = input._Tracker;
	}
	return *this;

}
#pragma endregion