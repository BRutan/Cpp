#ifndef OPTIONITERATIONROW_HPP
#define OPTIONITERATIONROW_HPP

#include <iostream>

struct OptionIterationRow
{
public:
	std::size_t stepNum;
	double Price;
	double IV;
	OptionIterationRow() : stepNum(0), Price(0), IV(0)
	{

	}
};

class OptionRowComparer
{
public:
	const bool operator()(const OptionIterationRow &A, const OptionIterationRow &B) const
	{
		return A.stepNum < B.stepNum;
	}
};

#endif