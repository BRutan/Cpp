/*




*/


#include "OptionImpliedVolFinder.hpp"

#pragma region Constructors/Destructor
OptionImpliedVolFinder::OptionImpliedVolFinder() : _Options(), _Counter()
{

}
OptionImpliedVolFinder::~OptionImpliedVolFinder()
{

}
#pragma endregion
#pragma region Accessors
std::vector<OptionElement>& OptionImpliedVolFinder::GetOptions()
{
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// 
	return this->_Options;
}
OptionIterationCounter& OptionImpliedVolFinder::GetCounter()
{
	return this->_Counter;
}
#pragma endregion

#pragma region Mutators

#pragma endregion

#pragma region Class Methods
void OptionImpliedVolFinder::AddOption(const OptionElement &elem)
{
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Add element to options list.
	this->_Options.push_back(elem);
}
void OptionImpliedVolFinder::ComputeAllIVs(double sigma_0, double tol_approx, double tol_consec)
{
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Use Newton's Method to compute all implied volatilities of stored options.
	double marketPrice;
	double sigma_old;
	double sigma_new;
	OptionIterationRow newRow;
	std::set<OptionIterationRow, OptionRowComparer> steps;
	for (auto &iter : this->_Options)
	{
		// Market price is second element of tuple:
		marketPrice = iter.price;
		// Start with passed guess value for implied volatility:
		sigma_new = sigma_0;
		iter.option.Param("sigma", sigma_new);
		while (std::abs(iter.option.Price() - marketPrice) > tol_approx || std::abs(sigma_new - sigma_old) > tol_consec)
		{
			sigma_old = sigma_new;
			sigma_new = sigma_old - ((iter.option.Price() - marketPrice) / iter.option.Vega());
			iter.option.Param("sigma", sigma_new);
		}
		// Update the option's iv with computed value:
		iter.option.Param("sigma", sigma_new);
	}
}
void OptionImpliedVolFinder::PullFromCSV(const std::string &path)
{
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Pull in options from CSV file.
	std::ifstream file(path);
	if (!file.good())
	{
		throw std::exception(("Could not open file at path " + path + ".").c_str());
	}
	std::string currLine;
	std::regex comma(",");
	std::string params[] = {"s", "k", "r", "t"};
	unsigned index;
	bool isCall;
	double marketPrice;
	OptionElement _option;
	while (!file.eof())
	{
		std::getline(file, currLine);
		// Skip blank lines:
		if (!currLine.empty())
		{
			std::sregex_token_iterator iter(currLine.begin(), currLine.end(), comma, -1);
			std::sregex_token_iterator end;
			index = 0;
			while (iter != end && index < 6)
			{
				if (!index)
				{
					// Set the option type:
					isCall = ((*iter == "P") ? false : true);
				}
				else if (index != 5)
				{
					_option.option.Param(params[index - 1], std::stod(*iter));
				}
				else
				{
					// Get the option price.
					_option.price = std::stod(*iter);
				}
				index++;
				iter++;
			}
			_option.option.Type(isCall);
			// Append option to stored options:
			this->_Options.push_back(_option);
		}
	}
	file.close();
}
void OptionImpliedVolFinder::PrintAllOptionsToCSV(const std::string &path)
{
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Write results to CSV file.
	std::ofstream outputFile(path);
	if (path.find(".csv") == std::string::npos)
	{
		throw std::exception("File must be csv file.");
	}
	else if (!outputFile.good())
	{
		throw std::exception("Could not write to file at provided path.");
	}
	std::stringstream currLine;
	std::string headerLine = "S,K,Sigma,r,t,Type,Market Price\n";
	std::string params[] = { "s", "k", "sigma", "r", "t" };
	double _sigma;
	unsigned index;
	outputFile.write(headerLine.c_str(), headerLine.length());
	for (auto &iter : this->_Options)
	{
		index = 0;
		currLine.str("");
		currLine << iter.option.Param(params[index]);
		for (index = 1; index < 7; index++)
		{
			if (index < 5)
			{
				currLine << "," << iter.option.Param(params[index]);
			}
			else if (index == 5)
			{
				currLine << "," << ((iter.option.Type()) ? "C" : "P");
			}
			else
			{
				currLine << "," << iter.price;
			}
		}
		currLine << "\n";
		outputFile.write(currLine.str().c_str(), currLine.str().length());
	}
	outputFile.close();
}
void OptionImpliedVolFinder::PrintCounterToCSV(const std::string &outputPath, std::size_t precision)
{
	this->_Counter.PrintToCSV(outputPath, precision);
}
#pragma endregion

