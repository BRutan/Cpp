#ifndef OPTIONELEMENT_HPP
#define OPTIONELEMENT_HPP

#include "EuropeanOption.hpp"
#include "Option.hpp"

struct OptionElement
{
public:
	Options::EuropeanOption option;
	double price;
};

#endif