/* BootstrapIterationRow.hpp
Description:
	* Abstract an iteration row in determining the yield curve for a particular bond. Tenors are expected to be unique in the BootstrapIterationCounter container.



*/

#ifndef BOOTSTRAPITERATIONROW_HPP
#define BOOTSTRAPITERATIONROW_HPP

struct BootstrapIterationRow
{
public:
	unsigned stepNum;
	double approxValue;
	double tenor;
	BootstrapIterationRow() : tenor(0), stepNum(0), approxValue(0)
	{

	}
}; 

#endif