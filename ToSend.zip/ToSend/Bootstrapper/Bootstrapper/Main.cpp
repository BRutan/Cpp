/* Main.cpp
Description:
	*




*/


#include "BootstrapDataRow.hpp"
#include "BootstrapMatrix.hpp"
#include "Linearbootstrapper.hpp"

int main()
{
	LinearBootstrapper strapper;
	strapper.Data().PullFromCSV("C:\\Users\\e652171\\Desktop\\Advanced Calculus Course\\Test\\Bonds.txt");
	// Test the linear bootstrapping method (using on rate):
	YieldCurve results = strapper.Bootstrap(.05, 10E-6, 10E-6, .015);

	results.PrintToCSV("C:\\Users\\e652171\\Desktop\\Advanced Calculus Course\\Test\\Output.csv");
	strapper.PrintCounterCSV("C:\\Users\\e652171\\Desktop\\Advanced Calculus Course\\Test\\Counter2.csv", 6);

	return 0;
}