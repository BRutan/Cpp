/* BootstrapIterationCounter.hpp
Description:
	*




*/


#ifndef BOOTSTRAPITERATIONCOUNTER_HPP
#define BOOTSTRAPITERATIONCOUNTER_HPP

#include <array>
#include <map>
#include <fstream>
#include <set>
#include <sstream>
#include <vector>
#include "BootstrapDataRow.hpp"
#include "BootstrapIterationRow.hpp"

class Comparer
{
public:
	const bool operator()(const BootstrapIterationRow &A, const BootstrapIterationRow &B) const
	{
		return A.stepNum < B.stepNum;
	}
	const bool operator()(const double A, const double B) const
	{
		return A < B;
	}
};

class BootstrapIterationCounter
{
private:
	/////////////////////////////
	// Class Members:
	/////////////////////////////
	std::map<double, std::set<BootstrapIterationRow, Comparer>, Comparer> _Data;
	std::size_t precision;
public:
	/////////////////////////////
	// Constructor/Destructor:
	/////////////////////////////
	BootstrapIterationCounter();
	virtual ~BootstrapIterationCounter();
	/////////////////////////////
	// Accessors:
	/////////////////////////////
	std::size_t Size();
	std::set<double, Comparer> GetAllTenors();
	std::set<BootstrapIterationRow, Comparer>& Rows(double tenor);
	/////////////////////////////
	// Class Methods:
	/////////////////////////////
	void PrintToCSV(const std::string &outputPath, const std::size_t &precision);
	/////////////////////////////
	// Mutators:
	/////////////////////////////
	void Clear();
	void Row(const BootstrapIterationRow &newRow, double tenor);
	void Rows(const std::set<BootstrapIterationRow, Comparer> &rows, double tenor);
	/////////////////////////////
	// Overloaded Operators:
	/////////////////////////////
	BootstrapIterationCounter& operator=(const BootstrapIterationCounter&);
};

#endif
