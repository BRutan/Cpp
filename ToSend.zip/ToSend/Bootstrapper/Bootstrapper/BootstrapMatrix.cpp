/* BootstrapMatrix.cpp
Description:
	*



*/

#include <algorithm>
#include <fstream>
#include <iterator>
#include <map>
#include <regex>
#include <sstream>
#include <vector>
#include "BootstrapDataRow.hpp"
#include "BootstrapMatrix.hpp"

#pragma region Constructors/Destructor
BootstrapMatrix::BootstrapMatrix() : _Data(), _firstZCBTenor(), _HasZCB()
{

}
BootstrapMatrix::~BootstrapMatrix()
{

}
#pragma endregion
#pragma region Accessors
BootstrapDataRow& BootstrapMatrix::GetDataRow(double tenor)
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Return data row of given tenor.
	// Return if present:
	if (this->_Data.find(tenor) != this->_Data.end())
	{
		return this->_Data.at(tenor);
	}
}
std::vector<double> BootstrapMatrix::GetAllTenors(bool Ascending)
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Return vector containing all of the tenors loaded into the matrix.
	std::vector<double> output;
	std::transform(this->_Data.begin(), this->_Data.end(), std::back_inserter(output), RetrieveKey());
	return output;
}
double BootstrapMatrix::GetFirstZCBTenor()
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Return the first zero coupon bond's tenor.
	double earliestZCBTenor = this->_Data.begin()->second.Tenor;
	for (auto &iter : this->_Data)
	{
		if (iter.first < earliestZCBTenor)
		{
			earliestZCBTenor = iter.first;
		}
	}
	return earliestZCBTenor;
}
bool BootstrapMatrix::HasZCB()
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	return this->_HasZCB;
}
unsigned BootstrapMatrix::Size()
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Return number of rows in matrix.
	return this->_Data.size();
}
#pragma endregion
#pragma region Mutators
void BootstrapMatrix::AddDataRow(double tenor, BootstrapDataRow row)
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Add row of data to matrix if tenor has not been added yet.
	if (this->_Data.find(tenor) == this->_Data.end())
	{
		this->_Data.emplace(tenor, row);
		if (row.CouponRate == 0)
		{
			this->_HasZCB = true;
		}
	}
	else
	{
		throw std::exception("Tenor has already been loaded.");
	}
}
void BootstrapMatrix::Clear()
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Reset the matrix.
	this->_HasZCB = false;
	this->_firstZCBTenor = 0.0;
	this->_Data.clear();
}
void BootstrapMatrix::PullFromCSV(const std::string &path)
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Pull data from CSV file at given path.
	this->_Data.clear();
	BootstrapDataRow newRow;
	std::ifstream file(path.c_str());
	std::string currLine;
	std::regex csv(",");
	unsigned count;
	double currTenor;
	bool present;
	if (!file.good())
	{
		throw std::exception(("Could not open file at " + path + ".").c_str());
	}
	// Pull in all contents (assumes columns are { Tenor, Coupon Rate, Price, Face Value, Pmt Freq }):
	while (!file.eof())
	{
		std::getline(file, currLine);
		// Skip if line is blank:
		if (!currLine.empty())
		{
			// Split the CSV line:
			std::sregex_token_iterator iter(currLine.begin(), currLine.end(), csv, -1);
			std::sregex_token_iterator end;
			currTenor = 0;
			count = 0;
			present = false;
			while (iter != end && count < 5)
			{
				if (!count)
				{
					// Set the primary key of the row (Tenor):
					currTenor = std::stod(*iter);
					// If tenor already present in database then skip:
					if (this->_Data.find(currTenor) != this->_Data.end())
					{
						present = true;
						break;
					}
				}
				else
				{
					// Set the row item:
					newRow.SetItem(count, std::stod(*iter));
				}
				count++;
				iter++;
			}
			// Append to map if tenor is not present:
			if (!present)
			{
				// Append to data map:
				newRow.Tenor = currTenor;
				this->_Data.emplace(currTenor, newRow);
				// Indicate that zero coupon bond is present in data:
				if (newRow.CouponRate == 0.0)
				{
					this->_HasZCB = true;
				}
			}
		}
	}
	// Close file:
	file.close();
	// Determine the first zero coupon bond tenor:

}
#pragma endregion
#pragma region Overloaded Operators
BootstrapMatrix& BootstrapMatrix::operator=(const BootstrapMatrix &input)
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Assignment operator.
	if (this != &input)
	{
		this->_Data = input._Data;
		this->_firstZCBTenor = input._firstZCBTenor;
		this->_HasZCB = input._HasZCB;
	}
	return *this;
}
#pragma endregion
