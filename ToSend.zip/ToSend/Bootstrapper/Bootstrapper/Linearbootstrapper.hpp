/* Linearbootstrapper.hpp
Description:
	* 

	NOTE: earliest tenor bond must be a ZCB or else will fail.
*/

#ifndef LINEARBOOTSTRAPPER_HPP
#define LINEARBOOTSTRAPPER_HPP

#include <array>
#include <functional>
#include <map>
#include "BootstrapMatrix.hpp"
#include "BootstrapDataRow.hpp"
#include "BootstrapIterationCounter.hpp"
#include "BootstrapIterationRow.hpp"
#include "YieldCurve.hpp"
#include "ZeroFinding.hpp"

using Func = std::function<double(double, double, double)>;

class LinearBootstrapper
{
private:
	/////////////////////////////
	// Class Members:
	/////////////////////////////
	BootstrapIterationCounter _Counter;
	BootstrapMatrix _Data; // { Tenor -> { Coupon Rate, Price, Face Value, Pmt Freq }}
	double Rate(double Price, double FaceValue, double tenor);
	void NewtonsMethod(double x_0, double tol_approx, double tol_consec, BootstrapDataRow bond, YieldCurve &currentCurve);
public:
	/////////////////////////////
	// Constructors/Destructor:
	/////////////////////////////
	LinearBootstrapper();
	~LinearBootstrapper();
	/////////////////////////////
	// Accessors:
	/////////////////////////////
	BootstrapMatrix& Data();
	BootstrapIterationCounter& Counter();
	/////////////////////////////
	// Mutators:
	/////////////////////////////
	void Data(const BootstrapMatrix&);	
	/////////////////////////////
	// Class Methods:
	/////////////////////////////
	YieldCurve Bootstrap(double x_0, double tol_approx, double tol_consec, double onRate = 0.0);
	void PrintCounterCSV(const std::string &outputPath, const std::size_t &precision);
	/////////////////////////////
	// Overloaded Operators:
	/////////////////////////////
	LinearBootstrapper& operator=(const LinearBootstrapper&);
};

#endif
