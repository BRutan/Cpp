/* BootstrapMatrix.hpp
Description:
	* 



*/


#ifndef BOOTSTRAPMATRIX_HPP
#define BOOTSTRAPMATRIX_HPP

#include <algorithm>
#include <fstream>
#include <iterator>
#include <map>
#include <sstream>
#include <string>
#include <vector>
#include "BootstrapDataRow.hpp"
#include "BootstrapIterationCounter.hpp"

class BootstrapMatrix
{
private:
	struct RetrieveKey
	{
		template <typename T>
		typename T::first_type operator()(T keyValuePair) const
		{
			return keyValuePair.first;
		}
	};
	std::map<double, BootstrapDataRow> _Data;
	double _firstZCBTenor;
	bool _HasZCB;
public:
	///////////////////////////
	// Constructors/Destructor:
	///////////////////////////
	BootstrapMatrix();
	virtual ~BootstrapMatrix();
	///////////////////////////
	// Accessors:
	///////////////////////////
	double GetFirstZCBTenor();
	bool HasZCB();
	BootstrapDataRow& GetDataRow(double tenor);
	std::vector<double> GetAllTenors(bool Ascending);
	unsigned Size();
	///////////////////////////
	// Mutators:
	///////////////////////////
	void AddDataRow(double tenor, BootstrapDataRow row);
	void Clear();
	void PullFromCSV(const std::string &path);
	///////////////////////////
	// Overloaded Operators:
	///////////////////////////
	BootstrapMatrix& operator=(const BootstrapMatrix&);
};

#endif
