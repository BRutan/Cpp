/* YieldCurve.hpp
Description:
	* Object models zero-rate yield curve. 
Class Members:
	* std::map<double, double> _ZeroRates: Map { Tenor -> Zero Rate }. 
	* double _TerminalTenor: E


*/

#ifndef YIELDCURVE_HPP
#define YIELDCURVE_HPP

#include <array>
#include <fstream>
#include <map>
#include <sstream>
#include <string>

class YieldCurve
{
private:
	///////////////////////////////
	// Class Members:
	///////////////////////////////
	std::map<double, double> _ZeroRates;
public:
	///////////////////////////////
	// Constructors/Destructor:
	///////////////////////////////
	YieldCurve();
	virtual ~YieldCurve();
	///////////////////////////////
	// Accessors:
	///////////////////////////////
	double Rate(double tenor);
	bool HasTenor(double tenor);
	double EarliestTenor();
	double TerminalTenor();
	///////////////////////////////
	// Mutators:
	///////////////////////////////
	void Rate(double tenor, double rate);
	void RemoveTenor(double tenor);
	///////////////////////////////
	// Methods:
	///////////////////////////////
	void PrintToCSV(const std::string &path);
	///////////////////////////////
	// Overloaded Operators:
	///////////////////////////////
	YieldCurve& operator=(const YieldCurve&);
};

#endif