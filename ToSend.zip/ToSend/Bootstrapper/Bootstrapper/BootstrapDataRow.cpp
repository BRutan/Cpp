/* BootstrapDataRow.cpp
Description:
	* Represent a row in the BootstrapMatrix.
Class Members (all public):
	* double CouponRate: Bond's annualized coupon rate.
	* double FaceValue: Terminal cash flow of bond.
	* unsigned PmtFreq: Number of payments per year.
	* double Price: Bond's market price.
Class Methods:
	* void Clear(): Set all values to 0.
	* void SetItem(unsigned index, double value): Set element at index to given value. (Note: index ordering is { Coupon Rate, Price, Face Value, Pmt Freq }, which corresponds to files.)
*/

#include "BootstrapDataRow.hpp"

#pragma region Constructors/Destructor
BootstrapDataRow::BootstrapDataRow() : Price(0), CouponRate(0), FaceValue(0), PmtFreq(0)
{

}
#pragma endregion
#pragma region Public Methods
void BootstrapDataRow::Clear()
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Reset all columns to 0.
	for (unsigned i = 0; i < 5; i++)
	{
		this->SetItem(i, 0.0);
	}
}
void BootstrapDataRow::SetItem(unsigned index, double value)
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Set column to passed value (Note: index ordering is { Tenor, Coupon Rate, Price, Face Value, Pmt Freq }):
	switch (index)
	{
	case 0:
		this->Tenor = value;
		break;
	case 1:
		this->CouponRate = value;
		break;
	case 2:
		this->Price = value;
		break;
	case 3:
		this->FaceValue = value;
		break;
	case 4:
		this->PmtFreq = value;
		break;
	default:
		break;
	}
}
#pragma endregion

