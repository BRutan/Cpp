/* YieldCurve.cpp




*/

#include <array>
#include <fstream>
#include <map>
#include <sstream>
#include <string>
#include "YieldCurve.hpp"

#pragma region Constructors/Destructor
YieldCurve::YieldCurve() : _ZeroRates()
{

}
YieldCurve::~YieldCurve()
{

}
#pragma endregion
#pragma region Accessors
double YieldCurve::EarliestTenor()
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Return the earliest tenor for known data points with given yield curve.
	double earliestTenor = this->_ZeroRates.begin()->first;
	for (auto &iter : this->_ZeroRates)
	{
		if (earliestTenor > iter.first)
		{
			earliestTenor = iter.first;
		}
	}
	return earliestTenor;
}
bool YieldCurve::HasTenor(double tenor)
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Determine if zero rate for given tenor is present on yield curve.
	if (this->_ZeroRates.find(tenor) == this->_ZeroRates.end())
	{
		return false;
	}
	return true;
}

double YieldCurve::Rate(double tenor)
{	
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Return the rate for the given tenor.
	if (this->_ZeroRates.find(tenor) == this->_ZeroRates.end())
	{
		std::stringstream errMessage("Tenor ");
		errMessage << tenor << " could not be found.";
		throw std::exception(errMessage.str().c_str());
	}
	return this->_ZeroRates.at(tenor);
}
double YieldCurve::TerminalTenor()
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Return the latest tenor present on the curve.
	double terminalTenor = this->_ZeroRates.begin()->first;
	for (auto &iter : this->_ZeroRates)
	{
		if (terminalTenor < iter.first)
		{
			terminalTenor = iter.first;
		}
	}
	return terminalTenor;
}
#pragma endregion
#pragma region Mutators
void YieldCurve::Rate(double tenor, double rate)
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Append a new zero coupon rate if tenor not present already on yield curve, otherwise overwrite the passed tenor's zero rate.
	if (this->_ZeroRates.find(tenor) != this->_ZeroRates.end())
	{
		// Overwrite tenor's rate if already present:
		this->_ZeroRates.at(tenor) = rate;
	}
	else
	{
		// Add new rate to the map:
		this->_ZeroRates.emplace(tenor, rate);
	}
}
void YieldCurve::RemoveTenor(double tenor)
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Remove tenor from map if present.
	if (this->_ZeroRates.find(tenor) != this->_ZeroRates.end())
	{
		this->_ZeroRates.erase(tenor);
	}
}
#pragma endregion
#pragma region Methods
void YieldCurve::PrintToCSV(const std::string &path)
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Print yield curve to CSV.
	std::ofstream file(path);
	if (path.find(".csv") == std::string::npos)
	{
		throw std::exception("File must be csv.");
	}
	if (!file.good())
	{
		throw std::exception("Could not create file at path.");
	}
	std::stringstream ss("");
	// Print the headers:
	ss << "Tenor,Rate\n";
	file.write(ss.str().c_str(), ss.str().length());
	for (auto &iter : this->_ZeroRates)
	{
		ss.str("");
		ss << iter.first << "," << iter.second << "\n";
		file.write(ss.str().c_str(), ss.str().length());
	}
	file.close();
}
#pragma endregion
#pragma region Overloaded Operators
YieldCurve& YieldCurve::operator=(const YieldCurve &input)
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Assignment operator. Copy contents of passed yield curve.
	if (this != &input)
	{
		this->_ZeroRates = input._ZeroRates;
	}
	return *this;
}
#pragma endregion