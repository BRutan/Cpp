/* BootstrapIterationCounter.cpp
Description:
	* 



*/



#include <array>
#include <iomanip>
#include <map>
#include <fstream>
#include <set>
#include <sstream>
#include <vector>
#include "BootstrapDataRow.hpp"
#include "BootstrapIterationRow.hpp"
#include "BootstrapIterationCounter.hpp"

#pragma region Constructors/Destructor
BootstrapIterationCounter::BootstrapIterationCounter() : _Data()
{

}
BootstrapIterationCounter::~BootstrapIterationCounter() 
{

}
#pragma endregion
#pragma region Accessors
std::set<double, Comparer> BootstrapIterationCounter::GetAllTenors()
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Return all tenors in order.
	std::set<double, Comparer> keys;
	for (auto &i : this->_Data)
	{
		keys.emplace(i.first);
	}
	return keys;
}
std::set<BootstrapIterationRow, Comparer>& BootstrapIterationCounter::Rows(double tenor)
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Return row corresponding to tenor.
	if (this->_Data.find(tenor) == this->_Data.end())
	{
		throw std::exception("Tenor corresponding to bond could not be found in the counter.");
	}
	return this->_Data.at(tenor);
}
std::size_t BootstrapIterationCounter::Size()
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Return number of bonds stored in the iteration counter.
	return this->_Data.size();
}
#pragma endregion

#pragma region Class Methods
void BootstrapIterationCounter::PrintToCSV(const std::string &outputPath, const std::size_t &precision)
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Print all elements to provided file, overwriting if necessary.
	if (this->_Data.size())
	{
		// Throw exception if intended file is not csv or could not create the file:
		if (outputPath.find(".csv") == std::string::npos)
		{
			throw std::exception("File must be csv.");
		}
		std::ofstream file(outputPath);
		if (!file.good())
		{
			throw std::exception("Could not create file at path.");
		}
		std::stringstream ss("");
		// Print the headers:
		ss << "------------------------------------------------------------------------------------\n";
		file.write(ss.str().c_str(), ss.str().length());
		ss.str("");
		for (auto &bond : this->_Data)
		{
			ss << "Bond tenor: " << bond.first << "\n";
			file.write(ss.str().c_str(), ss.str().length());
			ss.str("");
			ss << "Step #,PV\n";
			file.write(ss.str().c_str(), ss.str().length());
			for (auto &row: bond.second)
			{
				ss.str("");
				ss << row.stepNum << "," << std::setprecision(precision) << std::fixed << row.approxValue << "\n";
				file.write(ss.str().c_str(), ss.str().length());
			}
			ss.str("");
			ss << "------------------------------------------------------------------------------------\n";
			file.write(ss.str().c_str(), ss.str().length());
		}
		file.close();
	}
}
#pragma endregion

#pragma region Mutators
void BootstrapIterationCounter::Clear()
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Clear the contents.
	this->_Data.clear();
}

void BootstrapIterationCounter::Row(const BootstrapIterationRow &newRow, double tenor)
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Add single iteration row to the container for given bond.
	if (this->_Data.find(tenor) == this->_Data.end())
	{
		// Add new set for given bond tenor:
		this->_Data.emplace(tenor, std::set<BootstrapIterationRow, Comparer>());
	}
	this->_Data.at(tenor).emplace(newRow);
}
void BootstrapIterationCounter::Rows(const std::set<BootstrapIterationRow, Comparer> &rows, double tenor)
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Set all of the 
	if (this->_Data.find(tenor) != this->_Data.end())
	{
		this->_Data.at(tenor) = rows;
	}
	else
	{
		this->_Data.emplace(tenor, rows);
	}
}
#pragma endregion

#pragma region Overloaded Operators
BootstrapIterationCounter& BootstrapIterationCounter::operator=(const BootstrapIterationCounter &input)
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Copy passed object.
	if (this != &input)
	{
		this->_Data = input._Data;
	}
	return *this;

}
#pragma endregion
	