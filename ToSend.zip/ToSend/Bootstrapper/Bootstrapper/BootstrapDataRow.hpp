/* BootstrapDataRow.hpp
Description:
	* Represent a row in the BootstrapMatrix.
Class Members (all public):
	* double CouponRate: Bond's annualized coupon rate.
	* double FaceValue: Terminal cash flow of bond.
	* unsigned PmtFreq: Number of payments per year.
	* double Price: Bond's market price.
Class Methods:
	* void Clear(): Set all values to 0.
	* void SetItem(unsigned index, double value): Set element at index to given value. (Note: index ordering is { Coupon Rate, Price, Face Value, Pmt Freq }, which corresponds to files.)
*/

#ifndef DATAROW_HPP
#define DATAROW_HPP

struct BootstrapDataRow
{
public:
	//////////////////////////////
	// Members:
	//////////////////////////////
	double Tenor;
	double CouponRate;
	double FaceValue;
	unsigned PmtFreq;
	double Price;
	//////////////////////////////
	// Constructors/Destructor:
	//////////////////////////////
	BootstrapDataRow();
	//////////////////////////////
	// Methods: 
	//////////////////////////////
	void Clear();
	void SetItem(unsigned index, double value);
};

#endif