/* LinearBootstrapper.cpp
Description:
	*



*/

#include <array>
#include <functional>
#include <map>
#include <set>
#include "BootstrapMatrix.hpp"
#include "BootstrapDataRow.hpp"
#include "BootstrapIterationCounter.hpp"
#include "Linearbootstrapper.hpp"
#include "YieldCurve.hpp"
#include "ZeroFinding.hpp"

#pragma region Constructors/Destructor
LinearBootstrapper::LinearBootstrapper() : _Data(), _Counter()
{

}
LinearBootstrapper::~LinearBootstrapper()
{

}
#pragma endregion
#pragma region Accessors
BootstrapIterationCounter& LinearBootstrapper::Counter()
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Return the iteration counter of most recent bootstrapping.
	return this->_Counter;
}
BootstrapMatrix& LinearBootstrapper::Data()
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Return the data matrix.
	return this->_Data;
}

#pragma endregion
#pragma region Mutators
void LinearBootstrapper::Data(const BootstrapMatrix &input)
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Copy passed matrix.
	this->_Data = input;
}

#pragma endregion
#pragma region Class Methods
double LinearBootstrapper::Rate(double Price, double FaceValue, double tenor)
{
	// Return rate given above parameters.
	return -std::log(Price / FaceValue) / tenor;
}
YieldCurve LinearBootstrapper::Bootstrap(double x_0, double tol_approx, double tol_consec, double onRate)
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Return a bootstrapped yield curve. 
	YieldCurve output;
	// Reset the iteration counter:
	this->_Counter.Clear();
	// If an overnight rate was passed, then do not necessarily need zero coupon rate:
	auto tenors = this->_Data.GetAllTenors(true);
	if (onRate)
	{
		output.Rate(0, onRate);
	}
	else
	{
		// If no overnight rate passed, then calculate the first zero rate:
		double zcbTenor = this->_Data.GetFirstZCBTenor();
		BootstrapDataRow bond = this->_Data.GetDataRow(zcbTenor);
		output.Rate(zcbTenor, this->Rate(bond.Price, bond.FaceValue, zcbTenor));
	}
	// Calculate the zero coupon bond rate:
	if (!this->_Data.HasZCB() && output.EarliestTenor() != 0)
	{
		throw std::exception("Need at least one zero coupon bond or the overnight rate to perform the bootstrapping.");
	}
	// Fill in the yield curve using Newton's Method with linear interpolation (start with first non-zcb tenor if overnight rate was not specified):
	for (unsigned i = ((onRate) ? 0 : 1); i < this->_Data.Size(); i++)
	{
		this->NewtonsMethod(x_0, tol_approx, tol_consec, this->_Data.GetDataRow(tenors[i]), output);
	}
	return output;
}
void LinearBootstrapper::NewtonsMethod(double x_0, double tol_approx, double tol_consec, BootstrapDataRow bond, YieldCurve &currentCurve)
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Use Newton's Method to set 
	std::map<double, double> CashFlows;			// { Tenor -> Pmt }
	double step = currentCurve.EarliestTenor();
	double stepsize = 1 / ((double) bond.PmtFreq);
	double couponPmt = bond.CouponRate * bond.FaceValue / ((double)bond.PmtFreq);
	double knownPV = 0.0;
	double knownDuration = 0.0;
	double finalKnownRate = currentCurve.Rate(currentCurve.TerminalTenor());
	double terminalTenor = currentCurve.TerminalTenor();
	BootstrapIterationRow newRow;
	newRow.tenor = bond.Tenor;
	// Compute the present value and duration of cash flows for tenors where rate is known:
	while (step <= terminalTenor)
	{
		if (step != 0)
		{
			knownPV += couponPmt * std::exp(-currentCurve.Rate(step) * step);
			knownDuration += -couponPmt * std::exp(-currentCurve.Rate(step) * step) * step;
		}
		step += stepsize;
	}
	// Fill in all future cash flows:
	while (step <= bond.Tenor)
	{
		CashFlows.emplace(step, ((step != bond.Tenor) ? couponPmt : couponPmt + bond.FaceValue));
		step += stepsize;
	}
	auto weightedRate = [](double T, double t_0, double t, double r_0_T, double r_0_t0)
	{
		return ((t - t_0) / (T - t_0) * r_0_T) + ((T - t) / (T - t_0) * r_0_t0);
	};
	// Use this function to calculate present value using linearly interpolated rates:
	std::function<double(double)> PV = [weightedRate, &knownPV, CashFlows, &bond, &currentCurve](double terminalZeroRate)
	{
		double output = 0;
		for (auto iter = CashFlows.begin(); iter != CashFlows.end(); iter++)
		{
			if (iter->first != bond.Tenor)
			{
				// Compute discounted cash flow using weighted rate function:
				output += iter->second * std::exp(-weightedRate(bond.Tenor, currentCurve.TerminalTenor(), iter->first, terminalZeroRate, currentCurve.Rate(currentCurve.TerminalTenor()))* iter->first);
			}
			else
			{
				// Compute discounted cash flow using passed terminal weight (which we are trying to find using Newton's Method):
				output += iter->second * std::exp(-iter->first * terminalZeroRate);
			}
		}
		return output + knownPV;
	};
	// Use this function to calculate first derivative:
	std::function<double(double)> Duration = [weightedRate, &knownDuration, CashFlows, &bond, &currentCurve](double terminalZeroRate)
	{
		// Compute duration using terminalZeroRate:
		double output = 0;
		for (auto iter = CashFlows.begin(); iter != CashFlows.end(); iter++)
		{
			if (iter->first != bond.Tenor)
			{
				// Compute discounted time to cash flow maturity using weighted rate function:
				output += -iter->first * iter->second * std::exp(-weightedRate(bond.Tenor, currentCurve.TerminalTenor(), iter->first, terminalZeroRate, currentCurve.Rate(currentCurve.TerminalTenor()))* iter->first);
			}
			else
			{
				// Compute discounted time to cash flow maturity using passed terminal weight (which we are trying to find using Newton's Method):
				output += -iter->first * iter->second * std::exp(-iter->first * terminalZeroRate);
			}
		}
		return output + knownDuration;
	};
	////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////
	// Use Newton's method and linear interpolation with the profile of the passed bond to compute all later tenor zero rates:
	////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////
	double x_new = x_0;
	double x_old = x_0 - 1;
	while (std::abs(PV(x_new) - bond.Price) > tol_approx || (std::abs(x_new - x_old) > tol_consec))
	{
		// Throw exception if the first derivative is zero at evaluation, since cannot divide by zero:
		newRow.stepNum++;
		newRow.approxValue = PV(x_new);
		this->_Counter.Row(newRow, newRow.tenor);
		if (!(Duration(x_new)))
		{
			throw std::exception("Cannot divide by zero.");
		}
		x_old = x_new;
		x_new = x_old - ((PV(x_old) - bond.Price)/ Duration(x_old));
	}
	// Add final iteration row to the set:
	newRow.stepNum++;
	newRow.approxValue = PV(x_new);
	this->_Counter.Row(newRow, newRow.tenor);
	// Fill in the computed points on the yield curve using x_new (corresponds to terminal rate that satisfies Newton's method):
	step = currentCurve.TerminalTenor() + stepsize;
	while (step <= bond.Tenor)
	{
		currentCurve.Rate(step, (step != bond.Tenor) ? weightedRate(bond.Tenor, currentCurve.TerminalTenor(), step, x_new, finalKnownRate) : x_new);
		step += stepsize;
	}
}
void LinearBootstrapper::PrintCounterCSV(const std::string &outputPath, const std::size_t &precision)
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Print the counts for each bond that was used in bootstrapping contained in the Counter.
	this->_Counter.PrintToCSV(outputPath, precision);
}
#pragma endregion

#pragma region Overloaded Operators
LinearBootstrapper& LinearBootstrapper::operator=(const LinearBootstrapper &input)
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Description:
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Assignment operator.
	if (this != &input)
	{
		this->_Data = input._Data;
	}
	return *this;
}
#pragma endregion
