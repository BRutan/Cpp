/* EmptyState.cpp (exercise 6.9)
Description:
	* Derived StackState class, signifying that stack is empty and altering behavior on Push() / Pop() operations.
Class Members:
	// Constructors/Destructor:
	* EmptyState(): Default constructor.
	* EmptyState(const EmptyState&): Copy constructor.
	* ~EmptyState(): Destructor
	// Misc. Methods:
	* void Push(Stack&, const T&): Push new element onto passed stack.
	* doublePop(Stack&): Throw exception since no elements to remove.
	// Overloaded Operators:
	* EmptyState& operator=(const EmptyState&): Assignment operator.
*/

#ifndef EMPTYSTATE_HPP
#define EMPTYSTATE_HPP

#include <stdexcept>

#include "StackState.hpp"


class Stack;

class EmptyState : public StackState
{	
public:	
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	EmptyState() noexcept;										/* Default constructor. */
	EmptyState(const EmptyState &in) noexcept;					/* Copy constructor. */
	virtual ~EmptyState() noexcept;								/* Destructor. */
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	virtual void Push(Stack &stack_in, const double&in) noexcept;		/* Push new element onto stack. */
	virtual double Pop(Stack &stack_in) const;							/* Throw exception since no elements to pop. */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	EmptyState& operator=(const EmptyState &in) noexcept;		/* Assignment operator. Do nothing since class has no state variables. */
};

#endif