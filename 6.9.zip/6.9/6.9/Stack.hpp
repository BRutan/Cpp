/* Stack.hpp (exercise 6.9)
Description:
	* Template LIFO stack using StackState polymorphism and heap storage for items.
Class Members:
	// Data:
	* double*items[]: Data to store.
	* StackState *state: In {EmptyState, FullState, NotFullNotEmptyState} to delegate further functionality.
	* size_t currIndex, size: Current index of top item, and total size.
	* void Init(size_t): 
	// Constructors/Destructor:
	* Stack(): Default constructor. Set size to 1 and default construct items.
	* ~Stack(): Destructor. Free memory allocated in items.
	// Misc Methods:
	* void Push(const T&): Push copy of new item onto Stack.
	* doublePop(): Remove and return item at currIndex from Stack.
	// Overloaded Operators:
	* Stack& operator=(const Stack&): Assignment operator. Deep copy all items of passed Stack into this Stack.
*/

#ifndef STACK_HPP
#define STACK_HPP

#include <memory>

class StackState;

class Stack
{
private:
	friend class StackState;
	std::shared_ptr<double[]> items;					/* Data to store. */
	std::shared_ptr<StackState> state;			/* State of stack (in {EmptyState, FullState, NotFullNotEmptyState}). */
	int currIndex, size;						/* Current index and size of stack. */
	void Init(int size_in);						/* Initialize the Stack, setting size, currIndex (to 0) and state to EmptyState. */
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	Stack() noexcept;						/* Default constructor. Set size of items[] to 1, currIndex to 0 and stack_state to EmptyState. */
	Stack(std::size_t size_in) noexcept;	/* Overloaded constructor. Set size of items[] to passed index, currIndex to 0 and state_state to EmptyState. */
	Stack(const Stack &stack_in) noexcept;	/* Copy constructor. Copy state of passed Stack object. */
	virtual ~Stack() noexcept;				/* Destructor. Free memory via calling shared_ptr destructor. */
	////////////////////////////
	// Misc. Methods:
	////////////////////////////
	void Push(const double& data_in);			/* Push new element into items. */
	double Pop();								/* Pop top element off of stack. */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	Stack& operator=(const Stack &in) noexcept;	/* Assignment operator. Deep copy all elements in items from passed Stack into this stack. */
};

#endif