/* NotFullNotEmptyState.cpp (exercise 6.9)
Description:
	* Derived StackState class, signifying that stack is neither empty not full, allowing both Push() and Pop() operations.
Class Members:
	// Constructors/Destructor:
	* NotFullNotEmptyState(): Default constructor.
	* NotFullNotEmptyState(const NotFullNotEmptyState&): Copy constructor.
	* ~NotFullNotEmptyState(): Destructor
	// Misc. Methods:
	* void Push(Stack&, const T&): Push new element onto passed stack.
	* doublePop(Stack&): Pop top element from stack.
	// Overloaded Operators:
	* NotFullNotEmptyState& operator=(const NotFullNotEmptyState&): Assignment operator.
*/

#include "StackState.hpp"
#include "Stack.hpp"
#include "NotFullNotEmptyState.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////

NotFullNotEmptyState::NotFullNotEmptyState() noexcept								/* Default constructor. */
{

}

NotFullNotEmptyState::NotFullNotEmptyState(const NotFullNotEmptyState &in) noexcept	/* Copy constructor. */
{

}

NotFullNotEmptyState::~NotFullNotEmptyState() noexcept								/* Destructor. */
{

}
////////////////////////////
// Misc Methods:
////////////////////////////

void NotFullNotEmptyState::Push(Stack &stack_in, const double&value) noexcept		/* Push new element onto stack. */
{
	StackState::Push(stack_in, value);
}

double NotFullNotEmptyState::Pop(Stack &stack_in) const noexcept						/* Pop top element off of stack. */
{
	return StackState::Pop(stack_in);
}
////////////////////////////
// Overloaded Operators:
////////////////////////////

NotFullNotEmptyState& NotFullNotEmptyState::operator=(const NotFullNotEmptyState &in) noexcept	/* Assignment operator. */
{
	if (this != &in)
	{

	}
	return *this;
}

