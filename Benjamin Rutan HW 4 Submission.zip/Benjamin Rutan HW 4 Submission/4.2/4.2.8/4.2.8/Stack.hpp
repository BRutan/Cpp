/* Stack.hpp (exercise 4.2.8)
Description:
	* Solutions to problem 4.2.8.
*/

#ifndef STACK_HPP
#define STACK_HPP

#include <algorithm>
#include <initializer_list>
#include <vector>

template<typename T>
class Stack
{
private:
	std::vector<T> data;
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	Stack() : data()
	{

	}
	Stack(const std::vector<T> data_in) : data(data_in)
	{

	}
	Stack(const std::initializer_list<T> list_in) : data(list_in)
	{

	}
	Stack(const Stack &in) : data(in.data)
	{

	}
	virtual ~Stack()
	{

	}
	////////////////////////////
	// Accessors:
	////////////////////////////
	T top() const
	{
		if (data.size())
			return data[data.size() - 1];
		else
			throw std::out_of_range("");
	}
	////////////////////////////
	// Mutators:
	////////////////////////////
	void push(const T &data_in) noexcept
	{
		data.push_back(data_in);
	}
	void max() noexcept
	{
		if (data.size() >= 2)
		{
			T maxVal = std::max(data[0], data[1]);
			auto iter = data.begin();
			while (iter != data.end())
			{
				if (*iter < maxVal)
				{
					iter = data.erase(iter);
				}
				else
					iter++;
			}
		}
	}
	void min() noexcept
	{
		if (data.size() >= 2)
		{
			T minVal = std::min(data[0], data[1]);
			auto iter = data.begin();
			while (iter != data.end())
			{
				if (*iter > minVal)
				{
					iter = data.erase(iter);
				}
				else
					iter++;
			}
		}
	}
	void over() noexcept
	{
		if (data.size() >= 2)
		{
			data[0] = data[1];
		}
	}
	void rot() noexcept
	{
		if (data.size() >= 3)
		{
			std::swap(data.begin(), data.begin() + 3);
		}
	}
	void swap() noexcept
	{
		if (data.size() >= 2)
		{
			std::swap(data.begin(), data.begin() + 2);
		}
	}
	void drop() noexcept
	{
		if (data.size())
		{
			data.erase(data.begin());
		}
	}
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	Stack& operator=(const Stack &stack_in)
	{
		if (this != &stack_in)
		{
			this->data = stack_in.data;
		}
		return *this;
	}
	Stack& operator=(const std::initializer_list<T> list_in)
	{
		this->data.clear();
		for (auto iter = list_in.begin(); iter != list_in.end(); iter++)
		{
			data.push_back(*iter);
		}
		return *this;
	}
	friend std::ostream& operator<<(std::ostream &out, const Stack &in)
	{
		if (in.data.size())
		{
			out << "{ ";
			for (auto iter = in.data.begin(); iter != in.data.end(); iter++)
			{
				out << *iter << ((iter + 1 != in.data.end()) ? ", " : "");
			}
			out << " }";
		}
		return out;
	}
};


#endif
