/* Main.cpp (exercise 4.2.8)
Description:
	* Solution to exercise.
*/

#include <iostream>
#include "Stack.hpp"

int main()
{
	// Test Stack capabilities:
	Stack<int> test { 1, 4, 5, 6, 2 };
	std::cout << "test: " << test << std::endl;
	test.max();
	std::cout << "test.max(): " << test << std::endl;
	test = { 1, 4, 5, 6, 2 };
	test.min();
	std::cout << "test.min(): " << test << std::endl;
	test = { 1, 4, 5, 6, 2 };
	test.over();
	std::cout << "test.over(): " << test << std::endl;
	test = { 1, 4, 5, 6, 2 };
	test.rot();
	std::cout << "test.rot(): " << test << std::endl;
	test = { 1, 4, 5, 6, 2 };
	test.swap();
	std::cout << "test.swap(): " << test << std::endl;
	test = { 1, 4, 5, 6, 2 };
	test.drop();
	std::cout << "test.drop(): " << test << std::endl;

	system("pause");

	return 0;
}