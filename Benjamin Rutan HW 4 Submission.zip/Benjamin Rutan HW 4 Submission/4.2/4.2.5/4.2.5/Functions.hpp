/* Functions.hpp (exercise 4.2.5)
Description:
	* Provides solutions to problems 


*/

#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP

#include <iostream>
#include <vector>

struct VecTransform
{
	double thresholdValue;
	template<typename ContainerType>
	void operator()(ContainerType &container) noexcept
	{
		auto iter = container.begin();
		while (iter != container.end())
		{
			if (*iter <= thresholdValue)
				iter = container.erase(iter);
			else
				iter++;
		}
	}
};

template<typename T, typename Alloc>
std::ostream& operator<<(std::ostream &out, const std::vector<T, Alloc> &in)
{
	if (in.size())
	{
		out << "{ ";
		for (std::size_t index = 0; index < in.size(); index++)
		{
			out << in[index] << ((index != in.size() - 1) ? ", " : "}");
		}
	}
	return out;
}

#endif
