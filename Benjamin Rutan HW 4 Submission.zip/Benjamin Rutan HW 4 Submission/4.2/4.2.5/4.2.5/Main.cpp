/* Main.cpp (exercise 4.2.5)
Description:
	* Provides solutions to problems a-c for exercise 4.2.5.
*/

#include <algorithm>
#include <functional>
#include <iostream>
#include <vector>
#include "Functions.hpp"

int main()
{
	// b) Transform vector of integers into a set of integers using function objects, predefined STL function objects, and lambda functions:
	int thresholdValue = 2;
	std::vector<int> testVec{ 1, 2, 1, 4, 5, 5, -1 };
	std::cout << "testVec: " << testVec << std::endl;
	// Test using lambda:
	auto transformVec = [&thresholdValue, &testVec]() { auto iter = testVec.begin(); while (iter != testVec.end()){if (*iter <= thresholdValue) iter = testVec.erase(iter); else iter++;}};
	transformVec();
	std::cout << "testVec following lambda threshold application: " << testVec << std::endl;
	// Test using user defined function objects:
	testVec = { 1, 2, 1, 4, 5, 5, -1 };
	VecTransform transform;
	transform.thresholdValue = 2;
	transform(testVec);
	std::cout << "testVec following function object threshold application: " << testVec << std::endl;
	// Test using STL function objects:
	testVec = { 1, 2, 1, 4, 5, 5, -1 };
	std::remove_if(testVec.begin(), testVec.end(), [&thresholdValue](auto i) { return i <= thresholdValue; });
	
	std::cout << "testVec following std:: threshold application: " << testVec << std::endl;
	
	system("pause");

	return 0;
}