/* Main.cpp (exercise 4.1.2)
Description:
	* Solutions to problems a-e for exercise 4.1.2.
*/

#define _SCL_SECURE_NO_WARNINGS
#include <functional>
#include <iostream>
#include "Vector.hpp"

int main()
{
	// b) Create instance of Vector<> and print:
	Vector<int, 5> fiveVec(5);

	std::cout << "fiveVec: " << fiveVec << std::endl;
	
	// d) Implement scalar multiplication:
	std::cout << "5 * fiveVec = " << 5 * fiveVec << std::endl;
	
	// e) Test modify() method:
	std::function<int(int)> f([](int i) ->int { if (i > 4) return i * 4; });
	fiveVec.modify(f);
	std::cout << "fiveVec: " << fiveVec << std::endl;

	system("pause");
	return 0;
}