/* Main.cpp (exercise 4.3.6)
Description:
	* Solutions to problems a, b in exercise 4.3.6.
*/

#include <iostream>
#include <boost\random\lagged_fibonacci.hpp>
#include <boost\random\triangle_distribution.hpp>
#include <vector>

int main()
{
	// a) Create a variate of the triangle distribution with lagged Fibonacci as the engine:
	boost::triangle_distribution<> tDist;
	boost::lagged_fibonacci1279 lFib;

	// Generate a large number of outputs:
	std::vector<int> outputs;
	for (std::size_t i = 0; i < 24; i++)
	{
		outputs.push_back(tDist(lFib));
	}
	// Display output:
	std::cout << "Triangle Distribution Outputs: " << std::endl;
	std::cout << "{ ";
	for (std::size_t i = 0; i < outputs.size(); i += 3)
	{
		std::cout << outputs[i] << ", " << outputs[i + 1] << ", " << outputs[i + 2] << ((i < outputs.size() - 3) ? "\n" : "}\n");
	}

	system("pause");

	return 0;
}