/* Functions.hpp (exercise 4.3.6)
Description:
	* Solution to problem b.
*/

#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP

#include <bitset>

template<typename RealType, std::size_t bits, typename URNG>
RealType generate_canonical(URNG &g)
{

}


#endif
