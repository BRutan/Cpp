/* Functions.hpp (exercise 4.3.7)
Description:
	* Provides solutions to problems a-c for exercise 4.3.7.
*/

#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP

template<typename iterType, typename ExpectationType>
double ChiSquareStat(const iterType &begin, const iterType &end, const ExpectationType &expectedValue)
{
	auto iter = begin;
	ExpectationType accumulation = 0;
	while (iter != end)
	{
		accumulation += ((*iter - expectedValue) * (*iter - expectedValue)) / expectedValue;
		iter++;
	}
	return accumulation;
}

#endif