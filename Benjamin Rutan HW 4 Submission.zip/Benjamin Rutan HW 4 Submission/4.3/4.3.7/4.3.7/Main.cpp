/* Main.cpp (exercise 4.3.7)
Description:
	* Solution to exercise 4.3.7.
*/

#include <iostream>
#include <random>
#include "Functions.hpp"


int main()
{
	// c) Choose integer k and create unifom integers in range (0;k). Generate N draws and count number of occurrences of each integer j (0 <= j <= k):
	constexpr std::size_t k = 100, j = 10;
	std::size_t currResult, jCount = 0;
	std::uniform_int_distribution<> dist(0, k);
	std::random_device rand_eng;
	std::size_t N = 100;
	double chiSq;
	int results[k];
	for (std::size_t i = 0; i < N; i++)
	{
		results[i] = 0;
	}
	for (std::size_t i = 0; i < N; i++)
	{
		currResult = dist(rand_eng);
		results[currResult]++;
	}

	// Compute chi squared statistic:
	chiSq = ChiSquareStat(&results[0], &results[k - 1], (double) k);

	// Print the chi square statistic:
	std::cout << "Chi square statistic (with k = " << k << " and N = " << N << "): " << chiSq << std::endl;

	system("pause");

	return 0;
}