/* Main.cpp (exercise 4.3.5)
Description:
	* Solutions to problems a-c for exercise 4.3.5.
*/

#include <chrono>
#include <random>

int main()
{
	// a) Create instance of independent_bits_engine:
	std::independent_bits_engine<std::bernoulli_distribution, 20, std::size_t> ibe(40.0);
	// 

	system("pause");

	return 0;
}