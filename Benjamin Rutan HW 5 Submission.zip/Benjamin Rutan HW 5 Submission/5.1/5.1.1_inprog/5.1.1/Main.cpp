/* Main.cpp (exercise 5.1.1)
Description:
	* Solutions to problems a-d.
*/

#include <algorithm>
#include <boost\algorithm\string\find.hpp>
#include <boost\algorithm\string\trim.hpp>
#include <functional>
#include <iostream>

int main()
{
	// a) Test trim leading and trailing blanks function:
	std::string test(" abc123 ");
	const std::string testConst(" abc123 ");
	std::cout << "test: |" << test << "|" << std::endl;
	boost::trim(test);
	std::cout << "Trim(test) reference version: |" << test << "|" << std::endl;
	test = " abc123 ";
	// boost::trim(testConst);
	std::cout << "Trim(test) copy version: |" << testConst << "|" <<  std::endl;

	// b) Test Trim with predicates:
	std::string test2("AAA abc123 AAA");
	std::cout << "test2: |" << test2 << "|" << std::endl;
	boost::trim_if(test2, [](const auto &in) { return (in == 'A' || in == ' '); });
	std::cout << "trim_if(test2): |" << test2 << "|" << std::endl;
	// c) Test if a string starts or ends with a given string:
	std::string test3("abc123");
	std::string tester("abc");
	auto iter = boost::find(test3, tester);
	std::cout << tester << " is" << ((iter != test3.begin())? " not": " ") << "at start of string " << test3 << std::endl;
	
	// d) Test if a string contains another string:
	tester = "123";
	//auto iter2 = boost::find(test3, tester);
	//std::cout << tester << " is" << ((iter2 != test3.end()) ? " not" : " ") << " in string " << test3 << std::endl;

	system("pause");

	return 0;
}