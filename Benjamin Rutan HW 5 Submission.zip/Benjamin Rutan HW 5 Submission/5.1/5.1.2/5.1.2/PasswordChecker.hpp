/* PasswordChecker.hpp
Description:
	*



*/



#ifndef PASSWORDCHECKER_HPP
#define PASSWORDCHECKER_HPP

#include <boost\any.hpp>
#include <string>

std::string PasswordChecker(const std::string &str_in, bool &resultType)
{
	std::string outputMessage;
	// Determine if has at least 8 characters:
	// Return false if has any spaces:
	if (boost::any())


}




#endif
