/* Main.cpp (exercise 5.1.2)
Description:
	* 


*/

#include <boost\algorithm\string\trim.hpp>
#include <boost\algorithm\algorithm.hpp>
#include <algorithm>
#include <iostream>
#include <string>

int main()
{
	// a) Define predicates to test the following:
	std::string str2(" abd1 234\*");
	// Recognize digits:
	auto digitsOrLetters = [](auto i) { return std::isdigit(i) || std::isalpha(i); };
	auto digitsNotLetters = [](auto i) { return std::isdigit(i); };
	auto charsInRange = [](auto i) { return i >= 'a' - 0 && i <= 'z' - 0; };


	system("pause");

	return 0;
}