/* Main.cpp (exercise 5.1.3)
Description:
	* Solution to problems a-c.
*/

#define _SCL_SECURE_NO_WARNINGS

#include <boost\date_time\gregorian\gregorian.hpp>
#include <boost\algorithm\string\classification.hpp>
#include <boost\algorithm\string\split.hpp>
#include <iostream>
#include <string>
#include <vector>
#include "Functions.hpp"

int main()
{
	std::string sA("1,2,3,4/5/9*56");
	std::vector<std::string> results;
	// a) Split string into vector of strings, then join to form new string:
	std::cout << "Target string: " << sA << std::endl;
	boost::split(results, sA, boost::is_any_of(",|/|*"));
	std::string combined;
	for (std::vector<std::string>::iterator iter = results.begin(); iter != results.end(); iter++)
	{
		combined += *iter + (((iter + 1) != results.end())?"/":"");
	}

	std::cout << "Combined string: " << combined << std::endl;

	// b) Test function that converts strings to Boost date:
	std::string dateString("2015-12-31");
	boost::gregorian::date output = ConvertToDate(dateString);
	std::cout << "Date (string): " << dateString << std::endl;
	std::cout << "Date (boost::gregorian::date): " << output << std::endl;

	 // c) Test function that converts string to instance of map<string, double>:
	std::vector<std::string> names;
	std::map<std::string, double> nameValue;
	names.push_back("port = 23");
	names.push_back("pin = 87");
	names.push_back("value = 34.4");

	names.begin()->find("=", std::string::npos);
	ConvertToNameValueMap(names.begin(), names.end(), nameValue);

	system("pause");

	return 0;
}