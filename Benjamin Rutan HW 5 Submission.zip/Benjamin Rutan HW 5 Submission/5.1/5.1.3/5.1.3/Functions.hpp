/* Functions.hpp (exercise 5.1.3)
Description:
	* Solutions to b, c.
*/

#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP

#include <boost\algorithm\string\classification.hpp>
#include <boost\algorithm\string\split.hpp>
#include <boost\lexical_cast.hpp>
#include <boost\date_time\gregorian\gregorian.hpp>
#include <map>
#include <string>
#include <vector>

// b) Write function that converts strings to boost::gregorian::date:
boost::gregorian::date ConvertToDate(const std::string &date_in)
{
	if (date_in.find("-") != std::string::npos)
	{
		std::vector<std::string> contents;
		
		boost::split(contents, date_in, boost::is_any_of("-"));
		if (contents.size() != 3)
		{
			// Incorrect number of outputs, return default gregorian date:
			return boost::gregorian::date();
		}
		else
		{
			// Correct number of outputs (month, day, year):
			try
			{
				// year-month-day:
				return boost::gregorian::from_string(date_in);
			}
			catch (boost::bad_lexical_cast&)
			{
				// Return default gregorian date:
				return boost::gregorian::date();
			}
		}
	}
	else
	{
		// No "-" in string, return default date:
		return boost::gregorian::date();
	}
}

// c) Write function that converts strings to map<string, double>:

template<typename ContainerIterType>
void ConvertToNameValueMap(ContainerIterType &names_begin, ContainerIterType &names_end, std::map<std::string, double> &output)
{
	std::vector<std::string> temp;
	while (names_begin != names_end)
	{
		if (names_begin->find("=") != std::string::npos)
		{
			temp.clear();
			boost::split(temp, *names_begin, " = ");
			if (temp.size() == 2)
			{
				output.emplace(std::make_pair<std::string, double>(std::move(temp[0]), std::stod(temp[1])));
			}
		}
		names_begin++;
	}
}


#endif