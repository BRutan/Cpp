/* Main.cpp (exercise 5.1.4)
Description:
	* Solution to exercise.
*/

#define _SCL_SECURE_NO_WARNINGS

#include <boost\date_time\gregorian\gregorian.hpp>
#include <boost\algorithm\string\classification.hpp>
#include <boost\algorithm\string\split.hpp>
#include <boost\algorithm\string\trim.hpp>
#include <iostream>
#include <fstream>
#include <list>
#include <string>
#include <tuple>
#include <vector>

using Data = std::tuple<boost::gregorian::date, std::vector<double>>;
using ResultSet = std::list<Data>;

int main()
{
	std::ifstream inputFile;
	std::string currLine;
	
	// Open input file:
	try
	{
		inputFile.open("Input.txt");
	}
	catch (...)
	{
		std::cout << "Could not open input file (Input.txt)." << std::endl;
		system("pause");
		return 1;
	}
	std::string topLine;
	std::vector<std::string> splitLine;
	std::vector<double> lineData;
	ResultSet result;
	Data currElement;

	// Parse file:
	std::size_t lineCount = 0;
	std::string temp;
	while (!inputFile.eof())
	{
		std::getline(inputFile, currLine);
		lineCount++;
		if (lineCount != 1)
		{
			boost::trim(currLine);
			if (currLine.length())
			{
				splitLine.clear();
				boost::split(splitLine, currLine, boost::is_any_of(","));
				if (!splitLine.size())
				{
					lineData.clear();
					for (std::vector<std::string>::iterator iter = splitLine.begin(); iter != splitLine.end(); iter++)
					{
						if (iter->find("-") != std::string::npos)
						{
							// Date has been found, extract and set:
							temp = *iter;
							boost::trim_if(temp, [](char i) { return (i == '-' || i == ' '); });
							std::get<0>(currElement) = boost::gregorian::from_string(temp);
						}
						else
						{
							// Data has been found, append to the data list:
							temp = *iter;
							boost::trim(temp);
							lineData.push_back(std::stod(temp));
						}
					}
				}
				std::get<1>(currElement) = lineData;
				result.push_back(currElement);
			}
		}
		else
		{
			topLine = currLine;
		}
	}
	
	inputFile.close();

	// Print all contents:
	std::size_t count;
	std::cout << topLine << std::endl;
	for (auto elem : result)
	{
		std::cout << std::get<0>(elem) << ": ";
		count = 0;
		for (auto data_elem : std::get<1>(elem))
		{
			count++;
			std::cout << data_elem << ((count < std::get<1>(elem).size()) ? ", " : "");
		}
		std::cout << std::endl;
	}

	system("pause");

	return 0;
}