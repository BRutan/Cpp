/* Main.cpp (exercise 5.8.1)
Description:
	*


*/

#include <algorithm>
#include <iostream>
#include <string>
#include <vector>

int main()
{
	// a) Create vector:
	std::vector<int> vec2{ 3,4,5,6,7,5,6,7,8,9,1,2,3,4 };
	std::vector<int> vec3{ 5,5,5,5,5,5,5 };
	std::cout << "vec2 = { ";
	std::size_t count = 0;
	for (auto i : vec2)
	{
		count++;
		std::cout << i << ((count < vec2.size()) ? ", " : " }\n");
	}

	// b) Call make_heap() and print result:
	std::make_heap(vec2.begin(), vec2.end());
	std::cout << "vec2 (heap) = { ";
	count = 0;
	for (auto i : vec2)
	{
		count++;
		std::cout << i << ((count < vec2.size()) ? ", " : " }\n");
	}
	
	// c) Pop root of heap by calling pop_heap(): 
	std::pop_heap(vec2.begin(), vec2.end()); // Puts root of heap at end of vector.
	vec2.pop_back(); // Needs to be called since pop_heap() only puts the root of heap to end, without removing.
	count = 0;
	std::cout << "vec2 (after pop_heap): { ";
	for (auto i : vec2)
	{
		count++;
		std::cout << i << ((count < vec2.size()) ? ", " : " }\n");
	}

	// Test pop_heap() on vector without heap property:
	count = 0;
	std::cout << "vec3 (non-heap): { ";
	for (auto i : vec3)
	{
		count++;
		std::cout << i << ((count < vec3.size()) ? ", " : " }\n");
	}

	std::pop_heap(vec3.begin(), vec3.end()); // Does nothing since vec3 is not a heap:
	count = 0;
	std::cout << "vec3 (non-heap after pop_heap): { ";
	for (auto i : vec3)
	{
		count++;
		std::cout << i << ((count < vec3.size()) ? ", " : " }\n");
	}


	system("pause");

	return 0;
}