/* Main.cpp (exercise 5.8.2)
Description:
	* Solutions to problems a-c.
*/

#include <iostream>
#include <queue>

int main()
{
	std::priority_queue<int> pq;
	pq.emplace(10);
	pq.emplace(5);
	pq.emplace(20);
	pq.emplace(30);
	pq.emplace(25);
	pq.emplace(7);
	pq.emplace(40);

	// a) Print the queue:
	
	std::cout << "priority queue: { ";
	std::size_t count = 0;
	std::get<0>(pq)

	system("pause");

	return 0;
}