/* Functions.hpp (exercise 5.9.3)
Description:
	* Define combiner for signals2 objects.
*/

#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP

struct BootstrapCheck
{
	typedef bool result_type;
	template <typename InputIterator> bool operator()(InputIterator first, InputIterator last) const
	{
		while (first != last)
		{
			if (!*first)
			{
				return false;
			}
			++first;
		}
		return true;
	}
};

#endif