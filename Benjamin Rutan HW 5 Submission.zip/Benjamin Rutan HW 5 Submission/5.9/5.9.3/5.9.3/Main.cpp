/* Main.cpp (exercise 5.9.3)
Description:
	* Solutions to problems a-c.
*/

#define _SCL_SECURE_NO_WARNINGS
#include <boost\signals2.hpp>
#include <iostream>

#include "Functions.hpp"

int main()
{
	// a) Instantiate signal that uses combiner:
	boost::signals2::signal<bool(), BootstrapCheck> sig;

	// b) Connect three slots with necessary signature:
	auto trueFunc = []() { return true; };
	auto falseFunc = []() { return false; };
	sig.connect(trueFunc);
	sig.connect(falseFunc);
	sig.connect(trueFunc);

	// c)
	bool value = sig();

	std::cout << "sig(): " << value << std::endl; // Since one function returns false, signal returns false.

	system("pause");

	return 0;
}