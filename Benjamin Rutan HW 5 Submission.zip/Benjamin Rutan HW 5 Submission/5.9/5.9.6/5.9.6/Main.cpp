/* Main.cpp (exercise 5.9.6)
Description:
	* Solutions to problems a-c.
*/

#define _SCL_SECURE_NO_WARNINGS

#include <boost\signals2.hpp>
#include <iostream>

int main()
{
	// a) Create Exterior, Hardware, Data and Communication layer signals:
	boost::signals2::signal<void(double &d)> exterior;
	boost::signals2::signal<void(double &d)> hardware;
	boost::signals2::signal<void(double &d)> data;
	boost::signals2::signal<void(double &d)> communication;

	// Create slots:
	auto multiplyByFive = [](double &d) { d *= 5; };
	auto addFive = [](double &d) { d += 5; };
	auto print = [](double &d) { std::cout << d << std::endl; };

	// b) Connect signals to each other and emit:

	
	hardware.connect(multiplyByFive);
	hardware.connect(data);
	data.connect(addFive);
	data.connect(communication);
	communication.connect(print);

	exterior.connect(hardware);

	double value = -3.7;
	exterior(value);

	system("pause");

	return 0;
}