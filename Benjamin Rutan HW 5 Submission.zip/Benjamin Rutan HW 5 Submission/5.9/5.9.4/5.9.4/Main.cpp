/* Main.cpp (exercise 5.9.4)
Description:
	* Solutions to problems a-c.
*/


#include <boost\signals2.hpp>
#include <iostream>

int main()
{
	// a) Create binary slot functions:
	auto multiplyNums = [](double i, double j) { return i * j; };
	auto addNums = [](double i, double j) { return i + j; };

	// b) Create template combiner that sums values returned by slots:


	system("pause");

	return 0;
}