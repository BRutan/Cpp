/* Functions.hpp (exercise 5.9.1)
Description:
	* Solutions to problems a-d. 
*/

#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP

#include <iostream>

void freeFunc()
{
	std::cout << "Free function." << std::endl;
}

struct fObj
{
	void operator()()
	{
		std::cout << "Function object." << std::endl;
	}
};

struct MyStruct
{
	double val;
	MyStruct(double v) : val(v) {}
	void modify(double newValue)
	{
		val = newValue;
		std::cout << "A third slot: " << val << std::endl;
	}
};


#endif
