/* Subject.hpp (exercise 5.9.5)
Description:
	* Solutions to problems a-c.
*/

#ifndef SUBJECT_HPP
#define SUBJECT_HPP

#include <boost\signals2.hpp>
#include <boost\function.hpp>
#include <list>

typedef boost::function<void(double)> FunctionType;

// a) Recode to support signal2s:

// Using boost Function library typedef boost::function<void (double)> FunctionType;
class Subject 
{ 
	// The notifier (Observable)in Publisher-Subscriber pattern private:
	// std::list<FunctionType> attentionList;
	boost::signals2::signal<void(double)> signal_member;
public: 
	Subject() : signal_member()
	{ 
		
	}	
	void AddObserver(const FunctionType& ft) 
	{ 
		signal_member.connect(ft);
	}
	void ChangeEvent(double x) 
	{
		/* 
		for (auto it = attentionList.begin(); it != attentionList.end(); ++it) 
		{
			(*it)(x);
		} */
	}
};

#endif
