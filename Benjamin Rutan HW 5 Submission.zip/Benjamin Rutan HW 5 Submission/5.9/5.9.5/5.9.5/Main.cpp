/* Main.cpp (exercise 5.9.5)
Description:
	* Solutions to problems a-c.
*/

#include <iostream>

int main()
{
	// a) 


	system("pause");

	return 0;
}