/* Main.cpp (exercise 5.9.2)
Description:
	* Solutions to problems a, b.
*/

#define _SCL_SECURE_NO_WARNINGS
#include <boost\signals2.hpp>
#include <functional>
#include <iostream>
#include "Functions.hpp"

int main()
{
	// a) Create signal and slots using lambdas, free functions and function objects:
	boost::signals2::signal<void()> signal1;
	// Lambda version:
	signal1.connect(1, std::bind([]() {std::cout << "Lambda." << std::endl; }));
	// Free function version:
	signal1.connect(2, freeFunc);
	// Function object version:
	signal1.connect(3, fObj());
	signal1();			// All slots are emitted.

	// c) Experiment with disconnecting slots:
	signal1.disconnect_all_slots();

	// d) Create multiple signals and slots:
	boost::signals2::signal<void()> signalA;
	boost::signals2::signal<void()> signalB;
	boost::signals2::signal<void()> signalC;
	boost::signals2::signal<void()> signalD;

	// Define slots:
	auto slotB = []() {std::cout << "Slot B called by B\n " << std::endl; };
	auto slotC = []() {std::cout << "Slot C called by C\n " << std::endl; };
	auto slotD1 = []() {std::cout << "Slot D1 called by D\n " << std::endl; };
	auto slotD2 = []() {std::cout << "Slot D2 called by D\n " << std::endl; };
	
	signalB.connect(slotB);
	signalC.connect(slotC);
	signalD.connect(slotD1);
	signalD.connect(slotD2);

	// Make various connections between signal objects:
	signalA.connect(signalB);
	signalB.connect(signalC);
	signalC.connect(signalD);

	// Emit signal:
	signalA();


	system("pause");

	return 0;
}