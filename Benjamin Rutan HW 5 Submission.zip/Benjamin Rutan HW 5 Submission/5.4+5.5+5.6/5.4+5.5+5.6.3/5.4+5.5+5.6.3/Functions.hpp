/* Functions.hpp (exercise 5.4+5.5+5.6.3)
Description:
	* Hash functions to test in part b.
*/



#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP

#include "Point.hpp"
#include "Shape.hpp"

std::size_t a = 523;
std::size_t b = 409;

void hash(std::size_t &seed, const BenRutan::CAD::Point &point_in)
{
	// Work with X():
	seed = seed * a + point_in.X();
	seed = seed * b + point_in.Y();
}


#endif
