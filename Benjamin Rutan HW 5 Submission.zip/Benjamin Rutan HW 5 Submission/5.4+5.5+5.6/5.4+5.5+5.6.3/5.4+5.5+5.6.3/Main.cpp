/* Main.cpp (5.4+5.5+5.6.3)
Description:
	*


*/

#include <boost\unordered\unordered_set.hpp>
#include <boost\container\set.hpp>
#include <iostream>

#include "Point.hpp"
#include "Shape.hpp"
#include "StopWatch.hpp"

int main()
{
	// a) Create unordered multiset of Points using default_hash:
	boost::unordered_multiset<BenRutan::CAD::Point> mSet;
	StopWatch watch;
	double time = 0;
	// Start clock:
	watch.StartStopWatch();

	// Add elements to multiset:
	for (std::size_t i = 0; i < 100000; i++)
	{
		if (i % 2)
		{
			mSet.insert(BenRutan::CAD::Point(i, i + 1));
		}
		else
		{
			mSet.emplace(BenRutan::CAD::Point(i, i + 1));
		}
	}

	// Remove elements from multiset:
	/*
	for (std::size_t i = 0; i < 1000000; i++)
	{
		if (i % 2)
		{
			mSet.erase(i);
		}
		else
		{
			mSet.clear();
		}
	}*/

	// End clock:
	watch.StopStopWatch();

	// Measure the total time taken:
	time = watch.GetTime();

	std::cout << "Time taken: " << time << std::endl;

	// b) Do above using custom hash function and 
	boost::container::multiset<BenRutan::CAD::Point> mSet2;

	watch.StartStopWatch();

	for (std::size_t i = 0; i < 100000; i++)
	{
		if (i % 2)
		{
			mSet2.insert(BenRutan::CAD::Point(i, i + 1));  
		}
		else
		{
			mSet.emplace(BenRutan::CAD::Point(i, i + 1));
		}
	}



	watch.StopStopWatch();

	time = watch.GetTime();

	std::cout << "Time taken: " << time << std::endl;


	system("pause");

	return 0;
}