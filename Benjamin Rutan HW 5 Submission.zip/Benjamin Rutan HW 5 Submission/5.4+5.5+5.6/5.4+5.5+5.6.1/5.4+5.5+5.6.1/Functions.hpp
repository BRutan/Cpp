/* Functions.hpp (exercise 5.4+5.5+5.6.1)
Description:
	* Solutions to exercise.
*/

#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP

#include <string>

// a) Create two generic functions to hash arbitrary data types:

// For numeric types:
template<typename T>
std::size_t hash(T input)
{
	return input / 13 * 17;
}

// For iterable types that are convertible to std::size_t:
template<typename IterType>
std::size_t hash(IterType begin, IterType end)
{
	std::size_t a = 13;
	std::size_t b = 17;
	std::size_t hash_output = 0;

	while (begin != end)
	{
		hash_output = hash_output * b + *begin / a;
		begin++;
	}

	return hash_output;
}

#endif