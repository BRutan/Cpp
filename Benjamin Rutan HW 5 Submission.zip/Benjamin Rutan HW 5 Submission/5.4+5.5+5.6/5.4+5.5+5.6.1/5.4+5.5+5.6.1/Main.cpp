/* Main.cpp (exercise 5.4+5.5+5.6.1)
Description:
	* Solutions to problems a-c.
*/


#include <iostream>
#include <string>

#include "Functions.hpp"

int main()
{
	// b) Test hash functions using integers, strings, pointers, and numeric_limits<long>::max(); 

	std::string testString("abc");
	std::cout << "String: " << testString << ", Hash: " << hash<std::string::iterator>(testString.begin(), testString.end()) << std::endl;

	unsigned i = 25;
	std::cout << "Integer: " << i << ", Hash: " << hash(i) << std::endl;
	
	long max = std::numeric_limits<long>::max();
	std::cout << "Long: " << max << ", Hash: " << hash(max) << std::endl;
	
	// c) 

	std::size_t h1 = hash(4000);
	std::size_t h2 = hash(12000);

	std::cout << "h1: " << h1 << std::endl;
	std::cout << "h2: " << h2 << std::endl;
	std::cout << "h1 ^ (h2 << 1): " << (h1 ^ (h2 << 1)) << std::endl;


	system("pause");

	return 0;
}