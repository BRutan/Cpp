/* Main.cpp (exercise 5.4+5.5+5.6.2)
Description:
	* Solutions to problems a-c.
*/

#include <boost\unordered\unordered_map.hpp>
#include <iostream>
#include <list>
#include <tuple>

#include "Point.hpp"
#include "Shape.hpp"

using LineSegment = std::pair<BenRutan::CAD::Point, BenRutan::CAD::Point>;

int main()
{
	// a) Create hashes for Point and LineSegment using boost::hash_combine:

	BenRutan::CAD::Point p1(4.0, 5.0);
	BenRutan::CAD::Point p2(6.0, 7.0);
	LineSegment l1(p1, p2);

	std::size_t hash_1 = 0;
	
	boost::hash_combine(hash_1, p1.X());
	boost::hash_combine(hash_1, p1.Y());
	std::cout << "Point: " << p1 << ", Hash: " << hash_1 << std::endl;
	
	std::size_t hash_2 = 0;
	boost::hash_combine(hash_2, std::get<0>(l1).X());
	boost::hash_combine(hash_2, std::get<0>(l1).Y());
	boost::hash_combine(hash_2, std::get<1>(l1).X());
	boost::hash_combine(hash_2, std::get<1>(l1).Y());
	std::cout << "LineSegment: ( " << std::get<0>(l1) << "), ( " << std::get<1>(l1) << " ) " << std::endl;
	std::cout << "Hash: " << hash_2 << std::endl;
	
	// b) Create list of Point instances and compute hash:
	std::list<BenRutan::CAD::Point> points;
	for (std::size_t i = 0; i < 10; i++)
	{
		points.push_back(BenRutan::CAD::Point(i, i + 1));
	}
	
	// Compute hash using boost::hash_range():
	std::size_t hash_3 = 0;
	// boost::hash_range<std::list<BenRutan::CAD::Point>::iterator>(hash_3, points.begin(), points.end());
	std::cout << "Point List Hash: " << hash_3 << std::endl;
	
	system("pause");

	return 0;
}