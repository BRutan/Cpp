/* PointHash.hpp (exercise 5.4+5.5+5.6.2)
Description:
	* Solution to problem c.
*/


#ifndef POINTHASH_HPP
#define POINTHASH_HPP

#include <boost\unordered\unordered_map.hpp>
#include <functional>
#include "Point.hpp"
#include "Shape.hpp"


struct PointHash : std::unary_function<BenRutan::CAD::Point, std::size_t>
{
	std::size_t operator() (const BenRutan::CAD::Point &pt) const
	{

		// TBD by student:

		std::size_t seed = 0;
		boost::hash_combine(seed, pt.X());
		boost::hash_combine(seed, pt.Y());

		return seed;
	}

}

#endif

