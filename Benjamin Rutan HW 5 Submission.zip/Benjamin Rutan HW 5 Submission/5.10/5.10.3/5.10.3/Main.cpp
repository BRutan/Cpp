/* Main.cpp (exercise 5.10.3)
Description:
	* Solutions to problems a-c.
*/

#define _SCL_SECURE_NO_WARNINGS
#include <boost\numeric\ublas\matrix_sparse.hpp>
#include <boost\numeric\ublas\triangular.hpp>
#include <complex>
#include <iostream>

int main()
{
	// a) Create a complex sparse matrix:
	boost::numeric::ublas::compressed_matrix<std::complex<double>> complexSparse;
	complexSparse.insert_element(0, 0, std::complex<double>(4.0));
	std::complex<double> temp = complexSparse(0, 0);
	std::cout << "complexSparse(0, 0): " << temp << std::endl;

	// b) Create number of lower and upper triangular matrices with row and column major storage organization:
	boost::numeric::ublas::triangular_matrix<double, boost::numeric::ublas::lower> rowMajorLower;
	boost::numeric::ublas::triangular_matrix<double, boost::numeric::ublas::upper, boost::numeric::ublas::column_major> columnMajorUpper;


	system("pause");

	return 0;
}