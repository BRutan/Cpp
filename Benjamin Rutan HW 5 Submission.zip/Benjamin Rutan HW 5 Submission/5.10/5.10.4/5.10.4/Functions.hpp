/* Functions.hpp (exercise 5.10.4)
Description:
	*


*/


#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP



#endif
