/* Main.cpp (exercise 5.10.4)
Description:
	* Solutions to problems a-c.
*/

#include <iostream>
#include <vector>
#include <tuple>

int main()
{
	// a) Implement std::find_if:

	system("pause");

	return 0;
}