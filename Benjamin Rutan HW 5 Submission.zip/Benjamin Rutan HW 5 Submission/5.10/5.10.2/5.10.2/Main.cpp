/* Main.cpp (exercise 5.10.2)
Description:
	*



*/

#include <boost\numeric\ublas\matrix.hpp>
#include <iostream>

int main()
{
	// a) Create matrices with row and column variations:
	boost::numeric::ublas::matrix<double, boost::numeric::ublas::row_major> matr1;


	system("pause");

	return 0;
}