/* Main.cpp (exercise 5.7.2)
Description:
	* Solution to problems a-c. 
*/


#include <boost\bimap.hpp>
#include <boost\unordered\unordered_map.hpp>
#include <boost\uuid\string_generator.hpp>
#include <boost\uuid\uuid.hpp>
#include <iostream>
#include <string>

using BNS = boost::bimap<boost::unordered_map<std::string, >, boost::unordered_map<std::string>>;

int main()
{



	system("pause");

	return 0;
}