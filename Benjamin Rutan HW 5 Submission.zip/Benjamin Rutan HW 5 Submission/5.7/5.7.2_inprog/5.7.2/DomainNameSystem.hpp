/* DomainNameSystem.hpp (exercise 5.7.2)
Description:
	* 


*/


#ifndef DOMAINNAMESYSTEM_HPP
#define DOMAINNAMESYSTEM_HPP




#endif

