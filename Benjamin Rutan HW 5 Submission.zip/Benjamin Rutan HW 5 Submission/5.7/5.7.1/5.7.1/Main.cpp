/* Main.cpp (exercise 5.7.1)
Description:
	* Solutions to problems a-d.
*/

#include <boost\bimap.hpp>
#include <iostream>

typedef boost::bimap<std::string, std::size_t> personsType;
int main()
{
	personsType persons; // { name : age }
	
	// a) Populate bimap with names - age pairs:
	persons.insert(personsType::value_type("Ben", 27));
	persons.insert(personsType::value_type("Emily", 29));
	persons.insert(personsType::value_type("Sam", 24));

	// b) Print left and right maps of the bimap:
	std::cout << "Left map: " << std::endl;
	for (personsType::left_const_iterator i = persons.left.begin(); i != persons.left.end(); i++)
	{
		std::cout << i->first << ", " << i->second << std::endl;
	}
	std::cout << "Right map: " << std::endl;
	for (personsType::right_const_iterator i = persons.right.begin(); i != persons.right.end(); i++)
	{
		std::cout << i->first << ", " << i->second << std::endl;
	}
	
	// c) Search for age based on name, and name based on age:
	std::cout << "Ben's age: " << persons.left.find("Ben")->second << std::endl;
	std::cout << persons.left.find("Ben")->second << "'s person: " << persons.right.find(27)->second << std::endl;
	
	system("pause");

	return 0;
}