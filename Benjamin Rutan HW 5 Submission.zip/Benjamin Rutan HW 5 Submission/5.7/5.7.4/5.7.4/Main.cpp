/* Main.cpp (exercise 5.7.4)
Description:
	* Solutions to problems a-c.
*/

#include <boost\bimap.hpp>
#include <boost\container\list.hpp>
#include <boost\container\set.hpp>
#include <boost\unordered\unordered_set.hpp>
#include <iostream>
#include <string>


int main()
{
	// a) Create bimaps where domain is set, multiset and unordered set, and range is list, set and unordered set:
	boost::bimap<boost::container::set<std::string>, boost::container::list<std::string>> bm1;
	boost::bimap<boost::container::multiset<std::string>, boost::container::set<std::string>> bm2;
	boost::bimap<boost::unordered_set<std::string>, boost::unordered_set<std::string>> bm3;

	// b) Create instances of bimaps in part a and print values:



	// c) Modify code in part b to support different types of comparators (for ex: std::greater<>):




	return 0;
}