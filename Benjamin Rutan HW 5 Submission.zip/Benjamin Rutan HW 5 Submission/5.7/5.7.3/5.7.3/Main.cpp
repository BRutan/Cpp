/* Main.cpp (exercise 5.7.3)
Description:
	* Solutions to problems a-c.
*/

#include <boost\unordered_set.hpp>
#include <boost\bimap.hpp>
#include <iostream>
#include <string>


int main()
{
	// a) Create 1:N association between book title and author:
	boost::bimap<std::string, boost::unordered_set<std::string>> authorTitles;

	// b) Print price of book from given author:

	// c) Create association attribute containing tuple consisting of book abstract and price:


	return 0;
}