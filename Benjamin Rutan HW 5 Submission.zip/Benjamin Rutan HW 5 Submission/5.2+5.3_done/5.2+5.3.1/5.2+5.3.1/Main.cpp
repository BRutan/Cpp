/* Main.cpp (exercise 5.2+5.3.1)
Description:
	* Solutions to problems a-e for exercise 5.2+5.3.1.
*/

#include <iostream>
#include <regex>
#include <string>

int main()
{
	// a) 
	std::regex myReg("[a-z]*");
	std::regex myReg2("[a-z]+");

	std::string s1("aza"); // myReg + myReg2 return true since both zero or more and one or more letter is satisfied.
	std::cout << "regex_match(\"" << s1 << "\", \"[a-z]*\"):" << std::regex_match(s1, myReg) << std::endl; 
	std::cout << "regex_match(\"" << s1 << "\", \"[a-z]+\"):" << std::regex_match(s1, myReg2) << std::endl;
	std::string s2("1"); // myReg + myReg2 return false because no letters present.
	std::cout << "regex_match(\"" << s2 << "\", \"[a-z]*\"):" << std::regex_match(s2, myReg) << std::endl;
	std::cout << "regex_match(\"" << s2 << "\", \"[a-z]+\"):" << std::regex_match(s2, myReg2) << std::endl;
	std::string s3("b"); // myReg + myReg2 return true because at least one letter.
	std::cout << "regex_match(\"" << s3 << "\", \"[a-z]*\"):" << std::regex_match(s3, myReg) << std::endl;
	std::cout << "regex_match(\"" << s3 << "\", \"[a-z]+\"):" << std::regex_match(s3, myReg2) << std::endl;
	std::string s4("ZZ TOP"); // myReg + myReg2 return false because letters are capitalized.
	std::cout << "regex_match(\"" << s4 << "\", \"[a-z]*\"):" << std::regex_match(s4, myReg) << std::endl;
	std::cout << "regex_match(\"" << s4 << "\", \"[a-z]+\"):" << std::regex_match(s4, myReg2) << std::endl;

	// b)
	std::regex myNumericReg("\\d{2}");
	std::string f("34"); // match since exactly two digits.
	std::cout << "regex_match(\"" << f << "\", \"\\d{2}\"):" << std::regex_match(f, myNumericReg) << std::endl;

	std::string s("345"); // no match since more than two digits.
	std::cout << "regex_match(\"" << s << "\", \"\\d{2}\"):" << std::regex_match(s, myNumericReg) << std::endl;

	// c)
	std::regex myAltReg("(new)|(delete)");
	std::string s4A("new"); // match since one of the options matches (new).
	std::cout << "regex_match(\"" << s4A << "\", \"(new)|(delete)\"):" << std::regex_match(s4A, myAltReg) << std::endl;
	std::string s5("delete"); // match since one of the options matches (delete).
	std::cout << "regex_match(\"" << s5 << "\", \"(new)|(delete)\"):" << std::regex_match(s5, myAltReg) << std::endl;
	std::string s6("malloc"); // no match since not (new) or (delete).
	std::cout << "regex_match(\"" << s6 << "\", \"(new)|(delete)\"):" << std::regex_match(s6, myAltReg) << std::endl;

	// d) 
	std::regex myReg3("A*");
	std::regex myReg4("A+");
	std::regex myReg5("(\\d{2})");
	// std::regex myReg6("\\d{2, 4}"); Runtime error is thrown.
	std::regex myReg7("\\d{1,}");

	std::string testA("1");
	std::cout << "regex_match(\"" << testA << "\", \"A*\"):" << std::regex_match(testA, myReg3) << std::endl; // No match since no letters.
	std::cout << "regex_match(\"" << testA << "\", \"A+\"):" << std::regex_match(testA, myReg4) << std::endl; // No match since no letters.
	std::cout << "regex_match(\"" << testA << "\", \"(\\d{2})\"):" << std::regex_match(testA, myReg5) << std::endl; // No match since only one digit.
	std::cout << "regex_match(\"" << testA << "\", \"(\\d{1,})\"):" << std::regex_match(testA, myReg7) << std::endl; // Match since one digit (one or more digits match).

	// e) 
	std::cout << std::endl;
	std::regex rC("(\\w)*"); 
	std::regex rC1("(\\W)*");
	std::regex rC2("[A-Za-z0-9_]*");

	std::string sC1("abc");
	std::string sC2("A12678Z909za");

	std::cout << "regex_match(\"" << sC1 << "\", \"(\\w)\"): " << std::regex_match(sC1, rC) << std::endl; // Match since all lowercase (matches if character is a lowercase letter).
	std::cout << "regex_match(\"" << sC1 << "\", \"(\\W)\"): " << std::regex_match(sC1, rC1) << std::endl; // No match since all lowercase (matches if all characters are uppercase letters).
	std::cout << "regex_match(\"" << sC1 << "\", \"[A-Za-z0-9_]*\"): " << std::regex_match(sC1, rC2) << std::endl; // Match since contains one or no <upper case><lower case><digit> permutation. 
	std::cout << "regex_match(\"" << sC2 << "\", \"(\\w)\"): " << std::regex_match(sC2, rC) << std::endl; // 
	std::cout << "regex_match(\"" << sC2 << "\", \"(\\W)\"): " << std::regex_match(sC2, rC1) << std::endl;
	std::cout << "regex_match(\"" << sC2 << "\", \"[A-Za-z0-9_]*\"): " << std::regex_match(sC2, rC2) << std::endl;

	system("pause");

	return 0;
}