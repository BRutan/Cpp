/* Main.cpp (exercise 5.2+5.3.8)
Description:
	* Solution to exercise.
*/

#include <boost\date_time\gregorian\gregorian.hpp>
#include <boost\algorithm\string\classification.hpp>
#include <boost\algorithm\string\trim.hpp>
#include <iostream>
#include <fstream>
#include <list>
#include <regex>
#include <string>
#include <tuple>
#include <vector>

using Data = std::tuple<boost::gregorian::date, std::vector<double>>;
using ResultSet = std::list<Data>;

int main()
{
	std::regex matcher(",");
	std::ifstream inputFile;
	std::string currLine;
	
	// Open input file:
	try
	{
		inputFile.open("Input.txt");
	}
	catch (...)
	{
		std::cout << "Could not open input file (Input.txt)." << std::endl;
		system("pause");
		return 1;
	}
	std::string topLine;
	std::vector<double> lineData;
	ResultSet result;
	Data currElement;

	// Parse file:
	std::size_t lineCount = 0;
	std::string temp;
	auto end = std::sregex_token_iterator();
	while (!inputFile.eof())
	{
		std::getline(inputFile, currLine);
		lineCount++;
		if (lineCount != 1)
		{
			boost::trim(currLine);
			if (currLine.length())
			{
				lineData.clear();
				auto iter = std::sregex_token_iterator(currLine.begin(), currLine.end(), matcher, -1);
				while (iter != end)
				{
					if (iter->str().find("-") != std::string::npos)
					{
						// Date has been found, extract and set:
						temp = iter->str();
						boost::trim_if(temp, [](char i) { return (i == '-' || i == ' '); });
						std::get<0>(currElement) = boost::gregorian::from_string(temp);
					}
					else
					{
						// Data has been found, append to the data list:
						temp = iter->str();
						boost::trim(temp);
						lineData.push_back(std::stod(temp));
					}
					iter++;
				}
				std::get<1>(currElement) = lineData;
				result.push_back(currElement);
			}
		}
		else
		{
			topLine = currLine;
		}
	}
	
	inputFile.close();

	// Print all contents:
	std::size_t count;
	std::cout << topLine << std::endl;
	for (auto elem : result)
	{
		std::cout << std::get<0>(elem) << ": ";
		count = 0;
		for (auto data_elem : std::get<1>(elem))
		{
			count++;
			std::cout << data_elem << ((count < std::get<1>(elem).size()) ? ", " : "");
		}
		std::cout << std::endl;
	}

	system("pause");

	return 0;
}