/* Main.cpp (exercise 5.2+5.3.6)
Description:
	* Solutiosn to problems a-c.
*/


#include <iostream>
#include <regex>
#include <string>
#include <vector>

int main()
{
	std::regex ecmaReg("((\\+|-)?[[:digit:]]+)(\\.(([[:digit:]]+)?))?((e|E)((\\+|-)?)[[:digit:]]+)?");

	// a) This regular expression will match positive and negative integers, floating point numbers and scientific notation numbers.

	// b) Create program to test valid and invalid numbers:
	std::vector<double> validConversions;
	std::vector<std::string> test;
	test.push_back("++12345.2"); // Invalid
	test.push_back("123^45"); // Invalid
	test.push_back("45a.2"); // Invalid
	test.push_back("123"); // Valid
	test.push_back("-123");
	test.push_back("45.23");
	test.push_back("45E-2");

	for (auto i = test.begin(); i != test.end(); i++)
	{
		if (std::regex_match(*i, ecmaReg))
		{
			validConversions.push_back(std::stod(*i));
		}
	}

	// Print converted matches:
	std::cout << "Regex: " << "((\\+|-)?[[:digit:]]+)(\\.(([[:digit:]]+)?))?((e|E)((\\+|-)?)[[:digit:]]+)?" << std::endl;
	for (auto i : validConversions)
	{
		std::cout << i << std::endl;
	}

	system("pause");

	return 0;
}