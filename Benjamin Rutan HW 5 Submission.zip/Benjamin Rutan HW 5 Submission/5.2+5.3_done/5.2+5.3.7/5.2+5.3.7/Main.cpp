/* Main.cpp (exercise 5.2+5.3.6)
Description:
	* Solution to exercise.
*/

#include <iostream>
#include <regex>
#include <string>

int main()
{
	std::string test("Quick brown fox");
	std::string result;
	std::regex vowels("a|e|i|o|u");
	
	std::cout << "test (before replace): " << test << std::endl;

	// Use regex_replace to produce intended output:
	std::regex_replace(std::back_inserter(result), test.begin(), test.end(), vowels, "*");

	std::cout << "test (after replace): " << result << std::endl;
	
	system("pause");

	return 0;
}