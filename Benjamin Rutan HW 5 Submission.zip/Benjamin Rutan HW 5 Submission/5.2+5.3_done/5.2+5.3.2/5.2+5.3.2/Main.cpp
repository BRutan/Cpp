/* Main.cpp (exercise 5.2+5.3.2)
Description:
	* Solution to exercise 5.2+5.3.2.
*/

#include <iostream>
#include <regex>
#include <string>

int main()
{
	std::string myText("The rain in Spain stays mainly on the plain");
	std::regex mySearchReg("(rain)|(Spain)");

	std::smatch matches;

	std::cout << "myText = " << myText << std::endl;
	std::cout << "regex = " << "\"(rain)|(Spain)\"" << std::endl;
	
	// Find all matches to mySearchReg in myText string:
	if (std::regex_search(myText, matches, mySearchReg))
	{
		// Print the  match:
		std::cout << "First matched string: " << matches[0] << std::endl;
	}
	else
	{
		std::cout << "No matched strings." << std::endl;
	}

	system("pause");

	return 0;
}