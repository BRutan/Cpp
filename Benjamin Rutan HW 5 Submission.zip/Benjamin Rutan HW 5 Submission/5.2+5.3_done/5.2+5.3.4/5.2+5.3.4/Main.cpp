/* Main.cpp (exercise 5.2+5.3.4)
Description:
	* Solution to problems a-c.
*/

#include <iostream>
#include <regex>
#include <string>

int main()
{
	std::regex myReg10("/");
	std::string S3 = "2016/3/15";

	// a) Extract year, month and day from string:
	auto iter = std::sregex_token_iterator(S3.begin(), S3.end(), myReg10, -1);
	std::cout << "year: " << *iter++ << std::endl;
	std::cout << "month: " << *iter++ << std::endl;
	std::cout << "day: " << *iter++ << std::endl;

	// b) Extract hyphen from string:

	auto iter2 = std::sregex_token_iterator(S3.begin(), S3.end(), myReg10, 0);
	std::cout << "hyphen1: " << *iter2++ << std::endl;
	std::cout << "hyphen2: " << *iter2++ << std::endl;

	system("pause");

	return 0;
}