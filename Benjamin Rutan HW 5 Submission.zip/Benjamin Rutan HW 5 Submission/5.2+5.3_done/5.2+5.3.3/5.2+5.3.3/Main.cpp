/* Main.cpp (exercise 5.2+5.3.3)
Description:
	* Solutions to problems a-d.
*/


#include <iostream>
#include <regex>
#include <set>
#include <string>

int main()
{
	std::set<std::string> result;
	std::string s2 = "1,1,2,3,5,8,13,21";
	std::regex myReg("(\\d+),?");
	std::smatch currMatch;
	// a)
	std::cout << "s2: " << s2 << std::endl;
	std::cout << "myReg: " << "\"(\\d+),?\"" << std::endl;
	
	for (auto it = std::sregex_iterator(s2.begin(), s2.end(), myReg, std::regex_constants::match_default); it != std::sregex_iterator(); it++)
	{
		currMatch = *it;
		result.emplace(currMatch.str());
	}
	
	if (result.size() > 0)
	{
		std::cout << "Matches" << std::endl;
		for (auto i = result.begin(); i != result.end(); i++)
		{
			std::cout << *i << std::endl;
		}
	}
	else
	{
		std::cout << "No matches" << std::endl;
	}

	system("pause");

	return 0;
}