/* Main.cpp (exercise 5.2+5.3.5)
Description:
	* Solutions to problems a + b.
*/

#define _SCL_SECURE_NO_WARNINGS
#include <boost\algorithm\string\trim.hpp>
#include <boost\algorithm\string\split.hpp>
#include <boost\algorithm\string\classification.hpp>
#include <iostream>
#include <map>
#include <regex>
#include <string>

int main()
{
	// a) Extract assignment substrings within mainstring:
	std::string sA("a = 1, b = 2, c = 3");
	std::regex pattern(", ");
	std::map<std::string, int> assignments;
	std::vector<std::string> results;
	std::vector<std::string> currResults;
	auto iter = std::sregex_token_iterator(sA.begin(), sA.end(), pattern, -1);
	std::cout << "String: " << sA << std::endl;
	std::cout << "Extracted assignments: " << std::endl;
	
	std::size_t total = 0;
	while (total != 3)
	{
		results.push_back(*iter++);
		total++;
	}
	
	// b) Use split() to extract left and right parts and put into map:
	for (auto i = results.begin(); i != results.end(); i++)
	{
		boost::split(currResults, *i, boost::is_any_of("="));
		boost::trim<std::string>(currResults[0]);
		boost::trim<std::string>(currResults[1]);
		assignments.emplace(std::make_pair<std::string, int>(std::move(currResults[0]), std::stoi(currResults[1])));
	}
	std::cout << "Key = Mapped:" << std::endl;
	// Print all key and map pairs:
	for (auto i = assignments.begin(); i != assignments.end(); i++)
	{
		std::cout << std::get<0>(*i) << " = " << std::get<1>(*i) << std::endl;
	}


	system("pause");

	return 0;
}