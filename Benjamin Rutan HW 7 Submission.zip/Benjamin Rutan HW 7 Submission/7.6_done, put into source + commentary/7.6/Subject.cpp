/* Subject.hpp (exercise 7.6)
Description:
	* Handles list of Observers, notifying on changes.
Class Members:
	// Data:
	* list<shared_ptr<Observer>> observeList: List of observers.
	// Constructors/Destructor:
	* Subject(): Default constructor.
	* Subject(const Subject&): Copy constructor.
	* ~Subject(): Destructor.
	// Misc Methods:
	* void Attach(Observer*): Add new observer to observeList.
	* void Detach(): Remove observer from observeList.
	* void Notify(): call Update for each observer in observeList.
	// Overloaded Operators:
	* Subject& operator=(const Subject&): Assignment operator.
*/


/////////////////////////////
// Constructors/Destructor:
/////////////////////////////
/*
template<typename T, template<typename T, typename Alloc> class Container, typename Alloc = std::allocator<T>>
Subject<T, Container<T, Alloc>, Alloc>::Subject() : observeList()						// Default constructor. 
{

}

template<typename T, template<typename T, typename Alloc> class Container = std::deque, typename Alloc = std::allocator<T>>
Subject<T, Container, Alloc>::Subject(const Subject &in): observeList(in.observeList)		// Copy constructor. Copy observers 
{

}
template<typename T, template<typename T, typename Alloc> class Container = std::deque, typename Alloc = std::allocator<T>>
Subject<T, Container, Alloc>::~Subject() noexcept											// Destructor.
{

}
/////////////////////////////
// Misc Methods:
/////////////////////////////
template<typename T, template<typename T, typename Alloc> class Container = std::deque, typename Alloc = std::allocator<T>>
void Subject<T, Container, Alloc>::Attach(const T &f_in)
{
	this->observeList.push_back(f_in);
}
template<typename T, template<typename T, typename Alloc> class Container = std::deque, typename Alloc = std::allocator<T>>
void Subject<T, Container, Alloc>::Detach(const T &f_in)
{
	this->observeList.remove(f_in);
}
template<typename T, template<typename T, typename Alloc> class Container = std::deque, typename Alloc = std::allocator<T>>
void Subject<T, Container, Alloc>::Notify()													// Update each Observer in the observeList. 
{
	for (auto &it : observeList)
	{
		// Call each function in the list to update observers:
		it(std::dynamic_cast<Counter<T, Container, Alloc>*>(this))->GetCounter();
	}
}
/////////////////////////////
// Overloaded Operators:
/////////////////////////////
template<typename T, template<typename T, typename Alloc> class Container = std::deque, typename Alloc = std::allocator<T>>
Subject& Subject<T, Container, Alloc>::operator=(Subject &in)								// Assignment Operator
{
	if (this != &in)
	{
		this->observeList = in.observeList;
	}
	return *this;
} */