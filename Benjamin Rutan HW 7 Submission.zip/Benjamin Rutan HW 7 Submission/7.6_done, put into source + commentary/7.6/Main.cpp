/* Main.cpp (exercise 7.6)
Description:
	* Solutions to problems a-b.
*/

#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include "Counter.hpp"
#include "Subject.hpp"

int main()
{
	// b) Use deque to test "LongFormat" and "DoubleFormat" observers:
	std::function<void(double)> longFormat([](double value) { std::cout << std::setprecision(0) << "LongFormat value: " << value << std::endl; });
	std::function<void(double)> doubleFormat([](double value) { std::cout << std::setprecision(2) << std::fixed << "DoubleFormat value: " << value << std::endl; });
	
	Counter<std::function<void(double)>> count;
	count.Attach(longFormat);
	count.Attach(doubleFormat);

	std::cout << "Testing Counter: " << std::endl;
	count.IncreaseCounter();
	count.DecreaseCounter();
	


	system("pause");

	return 0;
}