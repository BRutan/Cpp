/* Counter.cpp (exercise 7.6)
Description:
	* Derived Subject class that increments or decrements a counter variable.
Class Members:
	// Data:
	* long double value: current counter value.
	// Constructors/Destructor:
	* Counter(): Default constructor. Set counter to 0.
	* Counter(const Counter&): Copy counter object.
	* ~Counter(): Destructor.
	// Misc Methods:
	* int GetCounter() const: Return current counter.
	* void IncreaseCounter(): Increase counter by 1.
	* void DecreaseCounter(): Decrease counter by 1.
	// Overloaded Operators:
	* Counter& operator=(const Counter&): Assignment operator.
*/


///////////////////////////
// Constructor/Destructor:
///////////////////////////
/*
template<typename T, template<typename T, typename Alloc> class Container = std::deque, typename Alloc = std::allocator<T>>
Counter<T, Container, Alloc>::Counter() noexcept	: Subject()						// Default constructor. Set counter to 0. 
{

}
template<typename T, template<typename T, typename Alloc> class Container = std::deque, typename Alloc = std::allocator<T>>
Counter<T, Container, Alloc>::Counter(const Counter &in) noexcept : Subject(in)		// Copy constructor. 
{

}
template<typename T, template<typename T, typename Alloc> class Container = std::deque, typename Alloc = std::allocator<T>>
Counter<T, Container, Alloc>::~Counter() noexcept									// Destructor. 
{

}
///////////////////////////
// Misc Methods:
///////////////////////////
template<typename T, template<typename T, typename Alloc> class Container = std::deque, typename Alloc = std::allocator<T>>
long double Counter<T, Container, Alloc>::GetCounter() const noexcept				// Return the current counter. 
{
	return value;
}
template<typename T, template<typename T, typename Alloc> class Container = std::deque, typename Alloc = std::allocator<T>>
void Counter<T, Container, Alloc>::IncreaseCounter() noexcept						// Increase the counter by 1. 
{
	this->value++;
	// Call Notify() to display to all observers:
	this->Notify();
}
template<typename T, template<typename T, typename Alloc> class Container = std::deque, typename Alloc = std::allocator<T>>
void Counter<T, Container, Alloc>::DecreaseCounter() noexcept						// Decrease the counter by 1. 
{
	this->value--;
	// Call Notify() to display to all observers:
	this->Notify();
}
///////////////////////////
// Overloaded Operators:
///////////////////////////
template<typename T, template<typename T, typename Alloc> class Container = std::deque, typename Alloc = std::allocator<T>>
Counter& Counter<T, Container,Alloc>::operator=(const Counter &in) noexcept			// Assignment operator. 
{
	if (this != &in)
	{
		this->value = in.value;
	}
	return *this;
} */