/* Subject.hpp (exercise 7.6)
Description:
	* Handles list of Observers, notifying on changes.
Class Members:
	// Data:
	* list<function<void(double)>> observeList: List of functions with void return value and single double parameter to delegate observing.
	// Constructors/Destructor:
	* Subject(): Default constructor.
	* Subject(const Subject&): Copy constructor.
	* ~Subject(): Destructor.
	// Misc Methods:
	* void Attach(Observer*): Add new observer to observeList.  
	* void Detach(): Remove observer from observeList.
	* void Notify(): call Update for each observer in observeList.
	// Overloaded Operators:
	* Subject& operator=(const Subject&): Assignment operator.
*/

#ifndef SUBJECT_HPP
#define SUBJECT_HPP

#include <deque>
#include <functional>
#include <memory>

template<typename T, template<typename T, typename A> class Container = std::deque, typename Alloc = std::allocator<T>>
class Subject
{
private:
	// Implement list of observers using template template parameters:
	Container<T, Alloc> observeList;
public:
	/////////////////////////////
	// Constructors/Destructor:
	/////////////////////////////
	Subject() : observeList()				/* Default constructor. */
	{

	}
	Subject(const Subject &in) : observeList(in.observeList)				/* Copy constructor. */
	{

	}
	Subject(Subject* in) : observeList(in->observeList)
	{

	}
	virtual ~Subject()														/* Destructor. */
	{

	}
	/////////////////////////////
	// Misc Methods:
	/////////////////////////////
	void Attach(const T &f_in)		/* Attach new Observer to the observeList. */
	{
		observeList.push_back(f_in);
	}
	void Detach(const T &f_in)			/* Remove Observer from observeList. */
	{
		observeList.remove(f_in);
	}
	void Notify()			/* Update each Observer in the observeList. */
	{
		for (auto iter = observeList.begin(); iter != observeList.end(); iter++)
		{
			// Call each function in the list to update observers, passing counter to each function:
			iter->operator()(((Counter<T>*)this)->GetCounter());
		}
	}
	/////////////////////////////
	// Overloaded Operators:
	/////////////////////////////
	Subject& operator=(const Subject &in) noexcept	/* Assignment Operator. */
	{
		if (this != &in)
		{
			this->observeList = in.observeList;
		}
		return *this;
	}
};

// #include "Subject.cpp"

#endif