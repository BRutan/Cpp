/* Counter.hpp (exercise 7.6)
Description:
	* Derived Subject class that increments or decrements a counter variable.
Class Members:
	// Data:
	* long double value: current counter value.
	// Constructors/Destructor:
	* Counter(): Default constructor. Set counter to 0.
	* Counter(const Counter&): Copy counter object.
	* ~Counter(): Destructor.
	// Misc Methods:
	* int GetCounter() const: Return current counter.
	* void IncreaseCounter(): Increase counter by 1.
	* void DecreaseCounter(): Decrease counter by 1.
	// Overloaded Operators:
	* Counter& operator=(const Counter&): Assignment operator.
*/

#ifndef COUNTER_HPP
#define COUNTER_HPP

#include <deque>
#include <functional>
#include "Subject.hpp"

template<typename T, template<typename T, typename A> class Container = std::deque, typename Alloc = std::allocator<T>>
class Counter : public Subject<T, Container, Alloc>
{
private:
	long double value;
public:
	///////////////////////////
	// Constructor/Destructor:
	///////////////////////////
	Counter() noexcept	: value(), Subject()								// Default constructor. Set counter to 0.
	{

	}
	Counter(const Counter &count_in) : value(count_in), Subject(count_in)	// Copy constructor.
	{

	}
	virtual ~Counter() override				// Destructor. 
	{

	}
	///////////////////////////
	// Misc Methods:
	///////////////////////////
	long double GetCounter() const noexcept		// Return the current counter. 
	{
		return this->value;
	}
	void IncreaseCounter()						// Increase the counter by 1. 
	{
		value++;
		// Notify all of the function observers in base class of change to counter:
		this->Notify();
	}
	void DecreaseCounter()						// Decrease the counter by 1.
	{
		value--;
		// Notify all of the function observers in base class of change to counter:
		this->Notify();
	}
	///////////////////////////
	// Overloaded Operators:
	///////////////////////////
	Counter& operator=(const Counter &in)		// Assignment operator. Deep copy the counter (value) from passed Counter object. 
	{
		if (this != &in)
		{
			this->value = in.value;
			Subject::operator=(in);
		}
		return *this;
	}
};

#include "Counter.cpp" 

#endif