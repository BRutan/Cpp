/* ShapeFactory.cpp (exercise 7.1)
Description:
	* Factory abstract base class for derived classes (ConsoleShapeFactory).
Class Members:
	// Constructors/Destructor:
	* ShapeFactory(): Default constructor.
	* ShapeFactory(const ShapeFactory&): Copy constructor.
	* ~ShapeFactory(): Destructor.
	// Misc Methods:
	* std::tuple<Circle, Line, Point> CreateShapes() const: PVMF to be overriden in derived class. Return tuple containing varying number of shapes, depending upon user input from stdin.
	// Overloaded Operators:
	* ShapeFactory& operator=(const ShapeFactory&): Assignment operator.
*/

#include "Circle.hpp"
#include "Line.hpp"
#include "Point.hpp"
#include "Shape.hpp"
#include "ShapeFactory.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
ShapeFactory::ShapeFactory() noexcept						/* Default constructor. */
{

}
ShapeFactory::ShapeFactory(const ShapeFactory &in) noexcept		/* Copy constructor. */
{

}
ShapeFactory::~ShapeFactory() noexcept						/* Destructor. */
{

}

////////////////////////////
// Overloaded Operators:
////////////////////////////
ShapeFactory& ShapeFactory::operator=(const ShapeFactory &in) noexcept	/* Assignment operator. */
{
	if (this != &in)
	{

	}
	return *this;
}
