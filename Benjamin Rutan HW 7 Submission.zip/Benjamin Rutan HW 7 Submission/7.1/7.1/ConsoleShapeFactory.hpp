/* ConsoleShapeFactory.hpp (exercise 7.1)
Description:
	* Derived from ShapeFactory, 
Class Members:
	// Constructors/Destructor:
	* ConsoleShapeFactory(): Default constructor.
	* ConsoleShapeFactory(const ConsoleShapeFactory&): Copy constructor.
	* ~ConsoleShapeFactory(): Destructor.
	// Misc Methods:
	* std::tuple<Circle, Line, Point> CreateShapes() const: Return tuple containing varying number of shapes, depending upon user input from stdin.
	// Overloaded Operators:
	* ConsoleShapeFactory& operator=(const ConsoleShapeFactory&): Assignment operator.
*/

#ifndef CONSOLESHAPEFACTORY_HPP
#define CONSOLESHAPEFACTORY_HPP

#include <algorithm>
#include <memory>
#include <string>
#include "ShapeFactory.hpp"

class ConsoleShapeFactory : public ShapeFactory
{	
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	ConsoleShapeFactory() noexcept;									/* Default constructor. */
	ConsoleShapeFactory(const ConsoleShapeFactory&) noexcept;		/* Copy constructor. */
	virtual ~ConsoleShapeFactory() noexcept override;				/* Destructor. */
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	virtual std::tuple<Circle, Line, Point> CreateShapes() const noexcept override;	/* Return tuple containing varying number of shapes, depending upon user input from stdin. */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	ConsoleShapeFactory& operator=(const ConsoleShapeFactory&) noexcept;	/* Assignment operator. */
};

#endif