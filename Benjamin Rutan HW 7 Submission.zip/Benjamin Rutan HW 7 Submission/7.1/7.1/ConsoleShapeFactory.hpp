/* ConsoleShapeFactory.hpp (exercise 7.1)
Description:
	* Derived from ShapeFactory, 
Class Members:
	// Constructors/Destructor:
	* ConsoleShapeFactory(): Default constructor.
	* ConsoleShapeFactory(const ConsoleShapeFactory&): Copy constructor.
	* ~ConsoleShapeFactory(): Destructor.
	// Misc Methods:
	* tuple<Shape...> CreateShapes() const: PVMF, return a tuple to user containing varying number of shapes. 
	// Overloaded Operators:
	* ConsoleShapeFactory& operator=(const ConsoleShapeFactory&): Assignment operator.
*/

#ifndef CONSOLESHAPEFACTORY_HPP
#define CONSOLESHAPEFACTORY_HPP

#include <algorithm>
#include <memory>
#include <string>
#include "ShapeFactory.hpp"

class ConsoleShapeFactory : public ShapeFactory
{
private:
	
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	ConsoleShapeFactory() noexcept;									/* Default constructor. */
	ConsoleShapeFactory(const ConsoleShapeFactory&) noexcept;		/* Copy constructor. */
	virtual ~ConsoleShapeFactory() noexcept;						/* Destructor. */
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	template<typename... Shapes>
	virtual std::tuple<Shapes...> CreateShapes(const std::string&) const noexcept;	/* Return tuple containing varying number of shapes, depending upon user input from stdin. */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	ConsoleShapeFactory& operator=(const ConsoleShapeFactory&) noexcept;	/* Assignment operator. */
};

#endif