/* ShapeFactory.hpp (exercise 7.1)
Description:
	* Factory abstract base class for derived classes (ConsoleShapeFactory).
Class Members:
	// Constructors/Destructor:
	* ShapeFactory(): Default constructor.
	* ShapeFactory(const ShapeFactory&): Copy constructor.
	* ~ShapeFactory(): Destructor.
	// Misc Methods:
	* std::tuple<Circle, Line, Point> CreateShapes() const: Return tuple containing varying number of shapes, depending upon user input from stdin.
	// Overloaded Operators:
	* ShapeFactory& operator=(const ShapeFactory&): Assignment operator. 
*/

#ifndef SHAPEFACTORY_HPP
#define SHAPEFACTORY_HPP

#include <tuple>
#include "Circle.hpp"
#include "Line.hpp"
#include "Point.hpp"
#include "Shape.hpp"

class ShapeFactory
{
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	ShapeFactory() noexcept;						/* Default constructor. */
	ShapeFactory(const ShapeFactory&) noexcept;		/* Copy constructor. */
	virtual ~ShapeFactory() noexcept;				/* Destructor. */
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	virtual std::tuple<Circle, Line, Point> CreateShapes() const noexcept = 0;	/* Return tuple containing a default instantiation of each derived Shape class. */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	ShapeFactory& operator=(const ShapeFactory&) noexcept;	/* Assignment operator. */
};

#endif