/* ShapeFactory.hpp (exercise 7.1)
Description:
	* Factory abstract base class for derived classes (ConsoleShapeFactory).
Class Members:
	// Constructors/Destructor:
	* ShapeFactory(): Default constructor.
	* ShapeFactory(const ShapeFactory&): Copy constructor.
	* ~ShapeFactory(): Destructor.
	// Misc Methods:
	* tuple<Shape...> CreateShapes() const: PVMF, return a tuple to user containing varying number of shapes. 
	// Overloaded Operators:
	* ShapeFactory& operator=(const ShapeFactory&): Assignment operator. 
*/

#ifndef SHAPEFACTORY_HPP
#define SHAPEFACTORY_HPP

#include <tuple>
#include "Circle.hpp"
#include "Line.hpp"
#include "Point.hpp"
#include "Shape.hpp"

class ShapeFactory
{
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	ShapeFactory() noexcept;						/* Default constructor. */
	ShapeFactory(const ShapeFactory&) noexcept;		/* Copy constructor. */
	virtual ~ShapeFactory() noexcept;				/* Destructor. */
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	template<typename... Shapes>
	virtual std::tuple<Shapes...> CreateShapes() const noexcept = 0;	/* PVMFs to be overwritten in derived classes (ConsoleShapeFactory). */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	ShapeFactory& operator=(const ShapeFactory&) noexcept;	/* Assignment operator. */
};

#endif