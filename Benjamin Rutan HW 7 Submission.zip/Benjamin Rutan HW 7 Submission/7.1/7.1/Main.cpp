/* Main.cpp (exercise 7.1)
Description:
	* Solutions to problems a-e.
*/

#include <iostream>
#include "ConsoleShapeFactory.hpp"
#include "Circle.hpp"
#include "Line.hpp"
#include "Point.hpp"
#include "Shape.hpp"
#include "ShapeFactory.hpp"

int main()
{
	// e) Create test program for ShapeFactory:
	ShapeFactory *test = new ConsoleShapeFactory();
	std::cout << "Testing ConsoleShapeFactory() that generates derived Shape objects:" << std::endl;

	std::string test2;
	system("pause");

	return 0;
}