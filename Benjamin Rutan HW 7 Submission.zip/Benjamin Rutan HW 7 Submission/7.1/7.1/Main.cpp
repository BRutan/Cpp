/* Main.cpp (exercise 7.1)
Description:
	* Solutions to problems a-e.
*/

#include <iostream>
#include <memory>
#include "ConsoleShapeFactory.hpp"
#include "Circle.hpp"
#include "Line.hpp"
#include "Point.hpp"
#include "Shape.hpp"
#include "ShapeFactory.hpp"

int main()
{
	// e) Create test program for ConsoleShapeFactory:
	ConsoleShapeFactory test;
	std::cout << "Testing ConsoleShapeFactory() that generates derived Shape objects:" << std::endl;
	// Generate tuple<Circle, Line, Point> containing default constructed derived Shape objects using ConsoleShapeFactory::CreateShapes(): 
	auto output = test.CreateShapes();

	// Unpack output tuple:



	system("pause");

	return 0;
}