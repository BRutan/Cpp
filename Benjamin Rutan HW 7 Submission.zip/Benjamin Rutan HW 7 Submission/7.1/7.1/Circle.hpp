/* Circle.hpp (exercise 7.1)
Description:
	*Declare Circle class that represents circle in 2-D Euclidean space.
State Variables/Objects:
	*Point centerPoint: the center of the circle.
	*double m_radius: the radius of the circle.
Member Functions:
	// Constructors/Destructor:
	*Circle(): Default constructor (sets centerPoint's state to (0,0)). 
	*Circle(const Point&, double): Overloaded constructor (sets centerPoint's state to passed Point's state, sets m_radius). 
	*Circle(const Circle&): Copy constructor (sets calling Circle object's state to passed Circle object's state).
	*~Circle():	Destructor (frees memory allocated for centerPoint during construction).
	// Accessors:
	*Point CenterPoint() const: Return the centerPoint Point object. 
	*double Radius() const: Return the radius of the Circle object. 
	// Mutators:
	*void CenterPoint(const Point&): Set the centerPoint object's state to the passed Point object's state.
	*void Radius(double):	Set the radius of the circle.
	// Misc. methods:
	*double Circumference() const: calculates and returns circumference of Circle object.
	*double Diameter() const: calculates and returns diameter of Circle object.
	*void Print() const: "Print" the Circle to stdout. 
	// Overloaded Operators:
	*Circle& operator=(const Circle&): Assignment operator.
*/

#ifndef CIRCLE_HPP
#define CIRCLE_HPP

#include<iostream>
#include<string>
#include"Point.hpp"
#include"Shape.hpp"

class Circle : public Shape
{
private:
	//////////////////////////////////////
	// State objects/variables: 
	//////////////////////////////////////
	Point centerPoint;							/* Center of circle. */
	double m_radius;							/* Radius of circle. */
public:
	//////////////////////////////////////
	// Constructors/Destructor:
	//////////////////////////////////////
	Circle();									/* Default constructor. */
	Circle(const Point&, double);				/* Overloaded constructor, set centerPoint and radius. */
	Circle(const Circle&);						/* Copy constructor. */
	virtual ~Circle();							/* Destructor. */
	//////////////////////////////////////
	// Accessors:
	//////////////////////////////////////
	Point CenterPoint() const;					/* Return center point as Point object. */
	double Radius() const;	 					/* Return the radius of the circle. */
	//////////////////////////////////////
	// Mutators:
	//////////////////////////////////////
	void CenterPoint(const Point&);				/* Set center point via copying coordinates of passed Point object. */
	void Radius(double);						/* Set the radius of the Circle. */
	//////////////////////////////////////
	// Misc. methods:
	//////////////////////////////////////
	double Circumference() const;				/* Return the Circumference of the circle. */
	double Diameter() const;					/* Return the Diameter of the circle. */
	virtual void Print() const;					/* "Print" the Circle to stdout. */
	//////////////////////////////////////
	// Overloaded Operators:
	//////////////////////////////////////
	// Member operators:
	Circle& operator=(const Circle&);			/* Assignment operator. */
};	


#endif