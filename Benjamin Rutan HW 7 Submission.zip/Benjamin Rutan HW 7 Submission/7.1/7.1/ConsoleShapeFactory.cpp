/* ConsoleShapeFactory.cpp (exercise 7.1)
Description:
	* Derived from ShapeFactory,
Class Members:
	// Constructors/Destructor:
	* ConsoleShapeFactory(): Default constructor. Do nothing since object has no state.
	* ConsoleShapeFactory(const ConsoleShapeFactory&): Copy constructor. Do nothing since object has no state.
	* ~ConsoleShapeFactory(): Destructor. Do nothing since object has no state.
	// Misc Methods:
	* std::tuple<Circle, Line, Point> CreateShapes() const: Return tuple containing varying number of shapes, depending upon user input from stdin.
	// Overloaded Operators:
	* ConsoleShapeFactory& operator=(const ConsoleShapeFactory&): Assignment operator.
*/

#include "ConsoleShapeFactory.hpp"
#include "ShapeFactory.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
ConsoleShapeFactory::ConsoleShapeFactory() noexcept									/* Default constructor. */
{

}
ConsoleShapeFactory::ConsoleShapeFactory(const ConsoleShapeFactory &in) noexcept	/* Copy constructor. */
{

}
ConsoleShapeFactory::~ConsoleShapeFactory() noexcept								/* Destructor. */
{

}
////////////////////////////
// Misc Methods:
////////////////////////////
std::tuple<Circle, Line, Point> ConsoleShapeFactory::CreateShapes() const noexcept				/* Return tuple containing a default instantiation of each derived Shape class. */
{
	return std::make_tuple<Circle, Line, Point>(Circle(), Line(), Point());
}
////////////////////////////
// Overloaded Operators:
////////////////////////////
ConsoleShapeFactory& ConsoleShapeFactory::operator=(const ConsoleShapeFactory &in) noexcept				/* Assignment operator. */
{
	// Preclude self-assignment:
	if (this != &in)
	{

	}
	return *this;
}
template<std::size_t size, typename ...Shapes>
std::ostream& unfold_print(std::ostream &in, const std::tuple<...Shapes> &out)
{
	std::get<size>(out).Print();
	in << ", ";
	return unfold_print<size - 1, Shapes...>(out);
}
// Terminating Base case:
template<0, typename ...Shapes>
std::ostream& unfold_print(std::ostream &in, const std::tuple<...Shapes> &out)
{
	std::get<0>(out).Print();
	in << " }";
	return in;
}
std::ostream& operator<<(std::ostream &in, const std::tuple<Circle, Line, Point> &out)					/* Print ConsoleShapeFactory.CreateShapes() output. */
{
	std::cout << "Tuple: { ";
	return unfold_print<3>(in, out);
}



