/* ConsoleShapeFactory.cpp (exercise 7.1)
Description:
	* Derived from ShapeFactory,
Class Members:
	// Constructors/Destructor:
	* ConsoleShapeFactory(): Default constructor.
	* ConsoleShapeFactory(const ConsoleShapeFactory&): Copy constructor.
	* ~ConsoleShapeFactory(): Destructor.
	// Misc Methods:
	* Circle CreateCircle(double p_x, double p_y, double rad) const: PVMF, create a Circle object using passed parameters.
	// Overloaded Operators:
	* ConsoleShapeFactory& operator=(const ConsoleShapeFactory&): Assignment operator.
*/

#include "ConsoleShapeFactory.hpp"
#include "ShapeFactory.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
ConsoleShapeFactory::ConsoleShapeFactory() noexcept									/* Default constructor. */
{

}
ConsoleShapeFactory::ConsoleShapeFactory(const ConsoleShapeFactory &in) noexcept	/* Copy constructor. */
{

}
ConsoleShapeFactory::~ConsoleShapeFactory() noexcept								/* Destructor. */
{

}
////////////////////////////
// Misc Methods:
////////////////////////////
template<typename... Shapes>
std::tuple<Shapes...> ConsoleShapeFactory::CreateShapes(cont std::string &command_in) const noexcept	/* Return tuple containing varying number of shapes, depending upon user input from stdin. */
{
	// http://www.cplusplus.com/reference/tuple/tuple_cat/
	char toCreate[3] = { 'p', 'c','l'};
	// Determine which version of tuple to create:
	auto pos = std::find(command_in.begin(), command_in.end(), 'p');
	if (pos != command_in.end())
	{

		command_in = command_in.substr(0, std::distance(command_in.begin(), pos)) + command_in.substr(0, std::distance(pos + 1, command_in.end()));
	}
	pos = std::find(command_in.begin(), command_in.end(), 'c');
	if (pos != command_in.end())
	{

		command_in = command_in.substr(0, std::distance(command_in.begin(), pos)) + command_in.substr(0, std::distance(pos + 1, command_in.end()));
	}
	pos = std::find(command_in.begin(), command_in.end(), 'l');
	if (pos != command_in.end())
	{

		command_in = command_in.substr(0, std::distance(command_in.begin(), pos)) + command_in.substr(0, std::distance(pos + 1, command_in.end()));
	}
	// Use only first three letters:
}
////////////////////////////
// Overloaded Operators:
////////////////////////////
ConsoleShapeFactory& ConsoleShapeFactory::operator=(const ConsoleShapeFactory &in) noexcept	/* Assignment operator. */
{
	if (this != &in)
	{

	}
	return *this;
}