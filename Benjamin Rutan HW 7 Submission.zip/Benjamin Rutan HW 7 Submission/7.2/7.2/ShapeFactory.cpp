/* ShapeFactory.cpp (exercise 7.2)
Description:
	* Factory abstract base class for derived classes (ConsoleShapeFactory).
Class Members:
	// Constructors/Destructor:
	* ShapeFactory(): Default constructor.
	* ShapeFactory(const ShapeFactory&): Copy constructor.
	* ~ShapeFactory(): Destructor.
	// Misc Methods:
	* std::tuple<Circle, Line, Point> CreateShapes() const: PVMF to be overriden in derived class. Return tuple containing varying number of shapes, depending upon user input from stdin.
	// Overloaded Operators:
	* ShapeFactory& operator=(const ShapeFactory&): Assignment operator.
*/

#include "Circle.hpp"
#include "Line.hpp"
#include "Point.hpp"
#include "Shape.hpp"
#include "ShapeFactory.hpp"

////////////////////////////
// Constructors/Destructor:
////////////////////////////
ShapeFactory::ShapeFactory(const ShapeCreatorFunc &s_in) : _CreatorFunc(s_in)	 	/* Overloaded constructor. Use user-defined function to generated particular derived Shape. */
{

}
ShapeFactory::ShapeFactory(const ShapeFactory &sF_in) : _CreatorFunc(sF_in)			/* Copy constructor. */
{

}
ShapeFactory::~ShapeFactory()														/* Destructor. */
{

}
////////////////////////////
// Misc Methods:
////////////////////////////
std::shared_ptr<Shape> ShapeFactory::Create() const									/* Return tuple containing a default instantiation of each derived Shape class. */
{
	// Return Shape based upon instructions of user:
	return this->_CreatorFunc();
}
////////////////////////////
// Overloaded Operators:
////////////////////////////
ShapeFactory& ShapeFactory::operator=(const ShapeFactory &in)						/* Assignment operator. Copy _Creator function of passed ShapeFactory object. */
{
	if (this != &in)
	{
		this->_CreatorFunc = in._CreatorFunc;
	}
	return *this;
}
