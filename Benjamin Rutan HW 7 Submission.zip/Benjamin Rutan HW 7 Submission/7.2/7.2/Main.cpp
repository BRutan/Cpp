/* Main.cpp (exercise 7.2)
Description:
	*



*/

#include <iostream>

int main()
{
	// Create instance of ShapeFactory and pass 

	return 0;
}