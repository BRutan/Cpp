/* ConsoleShapeFactory.hpp (exercise 7.2)
Description:
	* Uses individual Create functions to generate Circle, Line, and Point (derived from Shape) objects using passed parameters to set state.
Class Members:
	// Constructors/Destructor:
	* ConsoleShapeFactory(): Default constructor.
	* ConsoleShapeFactory(const ConsoleShapeFactory&): Copy constructor.
	* ~ConsoleShapeFactory(): Destructor.
	// Misc Methods:
	* Circle CreateCircle(double p_x, double p_y, double rad) const: PVMF, create a Circle object using passed parameters.
	* Line CreateLine(double p1_x, double p1_y, double p2_x, double p2_y) const: PVMF, create a Line object using passed parameters.
	* Point CreatePoint(double p_x, double p_y) const: PVMF, create a Point object using passed parameters.
	// Overloaded Operators:
	* ConsoleShapeFactory& operator=(const ConsoleShapeFactory&): Assignment operator.
*/

#ifndef CONSOLESHAPEFACTORY_HPP
#define CONSOLESHAPEFACTORY_HPP

#include <memory>
#include "Circle.hpp"
#include "Line.hpp"
#include "Point.hpp"
#include "Shape.hpp"

class ConsoleShapeFactory
{
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	ConsoleShapeFactory();									/* Default constructor. Do nothing since ConsoleShapeFactory does not have state. */
	ConsoleShapeFactory(const ConsoleShapeFactory&);		/* Copy constructor. Do nothing since ConsoleShapeFactory does not have state. */
	virtual ~ConsoleShapeFactory();						/* Destructor. Do nothing since ConsoleShapeFactory does not have state. */
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	std::shared_ptr<Shape> CreateCircle(double p_x, double p_y, double rad) const;					/* Create new Circle on heap with Point having (p_x, p_y) as coordinates and radius of rad. */
	std::shared_ptr<Shape> CreateLine(double p1_x, double p1_y, double p2_x, double p2_y) const;	/* Create new Line on heap with Point1 having (p1_x, p1_y) and Point2 having (p2_x, p2_y) as coordinates. */
	std::shared_ptr<Shape> CreatePoint(double p_x, double p_y) const;								/* Create new Point on heap with coordinates (p_x, p_y). */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	ConsoleShapeFactory& operator=(const ConsoleShapeFactory&);	/* Assignment operator. Do nothing since ConsoleShapeFactory does not have state. */
};

#endif