/* ShapeFactory.hpp (exercise 7.2)
Description:
	* Factory abstract base class for derived classes (ConsoleShapeFactory).
Class Members:
	// Constructors/Destructor:
	* ShapeFactory(): Default constructor.
	* ShapeFactory(const ShapeFactory&): Copy constructor.
	* ~ShapeFactory(): Destructor.
	// Misc Methods:
	* std::tuple<Circle, Line, Point> CreateShapes() const: Return tuple containing varying number of shapes, depending upon user input from stdin.
	// Overloaded Operators:
	* ShapeFactory& operator=(const ShapeFactory&): Assignment operator. 
*/

#ifndef SHAPEFACTORY_HPP
#define SHAPEFACTORY_HPP

#include <functional>
#include <memory>
#include <tuple>
#include "Circle.hpp"
#include "Line.hpp"
#include "Point.hpp"
#include "Shape.hpp"

template<typename ...Inputs>
using ShapeCreatorFunc = std::function<std::shared_ptr<Shape>(Inputs...)>;		/* Parameters are: Point_X, Point_Y, Radius. */

class ShapeFactory
{
private:
	// State based approach: allow user to specify how what state Circles, Lines and Points are given on CreateShape(). 
	template<typename ...Inputs>
	ShapeCreatorFunc<Inputs...> _CreatorFunc;					/* Customize how Circle objects are created. */
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	template<typename ...Inputs>
	ShapeFactory(const ShapeCreatorFunc<Inputs...>&);						/* Overloaded constructor. */
	ShapeFactory(const ShapeFactory&);										/* Copy constructor. Copy _CreatorFunc from passed ShapeFactory object. */
	virtual ~ShapeFactory();												/* Destructor. */
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	virtual std::shared_ptr<Shape> Create() const;							/* Return tuple containing a default instantiation of each derived Shape class. */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	ShapeFactory& operator=(const ShapeFactory&);	/* Assignment operator. */
};

#endif