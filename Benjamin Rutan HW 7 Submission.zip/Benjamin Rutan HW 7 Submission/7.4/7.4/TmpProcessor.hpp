/*




*/

#ifndef TMPPROCESSOR_HPP
#define TMPPROCESSOR_HPP

#include <functional>

template<typename T>
using FactoryFunction = std::function<T()>;

template<typename T>
using ComputeFunction = std::function<T(const T&)>;

template<typename T>
using DispatchFunction = std::function<void(T&)>;

template<typename T>
class TmpProcessor
{
private:
	FactoryFunction<T> _factory;
	ComputeFunction<T> _compute;
	DispatchFunction<T> _dispatch;
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	TmpProcessor(const FactoryFunction<T> &factory, const ComputeFunction<T> &compute, const DispatchFunction<T> &dispatch) noexcept : _factory(factory), _compute(compute), _dispatch(dispatch)
	{

	}
	TmpProcessor(const TmpProcessor &in) noexcept : _factory(in._factory), _compute(in._compute), _dispatch(in._dispatch)		/* Copy constructor. */
	{

	}
	~TmpProcessor() noexcept
	{

	}
	////////////////////////////
	// Misc. Methods:
	////////////////////////////
	virtual void algorithm() final				/* Run internal functions in factor, compute and dispatch order. */
	{
		T val = this->_factory();
		T val2 = this->_compute(val);
		this->_dispatch(val2);
	}
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	TmpProcessor& operator=(const TmpProcessor &in) noexcept		/* Assignment operator. */
	{
		if (this != &in)
		{
			this->_compute = in._compute;
			this->_dispatch = in._dispatch;
			this->_factory = in._factory;
		}
		return *this;
	}
};

#endif