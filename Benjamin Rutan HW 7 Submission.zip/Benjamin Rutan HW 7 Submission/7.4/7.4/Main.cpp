/* Main.cpp (exericse 7.4)
Description:
	*


*/

#include <future>
#include <iostream>
#include <thread>
#include "TmpProcessor.hpp"

int main()
{
	// Test simple cases of TmpProcessor using Lambdas:
	
	FactoryFunction<double> fact = []() { return 456.00; };
	ComputeFunction<double> comp([](const double &in) { return in * in; });
	DispatchFunction<double> disp([](double &in) ->void { std::cout << "Dispatch: " << in << std::endl; });
	
	TmpProcessor<double> temp1(fact, comp, disp);
	temp1.algorithm();
	
	// Use thread and future objects to run compute intensive algorithms in parallel:
	FactoryFunction<double> fact_intense([]()->double{ long double accum = 0; for (long double i = 0; i < 1000000000; i++) accum += i; return accum; });
	ComputeFunction<double> comp_intense([](const double &in)->double{ double output = in; for (long double i = 0; i < 1000000000; i++) output -= i; return output; });
	std::promise<double> prom1, prom2;
	std::future<double> fut1 = prom1.get_future();
	TmpProcessor<double> intense(fact_intense, comp_intense, disp);
	// Execute asynchronously:
	//// NEed to run one sequentially, then one with parallel programming (using mutexes presumably:
	std::async(intense.algorithm(), std::move(prom1));
	std::async(intense.algorithm(), std::move(prom2));
	std::cout << "Result of intensive computation 1: " << fut1.get() << std::endl;
	std::cout << "Result of intensive computation 2: " << fut2.get() << std::endl;


	system("pause");

	return 0;
}