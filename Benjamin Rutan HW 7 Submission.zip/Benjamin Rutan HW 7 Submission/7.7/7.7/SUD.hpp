/*




*/

#ifndef SUD_HPP
#define SUD_HPP

#include <string>
#include <iostream>
#include <boost\algorithm\string.hpp>

template <typename T1, typename T2, template <typename T1> class Source, template <typename T2> class Sink, template <typename T1, typename T2> class Processing>
class SUD : private Source<T1>, private Sink<T2>, private Processing<T1, T2>
{ // System under discussion
private:
	// Define the requires interfaces that SUD needs
	using I::message; // Get input
	using Processing::convert; // Convert input to output
	using O::print; // Produce output
	using O::end; // End of program
public:
	void run()
	{
		// Core process, showing mediating role of SUD 
		auto s = message(); // I, input 
		convert(s);			// P, processing 
		print(s);			// O. output
		end(); // O, signals end of program 
	} 	
};


template<typename T1>
class Source
{
public:
	T1 message() const
	{
		// Generate output using user input from stdin:
		T1 output;
		std::cin >> output;
		return output;
	}
};

template<typename T2>
class Sink
{
	void convert(T2 &in)
	{
		
	}
};

template<typename T1, typename T2>
class Processing
{
	void print(const T1 &in) const
	{
		std::cout << in << std::endl;
	}
	void end() const
	{
		std::cout << "end" << std::endl;
	}
};

#endif