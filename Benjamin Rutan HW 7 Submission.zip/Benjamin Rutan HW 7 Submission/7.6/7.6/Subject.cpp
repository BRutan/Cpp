/* Subject.hpp (exercise 7.6)
Description:
	* Handles list of Observers, notifying on changes.
Class Members:
	// Data:
	* list<shared_ptr<Observer>> observeList: List of observers.
	// Constructors/Destructor:
	* Subject(): Default constructor.
	* Subject(const Subject&): Copy constructor.
	* ~Subject(): Destructor.
	// Misc Methods:
	* void Attach(Observer*): Add new observer to observeList.
	* void Detach(): Remove observer from observeList.
	* void Notify(): call Update for each observer in observeList.
	// Overloaded Operators:
	* Subject& operator=(const Subject&): Assignment operator.
*/


#include "Subject.hpp"
#include "Observer.hpp"

/////////////////////////////
// Constructors/Destructor:
/////////////////////////////
Subject::Subject() noexcept : observeList()		/* Default constructor. */
{

}
Subject::Subject(const Subject &in) noexcept : observeList(in.observeList)		/* Copy constructor. */
{

}
Subject::~Subject() noexcept					/* Destructor. */
{

}
/////////////////////////////
// Misc Methods:
/////////////////////////////
void Subject::Attach(std::shared_ptr<Observer> &obs_in) noexcept	/* Attach new Observer to the observeList. */
{
	observeList.push_back(obs_in);
}
void Subject::Detach(std::shared_ptr<Observer> &obs_in) noexcept	/* Remove Observer from observeList. */
{
	observeList.remove(obs_in);
}
void Subject::Notify() noexcept				/* Update each Observer in the observeList. */
{
	for (auto it = observeList.begin(); it != observeList.end(); it++)
	{
		(*it)->Update(this);
	}
}
/////////////////////////////
// Overloaded Operators:
/////////////////////////////
Subject& Subject::operator=(Subject &in) noexcept		/* Assignment Operator. */
{
	if (this != &in)
	{
		this->observeList = in.observeList;
	}
	return *this;
}