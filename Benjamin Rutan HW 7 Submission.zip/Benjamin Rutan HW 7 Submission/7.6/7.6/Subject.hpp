/* Subject.hpp (exercise 7.6)
Description:
	* Handles list of Observers, notifying on changes.
Class Members:
	// Data:
	* list<shared_ptr<Observer>> observeList: List of observers.
	// Constructors/Destructor:
	* Subject(): Default constructor.
	* Subject(const Subject&): Copy constructor.
	* ~Subject(): Destructor.
	// Misc Methods:
	* void Attach(Observer*): Add new observer to observeList.  
	* void Detach(): Remove observer from observeList.
	* void Notify(): call Update for each observer in observeList.
	// Overloaded Operators:
	* Subject& operator=(const Subject&): Assignment operator.
*/

#ifndef SUBJECT_HPP
#define SUBJECT_HPP

#include <list>
#include <memory>

class Observer;

class Subject
{
private:
	std::list<std::shared_ptr<Observer>> observeList;
public:
	/////////////////////////////
	// Constructors/Destructor:
	/////////////////////////////
	Subject() noexcept;						/* Default constructor. */
	Subject(const Subject&) noexcept;		/* Copy constructor. */
	virtual ~Subject() noexcept;			/* Destructor. */
	/////////////////////////////
	// Misc Methods:
	/////////////////////////////
	virtual void Attach(std::shared_ptr<Observer>&) noexcept;	/* Attach new Observer to the observeList. */
	virtual void Detach(std::shared_ptr<Observer>&) noexcept;	/* Remove Observer from observeList. */
	virtual void Notify() noexcept;				/* Update each Observer in the observeList. */
	/////////////////////////////
	// Overloaded Operators:
	/////////////////////////////
	Subject& operator=(Subject&) noexcept;	/* Assignment Operator. */
};

#endif