/* Counter.hpp (exercise 7.6)
Description:
	* Derived Subject class that increments or decrements a counter variable.
Class Members:
	// Data:
	* long double value: current counter value.
	// Constructors/Destructor:
	* Counter(): Default constructor. Set counter to 0.
	* Counter(const Counter&): Copy counter object.
	* ~Counter(): Destructor.
	// Misc Methods:
	* int GetCounter() const: Return current counter.
	* void IncreaseCounter(): Increase counter by 1.
	* void DecreaseCounter(): Decrease counter by 1.
	// Overloaded Operators:
	* Counter& operator=(const Counter&): Assignment operator.
*/

#ifndef COUNTER_HPP
#define COUNTER_HPP

#include "Subject.hpp"

class Counter : public Subject
{
private:
	long double value;
public:
	///////////////////////////
	// Constructor/Destructor:
	///////////////////////////
	Counter() noexcept;					/* Default constructor. Set counter to 0.*/
	Counter(const Counter&) noexcept;	/* Copy constructor. */
	virtual ~Counter() noexcept;		/* Destructor. */
	///////////////////////////
	// Misc Methods:
	///////////////////////////
	long double GetCounter() const noexcept;		/* Return the current counter. */
	void IncreaseCounter() noexcept;				/* Increase the counter by 1. */
	void DecreaseCounter() noexcept;				/* Decrease the counter by 1. */
	///////////////////////////
	// Overloaded Operators:
	///////////////////////////
	Counter& operator=(const Counter&) noexcept;	/* Assignment operator.*/
};

#endif