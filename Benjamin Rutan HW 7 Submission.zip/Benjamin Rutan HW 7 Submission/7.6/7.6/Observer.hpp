/* Observer.hpp (exercise 7.6)
Description:
	* Abstract base class, to be derived in classes that observe data.
Class Members:
	// Constructors/Destructor:
	* Observer(): Default constructor. 
	* Observer(Observer*) noexcept: Copy constructor with pointers.
	* Observer(const Observer&): Copy constructor.
	* ~Observer(): Destructor.
	// Misc Methods:
	* void Update(Subject&) const: Update the subject.
	// Overloaded Operators:
	* Observer& operator=(const Observer&): Assignment operator.
*/

#ifndef OBSERVER_HPP
#define OBSERVER_HPP

#include <memory>

class Subject;

class Observer
{
public:
	///////////////////////////
	// Constructor/Destructor:
	///////////////////////////
	Observer() noexcept;				/* Default constructor. */
	Observer(const Observer&) noexcept;	/* Copy constructor. */
	Observer(Observer*) noexcept;		/* Copy constructor with pointers. */
	virtual ~Observer() noexcept;		/* Destructor. */
	///////////////////////////
	// Misc Methods:
	///////////////////////////
	virtual void Update(Subject*) noexcept = 0; /* PVMF to be define in derived classes. Update the subject. */
	///////////////////////////
	// Overloaded Operators:
	///////////////////////////
	Observer& operator=(const Observer&) noexcept;	/* Assignment operator. */
};

#endif