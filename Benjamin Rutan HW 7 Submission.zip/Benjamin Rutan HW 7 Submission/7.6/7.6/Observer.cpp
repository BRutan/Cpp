/* Observer.cpp (exercise 7.6)
Description:
	* Abstract base class, to be derived in classes that observe data.
Class Members:
	// Constructors/Destructor:
	* Observer(): Default constructor.
	* Observer(const Observer&): Copy constructor.
	* ~Observer(): Destructor.
	// Misc Methods:
	* void Update(Subject&) const: Update the subject.
	// Overloaded Operators:
	* Observer& operator=(const Observer&): Assignment operator.
*/

#include "Observer.hpp"
#include "Subject.hpp"

///////////////////////////
// Constructor/Destructor:
///////////////////////////
Observer::Observer() noexcept				/* Default constructor. */
{

}
Observer::Observer(Observer *in) noexcept	/* Copy constructor with pointers. */
{

}
Observer::Observer(const Observer&)	noexcept	/* Copy constructor. */
{

}
Observer::~Observer() noexcept				/* Destructor. */
{

}
///////////////////////////
// Overloaded Operators:
///////////////////////////
Observer& Observer::operator=(const Observer &in) noexcept	/* Assignment operator. */
{
	if (this != &in)
	{

	}
	return *this;
}

