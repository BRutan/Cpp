/* Main.cpp (exercise 7.6)
Description:
	* Solutions to problems a-l.
*/

#include <iostream>
#include "Counter.hpp"
#include "DoubleFormat.hpp"
#include "LongFormat.hpp"
#include "Observer.hpp"
#include "Subject.hpp"

int main()
{
	// f) Test the Subject and Observer classes:
	std::shared_ptr<Subject> count(new Counter());
	std::shared_ptr<Observer> obs1(new LongFormat(count));
	std::shared_ptr<Observer> obs2(new DoubleFormat(count));
	
	// Attach to counter:
	count->Attach(obs1);
	count->Attach(obs2);
	// Ensure that observers are listening:
	std::dynamic_pointer_cast<Counter, Subject>(count)->IncreaseCounter();
	std::dynamic_pointer_cast<Counter, Subject>(count)->DecreaseCounter();	
	
	system("pause");

	return 0;
}