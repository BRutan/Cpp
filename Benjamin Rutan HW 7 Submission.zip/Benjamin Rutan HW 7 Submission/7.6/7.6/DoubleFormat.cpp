/* DoubleFormat.cpp (exercise 7.6)
Description:
	* Displays data in Counter as a double floating point.
Class Members:
	// Data:
	* shared_ptr<Subject> stored_subj: Current attached-to subject.
	// Constructors/Destructor:
	* DoubleFormat(): Default constructor.
	* DoubleFormat(shared_ptr<Subject> subj_in *subj_in) noexcept: Overloaded Constructor. Set the stored_subj and attach to.
	* DoubleFormat(const DoubleFormat&): Copy constructor.
	* ~DoubleFormat(): Destructor.
	// Misc Methods:
	* void Update(Subject&) const: Update the subject.
	// Overloaded Operators:
	* DoubleFormat& operator=(const DoubleFormat&): Assignment operator.
*/

#include <iomanip>
#include <iostream>
#include <memory>
#include "DoubleFormat.hpp"
#include "Observer.hpp"
#include "Subject.hpp"
#include "Counter.hpp"

///////////////////////////
// Constructor/Destructor:
///////////////////////////
DoubleFormat::DoubleFormat() noexcept : stored_subj(nullptr)						/* Default constructor. */
{

}
DoubleFormat::DoubleFormat(std::shared_ptr<Subject> &subj_in) noexcept : stored_subj(subj_in)						/* Default constructor. */
{
	std::shared_ptr<Observer> temp = std::make_shared<DoubleFormat>(this);
	subj_in->Attach(temp);
}
DoubleFormat::DoubleFormat(const DoubleFormat &df) noexcept	: stored_subj(df.stored_subj)			/* Copy constructor. */
{

}
DoubleFormat::DoubleFormat(DoubleFormat *in) noexcept : stored_subj(in->stored_subj)
{

}
DoubleFormat::~DoubleFormat() noexcept													/* Destructor. */
{

}
///////////////////////////
// Misc Methods:
///////////////////////////
void DoubleFormat::Update(Subject *subj_in) noexcept									/* Update the subject. */
{
	if (subj_in == &(*stored_subj))
	{
		std::cout << std::setprecision(2) << std::dynamic_pointer_cast<Counter, Subject>(this->stored_subj)->GetCounter() << std::endl;
	}
}
///////////////////////////
// Overloaded Operators:
///////////////////////////
DoubleFormat& DoubleFormat::DoubleFormat::operator=(const DoubleFormat &in) noexcept	/* Assignment operator. */
{
	if (this != &in)
	{
		this->stored_subj.reset(in.stored_subj.get());
	}
	return *this;
}