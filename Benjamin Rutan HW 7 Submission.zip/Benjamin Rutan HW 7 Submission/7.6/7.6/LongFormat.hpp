/* LongFormat.hpp (exercise 7.6)
Description:
	* Abstract base class, to be derived in classes that observe data.
Class Members:
	// Data:
	* shared_ptr<Subject> stored_subj: Current attached-to subject.
	// Constructors/Destructor:
	* LongFormat(): Default constructor.
	* LongFormat(shared_ptr<Subject>&): Overloaded constructor. Set stored_subj and become attached to subject.
	* LongFormat(const LongFormat&): Copy constructor.
	* ~LongFormat(): Destructor.
	// Misc Methods:
	* void Update(Subject*): Update the subject.
	// Overloaded Operators:
	* LongFormat& operator=(const LongFormat&): Assignment operator.
*/

#ifndef LONGFORMAT_HPP
#define LONGFORMAT_HPP

#include <cmath>
#include <iomanip>
#include <iostream>
#include <memory>
#include "Observer.hpp"

class Subject;
class Counter;

class LongFormat : public Observer
{
private:
	std::shared_ptr<Subject> stored_subj;		/* Current attached - to subject. */
public:
	///////////////////////////
	// Constructor/Destructor:
	///////////////////////////
	LongFormat() noexcept;						/* Default constructor. */
	LongFormat(std::shared_ptr<Subject>&) noexcept;				/* Overloaded constructor. Set stored_subj and become attached to subject. */
	LongFormat(LongFormat*) noexcept;			/* Copy constructor with pointers. */
	LongFormat(const LongFormat&) noexcept;		/* Copy constructor. */
	virtual ~LongFormat() noexcept;				/* Destructor. */
	///////////////////////////
	// Misc Methods:
	///////////////////////////
	virtual void Update(Subject*) noexcept;	/* Update the subject. */
	///////////////////////////
	// Overloaded Operators:
	///////////////////////////
	LongFormat& operator=(const LongFormat&) noexcept;	/* Assignment operator. */
};

#endif