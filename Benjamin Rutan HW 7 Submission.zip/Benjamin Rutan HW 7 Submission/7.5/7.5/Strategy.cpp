/* Strategy.cpp (exercise 7.5)
Description:
	*



*/

#include "Strategy.hpp"
#include "Point.hpp"

///////////////////////////
// Constructors/Destructor: 
///////////////////////////
Strategy::Strategy(const DistanceFunction &dist_in) : _DistFunc(dist_in)							/* Overloaded constructor. Set the _DistFunc member function that calculates distance.*/
{

}
Strategy::~Strategy()												/* Destructor. Pop _DistFunc off of stack. */
{

}
///////////////////////////
// Accessors: 
///////////////////////////
DistanceFunction& Strategy::Calculate() 							/* Return _DistFunc to allow direct computation. */
{
	return this->_DistFunc;
}
///////////////////////////
// Mutators: 
///////////////////////////
void Strategy::SetDistanceFunction(const DistanceFunction &func_in)	/* Replace _DistFunc with another DistanceFunction. */
{
	this->_DistFunc = func_in;
}
///////////////////////////
// Overloaded Operators: 
///////////////////////////
Strategy& Strategy::operator=(const Strategy &in)		/* Assignment operator. Copy passed Strategy object's _DistFunc member. */
{
	if (this != &in)
	{
		this->_DistFunc = in._DistFunc;
	}
	return *this;
}