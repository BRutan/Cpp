/* Main.cpp (exercise 7.5)
Description:
	* Solutions to problems a-f.
*/

#include <functional>
#include <iostream>
#include <memory>
#include "Point.hpp"
#include "Strategy.hpp"

int main()
{
	// Create function objects that use Pythagorean theorem method and Taximan method to calculate distance between points:
	DistanceFunction exactMethod([](const Point &p1, const Point &p2) { return std::sqrt(std::pow(p1.X() - p2.X(), 2) + std::pow(p1.Y() - p2.Y(), 2)); });
	DistanceFunction taximanMethod([](const Point &p1, const Point &p2) { return std::abs(p1.X() - p2.X()) + std::abs(p1.Y() - p2.Y()); });
	// Create strategy object to hold distance calculation strategy:
	Strategy strat(exactMethod);
	Point p1(4.0, 5.0), p2(6.0, 7.0);
	// Test Stateless version (using Strategy in a function):
	std::cout << "Distance between "; p1.Print(); std::cout << " and "; p2.Print(); std::cout << " (using Pythagorean theorem): " << p1.Distance(p2, strat) << std::endl;
	// Test Taximan version:
	strat.SetDistanceFunction(taximanMethod);
	std::cout << "Distance between "; p1.Print(); std::cout << " and "; p2.Print(); std::cout << " (using Taximan approximation): " << p1.Distance(p2, strat) << std::endl;
	// Test State-Based version:





	system("pause");

	return 0;
}