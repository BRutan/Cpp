/* Main.cpp (exercise 7.5)
Description:
	* Solutions to problems a-f.
*/

#include <iostream>
#include <memory>
#include "Point.hpp"
#include "ApproximateDistance.hpp"
#include "DistanceStrategy.hpp"
#include "ExactDistance.hpp"

int main()
{
	// f) Calculate distance between two points using different DistanceStrategy methods:
	Point p1(4.0, 5.0), p2(12.0, 3.0);
	ApproximateDistance *strategy1 = new ApproximateDistance();
	ExactDistance *strategy2 = new ExactDistance();

	// Test passing distance strategies to Distance function:
	std::cout << "Distance between "; 
	p1.Print(); std::cout << ", ";
	p2.Print();
	std::cout << " (using ApproximateDistance): " << p1.Distance(p2, strategy1) << std::endl;
	std::cout << "Distance between ";
	p1.Print(); std::cout << ", ";
	Point(0, 0).Print();
	std::cout << " (using ApproximateDistance): " << p1.Distance(strategy1) << std::endl;

	// Change strategy to ExactDistance:
	
	std::cout << "Distance between ";
	p1.Print(); std::cout << ", ";
	p2.Print();
	std::cout << " (using ExactDistance): " << p1.Distance(p2, strategy2) << std::endl;
	std::cout << "Distance between ";
	p1.Print();
	std::cout << ", ";
	Point(0, 0).Print();
	std::cout << " (using ExactDistance): " << p1.Distance(strategy2) << std::endl;
	
	system("pause");

	return 0;
}