/* ApproximateDistance.hpp (exercise 7.5)
Description:
	* Calculate the approximate distance between two points using fast but inaccurate "taxi driver" algorithm.
Class Members:
	// Constructors/Destructor:
	* ApproximateDistance(): Default constructor.
	* ApproximateDistance(const ApproximateDistance&): Copy constructor.
	* ~ApproximateDistance(): Destructor.
	// Misc Methods:
	* double Distance(const Point&, const Point&) const: Calculate distance using "taxi driver" algorithm. 
	// Overloaded Operators:
	* ApproximateDistance& operator=(const ApproximateDistance&): Assignment Operator.
*/

#ifndef APPROXIMATEDISTANCE_HPP
#define APPROXIMATEDISTANCE_HPP

#include <cmath>
#include "DistanceStrategy.hpp"

class Point;

class ApproximateDistance : public DistanceStrategy
{
public:
	////////////////////////////
	// Constructors/Destructor:
	////////////////////////////
	ApproximateDistance() noexcept;							  /* Default constructor. */
	ApproximateDistance(const ApproximateDistance&) noexcept; /* Copy constructor. */
	virtual ~ApproximateDistance() noexcept;				  /* Destructor. */
	////////////////////////////
	// Misc Methods:
	////////////////////////////
	virtual double Distance(const Point&, const Point&) const noexcept;		/* Calculate distance using Pythagorean Theorem ("exact" precision). */
	////////////////////////////
	// Overloaded Operators:
	////////////////////////////
	ApproximateDistance& operator=(const ApproximateDistance&) noexcept;	/* Assignment operator. */
};

#endif