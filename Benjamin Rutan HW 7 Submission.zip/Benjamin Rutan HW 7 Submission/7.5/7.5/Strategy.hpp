/* Strategy.hpp (exercise 7.5)
Description:
	*



*/


#ifndef STRATEGY_HPP
#define STRATEGY_HPP

#include <functional>
#include <memory>

// Forward declare to prevent inclusion-exclusion problem:
class Point;

// Create general function object type for calculating distance between points. Parameters are (Point1, Point2):
using DistanceFunction = std::function<double(const Point&, const Point&)>;

class Strategy
{
private:
	DistanceFunction _DistFunc;
public:
	///////////////////////////
	// Constructors/Destructor: 
	///////////////////////////
	Strategy(const DistanceFunction&);					/* Overloaded constructor. Set the _DistFunc member function that calculates distance.*/
	virtual ~Strategy();								/* Destructor. Pop _DistFunc off of stack. */
	///////////////////////////
	// Mutators: 
	///////////////////////////
	void SetDistanceFunction(const DistanceFunction&);	/* Replace _DistFunc with another DistanceFunction. */
	///////////////////////////
	// Misc Functions: 
	///////////////////////////
	DistanceFunction& Calculate();						/* Return _DistFunc to allow direct computation. */
	///////////////////////////
	// Overloaded Operators: 
	///////////////////////////
	Strategy& operator=(const Strategy&);				/* Assignment operator. Copy passed Strategy object's _DistFunc member. */
};

#endif
