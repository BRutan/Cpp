/* Functions.hpp (exercise 4.3.5)
Description:
	* 

*/

#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP

#include <bitset>
#include <random>

template<typename Engine, std::size_t _Wx, typename _UIntType>
std::bitset<_Wx> 




#endif
