/* Main.cpp (exercise 4.3.1) TODO fix external symbol error
Description:
	* Solutions to problems a-c in exercise 4.3.1.
*/


#include <iostream>
#include <random>

int main()
{
	std::mt19937 eng;
	double A = 0.0;
	double B = 1.0;
	std::normal_distribution<double> normal();
	std::uniform_real_distribution<double> uniform(A, B);
	std::chi_squared_distribution<double> chiSq();
	std::bernoulli_distribution bern();
	std::cauchy_distribution<double> cauchy();

	std::cout << "Engine outputs: " << std::endl;
	std::cout << "lin_cong: normal: uniform(0, 1): chiSq: bernoulli: cauchy:" << std::endl;
	int nTrials = 30;
	for (int i = 1; i <= nTrials; i++)
	{
		std::cout << uniform(eng) << " "<< normal() << " " << uniform(eng) << " " << chiSq() << " " << bern() << " " << cauchy() << std::endl;
	}
	std::cout << "end\n\n" << std::endl;

	system("pause");

	return 0;
}