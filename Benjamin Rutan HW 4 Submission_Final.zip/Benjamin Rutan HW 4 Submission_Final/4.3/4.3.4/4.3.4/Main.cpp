/* Main.cpp (exercise 4.3.4)
Description:
	*


*/

#include <iomanip>
#include <iostream>
#include <random>

int main()
{
	// a) Create random device and set seed:
	std::random_device device;
	// b) Create two uniform distributions:
	std::uniform_real_distribution<double> dist1(0.0, 1.0), dist2(0.0, 1.0);
	
	// c) Create loop generating uniform random vals x and y, and store count whether pythagorean distance to origin is greater than 1:
	std::size_t counter = 0;
	std::size_t numTrials = 2000000;
	double x, y, temp;
	for (std::size_t trial = 0; trial < numTrials; trial++)
	{
		x = (double) dist1(device);
		y = (double) dist2(device);
		temp = std::sqrt(x * x + y * y);
		if (std::sqrt(x * x + y * y) > 1.0)
		{
			counter++;
		}
	}

	// d) Compute pi based on number of trials and value of counter:
	std::cout << "pi approximation: " << std::setprecision(5) << 4.0 * (double)counter / numTrials << std::endl;

	system("pause");

	return 0;
}