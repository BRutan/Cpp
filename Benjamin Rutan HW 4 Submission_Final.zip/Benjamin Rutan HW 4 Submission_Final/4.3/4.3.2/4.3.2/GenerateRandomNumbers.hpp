/* GenerateRandomNumbers.hpp (exercise 4.3.2)
Description:
	* Generate random numbers and print histogram for generic probability distribution and engine.
*/


#ifndef GENERATERANDOMNUMBERS_HPP
#define GENERATERANDOMNUMBERS_HPP

#include <iomanip>
#include <iostream>
#include <map>
#include <string>

template<typename Dist, typename Eng>
void GenerateRandomNumbers(Dist d, Eng eng, std::size_t NTrials, const std::string &s)
{
	std::map<long long, double> counter;
	for (std::size_t trial = 1; trial <= NTrials; trial++)
	{
		counter.insert(std::pair<long long, double>(trial, d(eng)));
	}
	// Print contents of histogram:
	std::cout << "Distribution " << s << std::endl;
	for (std::size_t trial = 1; trial <= NTrials; trial++)
	{
		std::cout << trial << ", " << std::setprecision(2) << counter[trial] << std::endl;
	}
	counter.clear();
}


#endif