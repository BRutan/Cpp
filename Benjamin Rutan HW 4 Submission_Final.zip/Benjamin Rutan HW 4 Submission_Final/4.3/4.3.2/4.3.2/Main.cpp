/* Main.cpp (exercise 4.3.2)
Description:
	* Solutions to problems a-c for exercise 4.3.2.
*/

#include <iostream>
#include <random>
#include "GenerateRandomNumbers.hpp"


int main()
{
	// b) Test the GenerateRandomNumbers() function:
	GenerateRandomNumbers(std::geometric_distribution<>(.1), std::default_random_engine(), 100, "Geometric");
	GenerateRandomNumbers(std::uniform_real<double>(0.0, 1.0), std::default_random_engine(), 100, "Uniform");
	GenerateRandomNumbers(std::poisson_distribution<>(4), std::default_random_engine(), 100, "Poisson");

	system("pause");
	
	return 0;
}