/* Main.cpp (exercise 4.3.3)
Description:
	* Solutions to problems a, b for exercise 4.3.3.
*/

#include <algorithm>
#include <iostream>
#include <random>
#include <vector>

int main()
{
	std::vector<int> testVec;

	for (std::size_t i = 0; i < 1000; i++)
	{
		testVec.push_back(i);
	}

	// Shuffle the vector:
	// using mt19937:
	//std::random_shuffle(testVec.begin(), testVec.end(), std::mt19937());
	
	// Using default_random_engine:
	//std::random_shuffle(testVec.begin(), testVec.end(), std::default_random_engine());

	// Using linear_congruential_engine:
	// std::random_shuffle(testVec.begin(), testVec.end(), std::linear_congruential_engine<unsigned long, 21, 23, 24>());

	// b) Do above using std::shuffle():

	std::shuffle(testVec.begin(), testVec.end(), std::mt19937());
	std::shuffle(testVec.begin(), testVec.end(), std::default_random_engine());
	std::shuffle(testVec.begin(), testVec.end(), std::linear_congruential_engine<unsigned long, 21, 23, 24>());

	// Print vector:
	for (std::size_t i = 0; i < 100; i++)
	{
		std::cout << "{ ";
		for (std::size_t j = 0; j < 10; j++)
		{
			std::cout << testVec[i + j] << ((j < 9) ? ", " : " }\n");
		}
	}

	system("pause");

	return 0;
}