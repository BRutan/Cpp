/* Main.cpp (exercise 4.2.6)
Description:
	* Solutions to problems a-c for exercise 4.2.6.
*/

#include <iostream>
#include <string>
#include <vector>
#include "Functions.hpp"
#include "Point.hpp"
int main()
{
	std::vector<int> S1{ 1, 2, 3, 4, 5, 6 };
	std::vector<int> S2{ 1, 5 };

	std::cout << "S1: " << S1 << std::endl;
	std::cout << "S2: " << S2 << std::endl;
	// a) Remove elements from S1 that are not in S2 and return output:
	std::vector<int> output = SetDifference(S1, S2);
	std::cout << "S1 - S2: " << S1 << std::endl;
	std::cout << "Removed elements: " << output << std::endl;

	// b) Create array of points and filter out points that do not meet distance threshold between all other points:
	std::vector<CAD::Point> pointArray;
	double distThreshold = 5;
	for (std::size_t i = 0; i < 5; i++)
	{
		pointArray.push_back(CAD::Point(i, i + 4));
	}
	
	std::cout << "Point array: " << pointArray << std::endl;
	// Remove using predicate:
	// Filter(pointArray, [&distThreshold](const CAD::Point &a, const CAD::Point &b) { return a.Distance(b) < distThreshold; });
	std::cout << "Point array, with points less than " << distThreshold << " away from all others removed: " << pointArray << std::endl;

	// c) Trim all leading and trailing blanks from string:
	std::string test = "   abc123\t";
	std::cout << "test: " << test << std::endl;
	Trim(test);
	std::cout << "Trim(test): " << test << std::endl;

	// Test Trim_If():
	Trim_If(test, [](auto i) { return isdigit(i); });
	std::cout << "Trim_If(test, [remove numbers](){}): " << test << std::endl;

	// Test Split():
	std::string test2 = "abc, 123, abc, 345";
	std::vector<std::string> output2 = Split(test2, ", ");
	std::cout << "test2: " << test2 << std::endl;
	std::cout << "Split(test2): " << output2 << std::endl;


	system("pause");

	return 0;
}