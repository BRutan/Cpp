/* Functions.hpp (exercise 4.2.6)
Description:
	* Solutions to problems a-c for exercise 4.2.6.
*/

#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP

#include <algorithm>
#include <iostream>
#include <vector>
#include "Point.hpp"

// a) 
template<typename T, typename Alloc>
std::vector<T, Alloc> SetDifference(std::vector<T, Alloc> &s1, const std::vector<T, Alloc> &s2)
{
	std::vector<T, Alloc> output;
	bool exit = false;
	for (auto iter = s1.begin(); iter != s1.end();)
	{
		for (auto iter2 = s2.begin(); iter2 != s2.end(); iter2++)
		{
			if (!(iter != s1.end()))
			{
				exit = true;
				break;
			}
			if (*iter == *iter2)
			{
				iter = s1.erase(iter);
			}
		}
		if (exit)
		{
			break;
		}
		else
		{
			iter++;
		}
	}
	return output;
}

// b) Filter out all points that do not meet distance threshold:
template<typename BinaryPred>
void Filter(std::vector<CAD::Point> &pointArray, BinaryPred pred)
{
	bool exit = false;
	for (auto iter = pointArray.begin(); iter != pointArray.end(); )
	{
		for (auto iter2 = iter + 1; iter2 != pointArray.end(); )
		{
			if (!(iter != pointArray.end()))
			{
				exit = true;
				break;
			}
			if (!pred(*iter, *iter2))
			{
				iter2++;
				iter = pointArray.erase(iter);
			}
			else
			{
				iter2++;
			}
		}
		if (exit)
		{
			break;
		}
		iter++;
	}
}

// c) String functions:
void Trim(std::string &in)
{
	// Trim leading blanks:
	std::size_t i = 0;
	while (in.at(i) == '\t' || in.at(i) == ' ')
	{
		in.erase(i, 1);
		i++;
	}
	// Trim trailing blanks:
	i = in.size() - 1;
	while (in.at(i) == '\t' || in.at(i) == ' ')
	{
		in.erase(i, 1);
		i--;
	}
}
template<typename UnaryPredicate>
void Trim_If(std::string &in, UnaryPredicate pred)
{
	std::size_t i = 0;
	while (pred(in.at(i)))
	{
		in.erase(i, 1);
		i++;
	}
	i = in.size() - 1;
	while (pred(in.at(i)))
	{
		in.erase(i, 1);
		i--;
	}
}

std::vector<std::string> Split(const std::string &in, const char *delimiter)
{
	std::vector<std::string> output;
	std::size_t currIndex = 0;
	while (in.find(*delimiter, currIndex) != in.npos)
	{
		output.push_back(in.substr(currIndex, in.find(*delimiter, currIndex) - 1));
		currIndex = in.find(*delimiter, currIndex) + 1;
	}
	return output;
}

template<typename T, typename Alloc>
std::ostream& operator<<(std::ostream &out, const std::vector<T, Alloc> &in)
{
	if (in.size())
	{
		out << "{ ";
		for (std::size_t index = 0; index < in.size(); index++)
		{
			out << in[index] << ((index < in.size() - 1) ? ", " : " }");
		}
	}
	return out;
}


#endif
