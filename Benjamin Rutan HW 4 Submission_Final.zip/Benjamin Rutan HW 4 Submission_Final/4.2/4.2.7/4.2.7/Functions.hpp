/* Functions.hpp (exercise 4.2.7)
Description:
	* Solutions to problems a-d for exercise 4.2.7.
*/

#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP

#include <iostream>
#include <vector>

// a) Reverse vector:
template<typename T, typename Alloc>
std::vector<T, Alloc> Reverse(const std::vector<T, Alloc> &in)
{
	std::vector<T, Alloc> output;
	for (std::size_t i = in.size(); i > 0; i--)
	{
		output.push_back(in[i - 1]);
	}
	return output;
}
// b) Rotate vector:
template<typename T, typename Alloc>
std::vector<T, Alloc> Rotate(const std::vector<T, Alloc> &in)
{
	std::vector<T, Alloc> output;
	for (std::size_t i = in.size(); i > 0; i--)
	{
		output.push_back(in[i - 1]);
	}
	return output;
}

// c) PowerSet()
template<typename T, typename Alloc1, typename Alloc2>
std::vector<std::vector<T, Alloc1>, Alloc2> PowerSet(const std::vector<T, Alloc1> &in)
{
	std::size_t setSize = 1;
	for (auto &i : in)
	{

	}

}

// d) Move subset to front of container:
template<typename T, typename Alloc>
std::vector<T, Alloc> InsertFront(const std::vector<T, Alloc> &subSet, const std::vector<T, Alloc> &superSet)
{
	std::vector<T, Alloc> output(superSet);
	for (auto &i : subSet)
	{
		output.push_back(i);
	}
	return output;
}




template<typename T, typename Alloc>
std::ostream& operator<<(std::ostream &out, const std::vector<T, Alloc> &in)
{
	if (in.size())
	{
		out << "{ ";
		for (std::size_t i = 0; i < in.size(); i++)
		{
			out << in[i] << ((i < in.size() - 1) ? ", " : " }");
		}
	}
	return out;
}


#endif
