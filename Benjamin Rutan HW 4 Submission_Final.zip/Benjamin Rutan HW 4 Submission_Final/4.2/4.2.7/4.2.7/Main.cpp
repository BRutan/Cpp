/* Main.cpp (exercise 4.2.7)
Description:
	*Solutions to problems a-d for exercise 4.2.7.
*/


#include <vector>
#include "Functions.hpp"

int main()
{
	// a) Test Reverse():
	std::vector<int> S { 1,-1,7,8,9,10 };
	std::cout << "S: " << S << std::endl;
	std::cout << "Reverse(S): " << Reverse(S) << std::endl;

	// b) Test Rotate():

	// c) Test PowerSet():

	// d) Test InsertFront():
	std::cout << "Subset: " << std::vector<int>({8, 9, 10}) << std::endl;
	std::cout << "InsertFront(SubSet, S): " << InsertFront(std::vector<int>({ 8, 9, 10 }), S) << std::endl;


	system("pause");

	return 0;
}