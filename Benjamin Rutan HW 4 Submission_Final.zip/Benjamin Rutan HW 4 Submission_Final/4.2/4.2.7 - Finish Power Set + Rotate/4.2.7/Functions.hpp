/* Functions.hpp (exercise 4.2.7)
Description:
	* Solutions to problems a-d for exercise 4.2.7.
*/

#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP

#include <iostream>
#include <vector>

// a) Reverse vector:
template<typename T, typename Alloc>
std::vector<T, Alloc> Reverse(const std::vector<T, Alloc> &in)
{
	std::vector<T, Alloc> output;
	for (std::size_t i = in.size(); i > 0; i--)
	{
		output.push_back(in[i - 1]);
	}
	return output;
}
// b) Rotate vector:
template<typename T, typename Alloc>
std::vector<T, Alloc> Rotate(std::vector<T, Alloc> &in)
{
	for (auto iter = in.begin(); iter != in.end(); i++)
	{

	}
}

// c) PowerSet()
template<typename T, typename Alloc>
std::vector<std::vector<T, Alloc>> PowerSet(const std::vector<T, Alloc> &in)
{
	// Get uniques in the original set:
	std::vector<T, Alloc> uniques;
	bool found;
	for(auto iter1 = in.begin(); iter1 != in.end();
	{
		found = false;
		for (auto iter2 = iter1; iter2 != in.end(); iter2++)
		{
			if (*iter1 == *iter2)
			{
				found = true;
				break;
			}
		}
		if (!found)
		{
			uniques.push_back(*iter1);
		}
	}
	
	// Generate the power set:
	std::vector<T, Alloc> powerSet;
	for (std::size_t currSetSize = 1; currSetSize <= uniques.size(); currSetSize++)
	{
		for (auto &i : in)
		{

		}
	}

}

// d) Move subset to front of container:
template<typename T, typename Alloc>
std::vector<T, Alloc> InsertFront(const std::vector<T, Alloc> &subSet, const std::vector<T, Alloc> &superSet)
{
	std::vector<T, Alloc> output(superSet);
	for (auto &i : subSet)
	{
		output.push_back(i);
	}
	return output;
}

template<typename T, typename Alloc>
std::ostream& operator<<(std::ostream &out, const std::vector<T, Alloc> &in)
{
	if (in.size())
	{
		out << "{ ";
		for (std::size_t i = 0; i < in.size(); i++)
		{
			out << in[i] << ((i < in.size() - 1) ? ", " : " }");
		}
	}
	return out;
}


#endif
