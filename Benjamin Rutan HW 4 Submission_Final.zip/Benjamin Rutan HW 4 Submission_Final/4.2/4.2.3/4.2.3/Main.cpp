/* Main.cpp (exercise 4.2.3)
Description:
	*


*/


#include <list>
#include <queue>
#include <vector>

int main()
{
	/* 4.2.3 */
	// a) Scale all values by a given factor:
	// Would need to use a modifying algorithm, only O(n) available since needs to work with every unit of the container.
	std::vector<double> values(200, 10);
	std::for_each(values.begin(), values.end(), [](auto val) { return val * 20; });

	// b) Count number of elements whose values are in a given range:

	// c) Find the average, minimum and maximum values in a container:

	// d) Find the first element that is/is not in the range:

	// e) Search for all occurrences of 3456 in the container:

	// f) Determine if the elements in two ranges are equal:

	// g) Determine if a set is some permutation of 12345

	// h) Determine if container is already sorted:

	// i) Copy container into another:

	// j) Move last 10 elements of a container to the front:

	// k) Swap two ranges at a given position:

	// l) Generate vlaues in a container based on some formula:

	// m) Replace all uneven numbers by 0:

	// n) Remove all elements whose value is less than 100:

	// o) Shuffle a container randomly:

	// p) Compute one-sided divided differences of the values in a container:


	return 0;
}