/* Main.cpp (exercise 4.2.5)
Description:
	*


*/

#include <algorithm>
#include <functional>
#include <iostream>
#include <vector>
#include "Functions.hpp"

int main()
{
	// b) Transform vector of integers into a set of integers:
	int thresholdValue = 2;
	std::vector<int> testVec{ 1, 2, 1, 4, 5, 5, -1 };
	std::cout << "testVec: " << testVec << std::endl;
	auto transformVec = [&thresholdValue](auto input) { return input > thresholdValue; };
	std::transform(testVec.begin(), testVec.end(), testVec.begin(), transformVec);
	std::cout << "testVec following threshold application: " << testVec << std::endl;

	system("pause");

	return 0;
}