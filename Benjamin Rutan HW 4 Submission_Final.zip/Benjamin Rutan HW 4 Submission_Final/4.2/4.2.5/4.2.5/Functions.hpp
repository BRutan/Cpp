/* Functions.hpp (exercise 4.2.5)
Description:
	* 


*/

#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP

#include <iostream>
#include <vector>

struct FuncObj
{

	void operator()()
	{

	}
};



template<typename T, typename Alloc>
std::ostream& operator<<(std::ostream &out, const std::vector<T, Alloc> &in)
{
	if (in.size())
	{
		out << "{ ";
		for (std::size_t index = 0; index < in.size(); index++)
		{
			out << in[index] << ((index != in.size() - 1) ? ", " : "}");
		}
	}
	return out;
}

#endif
