/* Main.cpp (exercise 4.2.2) TODO add more elements to vec8, change size of output window (
Description:
	*


*/

#include <algorithm>
#include <iostream>
#include <string>
#include <vector>
#include <windows.h>

#include "StopWatch.hpp"

int main()
{
	// Adjust stdout window size:
	std::vector<double> vec8 { 1.0, 2.0, 3.0, -4.0, 10.0 };
	std::vector<double>::iterator pos;
	std::vector<std::string> functionNames{ "is_sorted_until(comparator)", "is_sorted_until", "is_sorted(comparator)", "is_sorted" };
	double times[4];
	bool isSorted;
	StopWatch sw;
	std::cout << "vec8 : { ";
	for (auto it = vec8.begin(); it != vec8.end(); it++)
	{
		std::cout << *it << (((it + 1) != vec8.end()) ?", ":" }\n");
	}
	// a) Test is_sorted_until and is_sorted with and without comparator:
	// Test is_sorted_until with comparator:
	sw.StartStopWatch();
	pos = std::is_sorted_until(vec8.begin(), vec8.end(), [](auto a, auto b) {return a < b; });
	sw.StopStopWatch();
	times[0] = sw.GetTime();
	std::cout << "is_sorted_until (with comparator): " << *pos << std::endl;
	// Test without comparator:
	sw.StartStopWatch();
	pos = std::is_sorted_until(vec8.begin(), vec8.end());
	sw.StopStopWatch();
	times[1] = sw.GetTime();
	std::cout << "is_sorted_until (without comparator): " << *pos << std::endl;
	// Test is_sorted with and without comparator:
	sw.StartStopWatch();
	isSorted = std::is_sorted(vec8.begin(), vec8.end(), [](auto a, auto b) { return a > b; });
	sw.StopStopWatch();
	times[2] = sw.GetTime();
	std::cout << "is_sorted (with comparator): " << isSorted << std::endl;
	sw.StartStopWatch();
	isSorted = std::is_sorted(vec8.begin(), vec8.end());
	sw.StopStopWatch();
	times[3] = sw.GetTime();
	std::cout << "is_sorted (without comparator): " << isSorted << std::endl;

	// Display the relative times to complete matrix:
	std::size_t row = 0;
	std::cout << "-------------------------------" << std::endl;
	std::cout << "Relative complexity matrix:    " << std::endl;
	std::cout << "-------------------------------" << std::endl;
	for (auto it = functionNames.begin(); it != functionNames.end(); it++)
	{
		std::cout << *it << ":" << ++row << std::endl;
	}
	std::cout << "\t1\t2\t3\t4\t" << std::endl;
	for (row = 1; row <= functionNames.size(); row++)
	{
		std::cout << row << ":\t";
		for (std::size_t col = 0; col < 4; col++)
		{
			std::cout << times[col] / times[row - 1] << "\t";
		}
		std::cout << std::endl;
	}

	system("pause");

	return 0;
}