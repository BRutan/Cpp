/* Main.cpp (exercise 4.2.1)
Description:
	* 

*/

#include <iostream>
#include "Functions.hpp"


int main()
{
	/* 4.2.1 */




	return 0;
}