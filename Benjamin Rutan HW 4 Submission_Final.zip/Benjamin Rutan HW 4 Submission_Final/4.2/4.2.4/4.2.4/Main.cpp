/* Main.cpp (exercise 4.2.4)
Description:
	* Solutions to problems a-f for exercise 4.2.4.
*/

#include <functional>
#include <initializer_list>
#include <iostream>
#include <vector>
#include "Functions.hpp"

int main()
{
	// a) Test GetUniqueCounts:
	std::vector<double> testVec{ 1,2,4,5,4,1 };
	std::vector<std::pair<double, std::size_t>> output = GetUniqueCounts(testVec);
	std::cout << "Get unique counts: " << output << std::endl;
	// b) Test the GetStats function:
	std::vector<double> testVec2(100, 1.0);
	std::tuple<double, double, double, double> stats(GetStats(testVec2));
	std::cout << "Min: " << std::get<0>(stats) << ", Max: " << std::get<1>(stats) << ", Sum: " << std::get<2>(stats) << ", Average: " << std::get<3>(stats) << std::endl;
	// c) Use STL algorithm to find first occurrence of value 5 in container S:
	std::vector<int> S{ 1,2,-3,4,5,5,5,6 };
	std::cout << "S: " << S << std::endl;
	auto fiveIndex = std::find(S.begin(), S.end(), 5);
	std::cout << "First 5 index in container: " << std::distance(S.begin(), fiveIndex) << std::endl;
	// d) Return position of first three consecutive elements having value 5:
	std::vector<int> S2{ 1,2,5,5,-3,4,5,5,5,6,3,4,5 };
	std::cout << "S2: " << S2 << std::endl;
	std::size_t result = GetPosition({ 5, 5, 5 }, S2);
	std::cout << "First position of {5, 5, 5}: " << result << std::endl;
	// Return position of first element of the first subrange matching {3, 4, 5}:
	result = GetPosition({ 3, 4, 5 }, S2, 2);
	std::cout << "First position of {3, 4, 5}: " << result << std::endl;
	// Return position of first element of the last subrange matching {3, 4, 5}:
	result = GetPosition_Final({ 3, 4, 5 }, S2);
	std::cout << "Last position of {3, 4, 5}: " << result << std::endl;

	// e) Find first element that has value equal to the value of following element:
	std::vector<int> S3{ 1,2,5,5,-3,4,5,5,5,6,3,4,5 };
	std::cout << "S3: " << S3 << std::endl;
	std::size_t result2 = findFirstRepeat(S3);
	std::cout << "First element with value equal to value of following element: " << S3[result2] << std::endl;

	// f) Find whether the elements in {1, 2, 5} are equal to the elements in set:
	std::cout << "{1, 2, 5} is a subset of S3: " << ((is_subset({ 1, 2, 5 }, S3))? "True": "False") << std::endl;

	system("pause");

	return 0;
}