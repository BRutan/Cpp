/* Functions.hpp (exercise 4.2.4)
Description:
	* Functions that serve as solutions to problems a-f.
*/


#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP

#include <array>
#include <algorithm>
#include <initializer_list>
#include <map>
#include <tuple>
#include <vector>

// a) Generate function to count frequency of each value in the container:
template<typename T, typename Alloc>
std::vector<std::pair<T, std::size_t>> GetUniqueCounts(std::vector<T, Alloc> &input)
{
	std::vector<std::pair<T, std::size_t>> output;
	T currVal;
	std::size_t currCount;
	// Sort the input vector:
	std::sort(input.begin(), input.end());
	// Get unique counts:
	auto it = input.begin();
	while (it != input.end())
	{
		currVal = *it;
		currCount = 0;
		while (currVal == *(it))
		{
			currCount++;
			it++;
			if (!(it != input.end()))
				break;
		}
		output.push_back(std::make_pair<T, std::size_t>(std::move(currVal), std::move(currCount)));
	}
	return output;
}

// b) Generate function to compute min, max, sum and average of values of the elements in a numeric container:
template<typename T, typename Alloc>
std::tuple<double, double, double, double> GetStats(std::vector<T, Alloc> &input)
{
	// Sort the vector:
	std::sort(input.begin(), input.end());
	double min = *input.begin();
	double max = *(input.end() - 1);
	// Get sum:
	double sum = 0;
	for (auto it = input.begin(); it != input.end(); it++)
	{
		sum += *it;
	}
	double average = sum / std::distance(input.begin(), input.end());
	// Return statistics:
	return std::make_tuple<double, double, double, double>(std::move(min), std::move(max), std::move(sum), std::move(average));
}


// d) Return position of first three consecutive elements having the value 5:
template<typename T, typename Alloc>
std::size_t GetPosition(const std::initializer_list<T> &list, const std::vector<T, Alloc> &data, std::size_t count = 0)
{
	if (data.size() / list.size() < count || list.size() > data.size())
	{
		throw std::out_of_range("");
	}
	auto it = data.begin();
	std::size_t countTracker = 0;
	while (it != data.end())
	{
		auto it2 = list.begin();
		auto itTemp = it;
		while (it2 != list.end())
		{
			if (*itTemp != *it2)
			{
				break;
			}
			it2++;
			itTemp++;
		}
		if (!(it2 != list.end()))
		{
			countTracker++;
			if (countTracker >= count)
			{
				return std::distance(data.begin(), it);
			}
		}
		else
		{
			it++;
		}
	}
	// Match not found, return size of array:
	return data.size();
}
template<typename T, typename Alloc>
std::size_t GetPosition_Final(const std::initializer_list<T> &sequence, const std::vector<T, Alloc> &data)
{
	if (sequence.size() > data.size())
	{
		return data.size();
	}
	auto it = data.begin();
	std::vector<std::size_t> positions;
	while (it != data.end())
	{
		auto itTemp = it;
		auto seqIt = sequence.begin();
		while (seqIt != sequence.end())
		{
			if (*seqIt != *itTemp)
			{
				break;
			}
			itTemp++;
			seqIt++;
		}
		if (!(seqIt != sequence.end()))
		{
			positions.push_back(std::distance(data.begin(), it));
		}
		it++;
	}
	return positions.at(positions.size() - 1);
}
// GetPosition with predicate:
template<typename T, typename Alloc, typename NAryPredicate>
std::size_t GetPosition(const std::vector<T, Alloc> &data, NAryPredicate pred)
{
	for (auto iter = data.begin(); iter != data.end(); iter++)
	{
		if (pred())
	}
	// Match not found, return size of array:
	return data.size();
}

// e) Find first element that has value of previous element:
template<typename T, typename Alloc>
std::size_t findFirstRepeat(std::vector<T, Alloc> vector_in)
{
	std::size_t output = 0;
	for (auto iter = vector_in.begin(); iter != vector_in.end(); iter++) 	
	{
		if(output && *iter == *(iter - 1))
		{
			break;
		}
		output++;
	}
	return output;
}

// f) Determine if all of the elements in a set are in another set:
template<typename T, typename Alloc>
bool is_subset(const std::initializer_list<T> &list_in, const std::vector<T, Alloc> &set_in)
{
	if (list_in.size() > set_in.size())
	{
		return false;
	}
	std::map<T, bool> results;
	// Load all keys into map:
	for (auto &it : list_in)
	{
		results.insert(std::pair<T, bool>(it, false));
	}
	for (auto &it : set_in)
	{
		results[it] = true;
	}
	for (auto &it : results)
	{
		if (!it.second)
		{
			return false;
		}
	}
	return true;
}


// Vector print function:
template<typename T, typename Alloc>
std::ostream& operator<<(std::ostream &out, std::vector<T, Alloc> &in)
{
	std::size_t count = 0;
	out << "{ ";
	for (auto &i : in)
	{
		out << i << ((count++ < in.size() - 1) ? "," : " }");
	}
	return out;
}

// Vector print function:
template<typename T>
std::ostream& operator<<(std::ostream &out, std::vector <std::pair<T, std::size_t>> &in)
{
	std::size_t count = 0;
	out << "{ ";
	for (auto &i : in)
	{
		out << "{" << std::get<0>(i) << ", " << std::get<1>(i) << "}" << ((count++ != in.size())?",":"");
	}
	out << " }";
	return out;
}




#endif
