/* Main.cpp (exercise 4.1.3)
Description:
	* Solutions to problems a-e for exercise 4.1.3.
*/

#define _SCL_SECURE_NO_WARNINGS

#include <iostream>
#include "Matrix.hpp"

int main()
{
	// b) Create instance of Matrix and print:
	Matrix<int, 5, 5> matrix_1(5);
	std::cout << "Matrix_1: " << matrix_1 << std::endl;

	// d) Implement scalar multiplication:
	std::cout << "5 * Matrix_1 = " << 5 * matrix_1 << std::endl;

	// e) Test modify() method:
	std::function<int(int)> test = [](int input) { return input * 20; };
	matrix_1.modify(test);
	std::cout << "Matrix_1.modify(): " << matrix_1 << std::endl;

	system("pause");

	return 0;
}