/* Main.cpp (exercise 4.1.3)
Description:
	*
	
	
*/

int main()
{

	return 0;
}